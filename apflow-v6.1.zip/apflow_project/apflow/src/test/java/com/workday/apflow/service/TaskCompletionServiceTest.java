package com.workday.apflow.service;

import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.execution.ExecutionQueuingInterceptor;
import com.workday.apflow.execution.WorkflowStateManager;
import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.model.WorkflowExecutionQueue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TaskCompletionServiceTest {

    @Mock
    private TaskInstanceDAO taskInstanceDAO;
    
    @Mock
    private ExecutionQueuingInterceptor executionQueuingInterceptor;
    
    @Mock
    private WorkflowStateManager workflowStateManager;
    
    private TaskCompletionService taskCompletionService;
    
    @BeforeEach
    void setUp() {
        taskCompletionService = new TaskCompletionService(taskInstanceDAO, executionQueuingInterceptor, workflowStateManager);
    }
    
    @Test
    void testCompleteTask() {
        // Setup
        Integer taskInstanceId = 1;
        Map<String, Object> outputMap = new HashMap<>();
        outputMap.put("result", "success");
        
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(taskInstanceId);
        taskInstance.setName("Test Task");
        taskInstance.setType("TODO");
        taskInstance.setStatus("IN_PROGRESS");
        
        WorkflowExecutionQueue queueEntry = new WorkflowExecutionQueue();
        queueEntry.setId(1);
        queueEntry.setWorkflowInstanceId(100);
        queueEntry.setNewlyCreated(true);
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(taskInstance);
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(taskInstance);
        when(executionQueuingInterceptor.interceptTaskCompletion(any(TaskInstance.class))).thenReturn(queueEntry);
        
        // Execute
        TaskInstance result = taskCompletionService.completeTask(taskInstanceId, outputMap);
        
        // Verify
        assertNotNull(result);
        assertEquals(taskInstanceId, result.getId());
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, times(1)).updateTaskInstance(any(TaskInstance.class));
        verify(executionQueuingInterceptor, times(1)).interceptTaskCompletion(any(TaskInstance.class));
    }
    
    @Test
    void testCompleteTask_TaskNotFound() {
        // Setup
        Integer taskInstanceId = 1;
        Map<String, Object> outputMap = new HashMap<>();
        outputMap.put("result", "success");
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(null);
        
        // Execute & Verify
        assertThrows(RuntimeException.class, () -> 
            taskCompletionService.completeTask(taskInstanceId, outputMap)
        );
        
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, never()).updateTaskInstance(any(TaskInstance.class));
        verify(executionQueuingInterceptor, never()).interceptTaskCompletion(any(TaskInstance.class));
    }
}
