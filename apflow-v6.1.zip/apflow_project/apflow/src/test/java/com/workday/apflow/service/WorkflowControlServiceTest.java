package com.workday.apflow.service;

import com.workday.apflow.constants.WorkflowConstants;
import com.workday.apflow.constants.WorkflowControlConstants;
import com.workday.apflow.dao.WorkflowInstanceDAO;
import com.workday.apflow.dto.request.WorkflowInstanceRequest;
import com.workday.apflow.dto.workflow.WorkflowInstanceDTO;
import com.workday.apflow.error.WorkflowException;
import com.workday.apflow.execution.ExecutionQueuingInterceptor;
import com.workday.apflow.model.WorkflowInstance;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class WorkflowControlServiceTest {

    @Mock
    private WorkflowInstanceDAO workflowInstanceDAO;
    
    @Mock
    private ExecutionQueuingInterceptor interceptor;
    
    private WorkflowControlService service;
    
    @BeforeEach
    public void setUp() {
        service = new WorkflowControlService(workflowInstanceDAO, interceptor);
    }
    
    @Test
    public void testPauseWorkflow_Success() {
        // Arrange
        Integer workflowInstanceId = 123;
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_RUNNING);
        workflow.setPropertiesMap(new HashMap<>());
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        WorkflowInstance result = service.pauseWorkflow(workflowInstanceId);
        
        // Assert
        assertEquals(WorkflowConstants.STATUS_PAUSED, result.getStatus());
        
        Map<String, Object> properties = result.getPropertiesMap();
        assertNotNull(properties);
        assertTrue(properties.containsKey(WorkflowControlConstants.PROP_PAUSED_AT));
        assertEquals("system", properties.get(WorkflowControlConstants.PROP_PAUSED_BY));
        assertEquals("API request", properties.get(WorkflowControlConstants.PROP_PAUSE_REASON));
        
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO).updateWorkflowInstance(workflow);
    }
    
    @Test
    public void testPauseWorkflow_WithUserAndReason() {
        // Arrange
        Integer workflowInstanceId = 123;
        String userId = "testUser";
        String reason = "Testing pause";
        
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_RUNNING);
        workflow.setPropertiesMap(new HashMap<>());
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        WorkflowInstance result = service.pauseWorkflow(workflowInstanceId, userId, reason);
        
        // Assert
        assertEquals(WorkflowConstants.STATUS_PAUSED, result.getStatus());
        
        Map<String, Object> properties = result.getPropertiesMap();
        assertNotNull(properties);
        assertTrue(properties.containsKey(WorkflowControlConstants.PROP_PAUSED_AT));
        assertEquals(userId, properties.get(WorkflowControlConstants.PROP_PAUSED_BY));
        assertEquals(reason, properties.get(WorkflowControlConstants.PROP_PAUSE_REASON));
        
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO).updateWorkflowInstance(workflow);
    }
    
    @Test
    public void testPauseWorkflow_WorkflowNotFound() {
        // Arrange
        Integer workflowInstanceId = 123;
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(null);
        
        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.pauseWorkflow(workflowInstanceId);
        });
        
        assertEquals("Workflow instance not found: " + workflowInstanceId, exception.getMessage());
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO, never()).updateWorkflowInstance(any());
    }
    
    @Test
    public void testPauseWorkflow_NotInRunningState() {
        // Arrange
        Integer workflowInstanceId = 123;
        
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_COMPLETED);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act & Assert
        WorkflowException exception = assertThrows(WorkflowException.class, () -> {
            service.pauseWorkflow(workflowInstanceId);
        });
        
        assertTrue(exception.getMessage().contains("Workflow is not in running state"));
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO, never()).updateWorkflowInstance(any());
    }
    
    @Test
    public void testResumeWorkflow_Success() {
        // Arrange
        Integer workflowInstanceId = 123;
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_PAUSED);
        workflow.setPropertiesMap(new HashMap<>());
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        WorkflowInstance result = service.resumeWorkflow(workflowInstanceId);
        
        // Assert
        assertEquals(WorkflowConstants.STATUS_RUNNING, result.getStatus());
        
        Map<String, Object> properties = result.getPropertiesMap();
        assertNotNull(properties);
        assertTrue(properties.containsKey(WorkflowControlConstants.PROP_RESUMED_AT));
        assertEquals("system", properties.get(WorkflowControlConstants.PROP_RESUMED_BY));
        
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO).updateWorkflowInstance(workflow);
        verify(interceptor).interceptWorkflowResume(workflow);
    }
    
    @Test
    public void testResumeWorkflow_WithUser() {
        // Arrange
        Integer workflowInstanceId = 123;
        String userId = "testUser";
        
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_PAUSED);
        workflow.setPropertiesMap(new HashMap<>());
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        WorkflowInstance result = service.resumeWorkflow(workflowInstanceId, userId);
        
        // Assert
        assertEquals(WorkflowConstants.STATUS_RUNNING, result.getStatus());
        
        Map<String, Object> properties = result.getPropertiesMap();
        assertNotNull(properties);
        assertTrue(properties.containsKey(WorkflowControlConstants.PROP_RESUMED_AT));
        assertEquals(userId, properties.get(WorkflowControlConstants.PROP_RESUMED_BY));
        
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO).updateWorkflowInstance(workflow);
        verify(interceptor).interceptWorkflowResume(workflow);
    }
    
    @Test
    public void testResumeWorkflow_WorkflowNotFound() {
        // Arrange
        Integer workflowInstanceId = 123;
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(null);
        
        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.resumeWorkflow(workflowInstanceId);
        });
        
        assertEquals("Workflow instance not found: " + workflowInstanceId, exception.getMessage());
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO, never()).updateWorkflowInstance(any());
        verifyNoInteractions(interceptor);
    }
    
    @Test
    public void testResumeWorkflow_NotInPausedState() {
        // Arrange
        Integer workflowInstanceId = 123;
        
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_RUNNING);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act & Assert
        WorkflowException exception = assertThrows(WorkflowException.class, () -> {
            service.resumeWorkflow(workflowInstanceId);
        });
        
        assertTrue(exception.getMessage().contains("Workflow is not in paused state"));
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO, never()).updateWorkflowInstance(any());
        verifyNoInteractions(interceptor);
    }
    
    @Test
    public void testUpdateWorkflow_Success() {
        // Arrange
        Integer workflowInstanceId = 123;
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        request.setName("Updated Workflow");
        
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_RUNNING);
        workflow.setPropertiesMap(new HashMap<>());
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        WorkflowInstance result = service.updateWorkflow(workflowInstanceId, request);
        
        // Assert
        assertNotNull(result.getInstanceDto());
        assertEquals("Updated Workflow", result.getInstanceDto().getName());
        
        Map<String, Object> properties = result.getPropertiesMap();
        assertNotNull(properties);
        assertTrue(properties.containsKey(WorkflowControlConstants.PROP_LAST_MODIFIED_AT));
        assertEquals("system", properties.get(WorkflowControlConstants.PROP_LAST_MODIFIED_BY));
        assertEquals("API request", properties.get(WorkflowControlConstants.PROP_MODIFICATION_REASON));
        
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO).updateWorkflowInstance(workflow);
    }
    
    @Test
    public void testUpdateWorkflow_WithDtoUserAndReason() {
        // Arrange
        Integer workflowInstanceId = 123;
        String userId = "testUser";
        String reason = "Testing update";
        
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        dto.setName("Updated Workflow");
        
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_RUNNING);
        workflow.setPropertiesMap(new HashMap<>());
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        WorkflowInstance result = service.updateWorkflow(workflowInstanceId, dto, userId, reason);
        
        // Assert
        assertEquals(dto, result.getInstanceDto());
        
        Map<String, Object> properties = result.getPropertiesMap();
        assertNotNull(properties);
        assertTrue(properties.containsKey(WorkflowControlConstants.PROP_LAST_MODIFIED_AT));
        assertEquals(userId, properties.get(WorkflowControlConstants.PROP_LAST_MODIFIED_BY));
        assertEquals(reason, properties.get(WorkflowControlConstants.PROP_MODIFICATION_REASON));
        
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO).updateWorkflowInstance(workflow);
    }
    
    @Test
    public void testUpdateWorkflow_WorkflowNotFound() {
        // Arrange
        Integer workflowInstanceId = 123;
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(null);
        
        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.updateWorkflow(workflowInstanceId, request);
        });
        
        assertEquals("Workflow instance not found: " + workflowInstanceId, exception.getMessage());
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO, never()).updateWorkflowInstance(any());
    }
    
    @Test
    public void testUpdateWorkflow_InTerminalState() {
        // Arrange
        Integer workflowInstanceId = 123;
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_COMPLETED);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act & Assert
        WorkflowException exception = assertThrows(WorkflowException.class, () -> {
            service.updateWorkflow(workflowInstanceId, request);
        });
        
        assertTrue(exception.getMessage().contains("Workflow is in terminal state"));
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO, never()).updateWorkflowInstance(any());
    }
    
    @Test
    public void testMigrateWorkflow_Success() {
        // Arrange
        Integer workflowInstanceId = 123;
        Integer targetVersionId = 2;
        
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_RUNNING);
        workflow.setVersion(1);
        workflow.setPropertiesMap(new HashMap<>());
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        WorkflowInstance result = service.migrateWorkflow(workflowInstanceId, targetVersionId);
        
        // Assert
        assertEquals(targetVersionId, result.getVersion());
        
        Map<String, Object> properties = result.getPropertiesMap();
        assertNotNull(properties);
        assertTrue(properties.containsKey(WorkflowControlConstants.PROP_LAST_MODIFIED_AT));
        assertEquals("system", properties.get(WorkflowControlConstants.PROP_LAST_MODIFIED_BY));
        assertEquals(WorkflowControlConstants.REASON_VERSION_UPDATE, 
                    properties.get(WorkflowControlConstants.PROP_MODIFICATION_REASON));
        
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO).updateWorkflowInstance(workflow);
    }
    
    @Test
    public void testMigrateWorkflow_WithUser() {
        // Arrange
        Integer workflowInstanceId = 123;
        Integer targetVersionId = 2;
        String userId = "testUser";
        
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_RUNNING);
        workflow.setVersion(1);
        workflow.setPropertiesMap(new HashMap<>());
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        WorkflowInstance result = service.migrateWorkflow(workflowInstanceId, targetVersionId, userId);
        
        // Assert
        assertEquals(targetVersionId, result.getVersion());
        
        Map<String, Object> properties = result.getPropertiesMap();
        assertNotNull(properties);
        assertTrue(properties.containsKey(WorkflowControlConstants.PROP_LAST_MODIFIED_AT));
        assertEquals(userId, properties.get(WorkflowControlConstants.PROP_LAST_MODIFIED_BY));
        assertEquals(WorkflowControlConstants.REASON_VERSION_UPDATE, 
                    properties.get(WorkflowControlConstants.PROP_MODIFICATION_REASON));
        
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO).updateWorkflowInstance(workflow);
    }
    
    @Test
    public void testMigrateWorkflow_WorkflowNotFound() {
        // Arrange
        Integer workflowInstanceId = 123;
        Integer targetVersionId = 2;
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(null);
        
        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.migrateWorkflow(workflowInstanceId, targetVersionId);
        });
        
        assertEquals("Workflow instance not found: " + workflowInstanceId, exception.getMessage());
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO, never()).updateWorkflowInstance(any());
    }
    
    @Test
    public void testMigrateWorkflow_InTerminalState() {
        // Arrange
        Integer workflowInstanceId = 123;
        Integer targetVersionId = 2;
        
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_COMPLETED);
        workflow.setVersion(1);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act & Assert
        WorkflowException exception = assertThrows(WorkflowException.class, () -> {
            service.migrateWorkflow(workflowInstanceId, targetVersionId);
        });
        
        assertTrue(exception.getMessage().contains("Workflow is in terminal state"));
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verify(workflowInstanceDAO, never()).updateWorkflowInstance(any());
    }
}
