package com.workday.apflow.dao;

import com.workday.apflow.constants.WorkflowConstants;
import com.workday.apflow.model.WorkflowInstance;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class WorkflowInstanceDAOTest {

    private WorkflowInstanceDAO workflowInstanceDAO;
    
    @BeforeEach
    void setUp() {
        workflowInstanceDAO = new WorkflowInstanceDAO();
    }
    
    @Test
    void testCreateWorkflowInstance() {
        // Setup
        WorkflowInstance workflowInstance = new WorkflowInstance();
        workflowInstance.setName("Test Workflow");
        workflowInstance.setStatus(WorkflowConstants.STATUS_PENDING);
        workflowInstance.setInputJson("{\"input\":\"test\"}");
        workflowInstance.setInstanceJson("{\"sequence\":[]}");
        workflowInstance.setCreatedBy("test-user");
        workflowInstance.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        
        // Execute
        WorkflowInstance result = workflowInstanceDAO.createWorkflowInstance(workflowInstance);
        
        // Verify
        assertNotNull(result);
        assertNotNull(result.getId());
        assertEquals("Test Workflow", result.getName());
        assertEquals(WorkflowConstants.STATUS_PENDING, result.getStatus());
    }
    
    @Test
    void testGetWorkflowInstance() {
        // Setup
        Integer workflowInstanceId = 1;
        
        // Execute
        WorkflowInstance result = workflowInstanceDAO.getWorkflowInstance(workflowInstanceId);
        
        // Verify
        assertNotNull(result);
    }
    
    @Test
    void testGetAllWorkflowInstances() {
        // Execute
        List<WorkflowInstance> result = workflowInstanceDAO.getAllWorkflowInstances();
        
        // Verify
        assertNotNull(result);
    }
    
    @Test
    void testGetWorkflowInstancesByStatus() {
        // Setup
        String status = WorkflowConstants.STATUS_RUNNING;
        
        // Execute
        List<WorkflowInstance> result = workflowInstanceDAO.getWorkflowInstancesByStatus(status);
        
        // Verify
        assertNotNull(result);
    }
    
    @Test
    void testUpdateWorkflowInstance() {
        // Setup
        WorkflowInstance workflowInstance = new WorkflowInstance();
        workflowInstance.setId(1);
        workflowInstance.setName("Test Workflow");
        workflowInstance.setStatus(WorkflowConstants.STATUS_RUNNING);
        
        // Execute
        WorkflowInstance result = workflowInstanceDAO.updateWorkflowInstance(workflowInstance);
        
        // Verify
        assertNotNull(result);
        assertEquals(1, result.getId());
        assertEquals(WorkflowConstants.STATUS_RUNNING, result.getStatus());
    }
    
    @Test
    void testDeleteWorkflowInstance() {
        // Setup
        Integer workflowInstanceId = 1;
        
        // Execute - should not throw exception
        workflowInstanceDAO.deleteWorkflowInstance(workflowInstanceId);
        
        // No verification needed as the method has no return value
        // and the implementation is a no-op for now
    }
}
