package com.workday.apflow.dto.workflow;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class WorkflowInstanceDTOTest {

    @Test
    public void testDefaultConstructor() {
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        
        assertNotNull(dto);
        assertNotNull(dto.getSequence());
        assertTrue(dto.getSequence().isEmpty());
        assertNotNull(dto.getTaskGroups());
        assertTrue(dto.getTaskGroups().isEmpty());
        assertNotNull(dto.getStandaloneTasks());
        assertTrue(dto.getStandaloneTasks().isEmpty());
        assertNotNull(dto.getMetadata());
        assertTrue(dto.getMetadata().isEmpty());
        assertNotNull(dto.getInputData());
        assertTrue(dto.getInputData().isEmpty());
        assertNotNull(dto.getOutputData());
        assertTrue(dto.getOutputData().isEmpty());
        assertEquals(0, dto.getCurrentPosition());
    }
    
    @Test
    public void testSettersAndGetters() {
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        
        // Test sequence
        List<SequenceItemDTO> sequence = new ArrayList<>();
        TaskSequenceItemDTO task = new TaskSequenceItemDTO();
        task.setId("task1");
        sequence.add(task);
        
        dto.setSequence(sequence);
        assertEquals(sequence, dto.getSequence());
        assertEquals(1, dto.getSequence().size());
        
        // Test current position
        dto.setCurrentPosition(5);
        assertEquals(5, dto.getCurrentPosition());
        
        // Test task groups
        Map<String, TaskGroupDTO> taskGroups = new HashMap<>();
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        taskGroup.setType("HORIZONTAL");
        taskGroups.put("tg1", taskGroup);
        
        dto.setTaskGroups(taskGroups);
        assertEquals(taskGroups, dto.getTaskGroups());
        assertEquals(1, dto.getTaskGroups().size());
        
        // Test standalone tasks
        Map<String, TaskDTO> standaloneTasks = new HashMap<>();
        TaskDTO taskDto = new TaskDTO();
        taskDto.setName("Task 1");
        standaloneTasks.put("task1", taskDto);
        
        dto.setStandaloneTasks(standaloneTasks);
        assertEquals(standaloneTasks, dto.getStandaloneTasks());
        assertEquals(1, dto.getStandaloneTasks().size());
        
        // Test metadata
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("createdBy", "user1");
        
        dto.setMetadata(metadata);
        assertEquals(metadata, dto.getMetadata());
        assertEquals(1, dto.getMetadata().size());
        
        // Test input data
        Map<String, Object> inputData = new HashMap<>();
        inputData.put("key1", "value1");
        
        dto.setInputData(inputData);
        assertEquals(inputData, dto.getInputData());
        assertEquals(1, dto.getInputData().size());
        
        // Test output data
        Map<String, Object> outputData = new HashMap<>();
        outputData.put("result", "success");
        
        dto.setOutputData(outputData);
        assertEquals(outputData, dto.getOutputData());
        assertEquals(1, dto.getOutputData().size());
    }
    
    @Test
    public void testAddSequenceItem() {
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        
        TaskSequenceItemDTO task = new TaskSequenceItemDTO();
        task.setId("task1");
        
        // Add item to sequence
        if (dto.getSequence() == null) {
            dto.setSequence(new ArrayList<>());
        }
        dto.getSequence().add(task);
        
        assertEquals(1, dto.getSequence().size());
        assertEquals(task, dto.getSequence().get(0));
    }
    
    @Test
    public void testAddTaskGroup() {
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        taskGroup.setType("HORIZONTAL");
        
        // Add task group
        if (dto.getTaskGroups() == null) {
            dto.setTaskGroups(new HashMap<>());
        }
        dto.getTaskGroups().put("tg1", taskGroup);
        
        assertEquals(1, dto.getTaskGroups().size());
        assertEquals(taskGroup, dto.getTaskGroups().get("tg1"));
    }
    
    @Test
    public void testAddStandaloneTask() {
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        
        TaskDTO task = new TaskDTO();
        task.setName("Task 1");
        
        // Add standalone task
        if (dto.getStandaloneTasks() == null) {
            dto.setStandaloneTasks(new HashMap<>());
        }
        dto.getStandaloneTasks().put("task1", task);
        
        assertEquals(1, dto.getStandaloneTasks().size());
        assertEquals(task, dto.getStandaloneTasks().get("task1"));
    }
    
    @Test
    public void testAddMetadata() {
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        
        // Add metadata
        if (dto.getMetadata() == null) {
            dto.setMetadata(new HashMap<>());
        }
        dto.getMetadata().put("createdBy", "user1");
        
        assertEquals(1, dto.getMetadata().size());
        assertEquals("user1", dto.getMetadata().get("createdBy"));
    }
    
    @Test
    public void testAddInputData() {
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        
        // Add input data
        if (dto.getInputData() == null) {
            dto.setInputData(new HashMap<>());
        }
        dto.getInputData().put("key1", "value1");
        
        assertEquals(1, dto.getInputData().size());
        assertEquals("value1", dto.getInputData().get("key1"));
    }
    
    @Test
    public void testAddOutputData() {
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        
        // Add output data
        if (dto.getOutputData() == null) {
            dto.setOutputData(new HashMap<>());
        }
        dto.getOutputData().put("result", "success");
        
        assertEquals(1, dto.getOutputData().size());
        assertEquals("success", dto.getOutputData().get("result"));
    }
    
    @Test
    public void testCreateTaskGroup() {
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        
        Map<String, Object> properties = new HashMap<>();
        properties.put("assignees", List.of("user1", "user2"));
        
        // Create task group
        String taskGroupId = "tg-" + System.currentTimeMillis();
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        taskGroup.setId(taskGroupId);
        taskGroup.setType("HORIZONTAL");
        taskGroup.setName("Horizontal Task Group");
        taskGroup.setProperties(properties);
        
        if (dto.getTaskGroups() == null) {
            dto.setTaskGroups(new HashMap<>());
        }
        dto.getTaskGroups().put(taskGroupId, taskGroup);
        
        assertNotNull(taskGroupId);
        assertTrue(taskGroupId.startsWith("tg-"));
        assertEquals(1, dto.getTaskGroups().size());
        
        TaskGroupDTO retrievedTaskGroup = dto.getTaskGroups().get(taskGroupId);
        assertNotNull(retrievedTaskGroup);
        assertEquals("HORIZONTAL", retrievedTaskGroup.getType());
        assertEquals("Horizontal Task Group", retrievedTaskGroup.getName());
        assertEquals(properties, retrievedTaskGroup.getProperties());
    }
    
    @Test
    public void testCreateStandaloneTask() {
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        
        Map<String, Object> properties = new HashMap<>();
        properties.put("priority", "high");
        
        // Create standalone task
        String taskId = "task-" + System.currentTimeMillis();
        TaskDTO task = new TaskDTO();
        task.setId(taskId);
        task.setName("Review Document");
        task.setType("review");
        task.setAssignment("user1");
        task.setProperties(properties);
        
        if (dto.getStandaloneTasks() == null) {
            dto.setStandaloneTasks(new HashMap<>());
        }
        dto.getStandaloneTasks().put(taskId, task);
        
        assertNotNull(taskId);
        assertTrue(taskId.startsWith("task-"));
        assertEquals(1, dto.getStandaloneTasks().size());
        
        TaskDTO retrievedTask = dto.getStandaloneTasks().get(taskId);
        assertNotNull(retrievedTask);
        assertEquals("Review Document", retrievedTask.getName());
        assertEquals("review", retrievedTask.getType());
        assertEquals("user1", retrievedTask.getAssignment());
        assertEquals(properties, retrievedTask.getProperties());
    }
}
