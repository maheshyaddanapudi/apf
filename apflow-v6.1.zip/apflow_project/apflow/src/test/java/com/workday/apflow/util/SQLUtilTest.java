package com.workday.apflow.util;

import org.junit.jupiter.api.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class SQLUtilTest {

    @Test
    public void testBuildJsonSearch() {
        // Test with path
        String result = SQLUtil.buildJsonSearch("data", "user.name", "=", "John");
        assertEquals("data->'user.name' = 'John'::jsonb", result);
        
        // Test without path
        result = SQLUtil.buildJsonSearch("data", "", "=", "John");
        assertEquals("data = 'John'::jsonb", result);
        
        // Test with null path
        result = SQLUtil.buildJsonSearch("data", null, "=", "John");
        assertEquals("data = 'John'::jsonb", result);
    }
    
    @Test
    public void testBuildWhereClause() {
        // Test with conditions
        List<String> conditions = Arrays.asList("name = ?", "age > ?", "active = ?");
        List<Object> values = Arrays.asList("John", 30, true);
        
        String result = SQLUtil.buildWhereClause(conditions, values);
        assertEquals("WHERE name = ? AND age > ? AND active = ?", result);
        
        // Test with null value
        conditions = Arrays.asList("name = ?", "description = ?");
        values = Arrays.asList("John", null);
        
        result = SQLUtil.buildWhereClause(conditions, values);
        assertEquals("WHERE name = ? AND description IS NULL", result);
        
        // Test with not equal null
        conditions = Arrays.asList("name = ?", "description <> ?");
        values = Arrays.asList("John", null);
        
        result = SQLUtil.buildWhereClause(conditions, values);
        assertEquals("WHERE name = ? AND description IS NOT NULL", result);
        
        // Test with empty conditions
        conditions = new ArrayList<>();
        values = new ArrayList<>();
        
        result = SQLUtil.buildWhereClause(conditions, values);
        assertEquals("", result);
    }
    
    @Test
    public void testSetParameters() throws SQLException {
        // Create mock objects
        PreparedStatement stmt = mock(PreparedStatement.class);
        
        // Test with various types
        List<Object> values = new ArrayList<>();
        values.add("John");
        values.add(30);
        values.add(1000L);
        values.add(3.14);
        values.add(true);
        values.add(UUID.randomUUID());
        values.add(java.time.LocalDateTime.now());
        values.add(null); // Should be skipped
        
        // Execute the method
        SQLUtil.setParameters(stmt, values);
        
        // Verify the calls
        verify(stmt).setString(1, (String) values.get(0));
        verify(stmt).setInt(2, (Integer) values.get(1));
        verify(stmt).setLong(3, (Long) values.get(2));
        verify(stmt).setDouble(4, (Double) values.get(3));
        verify(stmt).setBoolean(5, (Boolean) values.get(4));
        verify(stmt).setObject(6, values.get(5));
        verify(stmt).setTimestamp(7, java.sql.Timestamp.valueOf((java.time.LocalDateTime) values.get(6)));
        // No verification for null value as it should be skipped
    }
    
    @Test
    public void testCreateInClause() {
        // Test with values
        List<Integer> values = Arrays.asList(1, 2, 3);
        String result = SQLUtil.createInClause("id", values);
        assertEquals("id IN (?, ?, ?)", result);
        
        // Test with empty list
        values = new ArrayList<>();
        result = SQLUtil.createInClause("id", values);
        assertEquals("1=0", result);
        
        // Test with null
        result = SQLUtil.createInClause("id", null);
        assertEquals("1=0", result);
    }
    
    @Test
    public void testGetJsonValue() throws SQLException {
        // Create mock objects
        ResultSet rs = mock(ResultSet.class);
        when(rs.getString("data")).thenReturn("{\"user\":{\"name\":\"John\",\"age\":30}}");
        
        // Test with valid path
        String result = SQLUtil.getJsonValue(rs, "data", "user.name");
        assertEquals("John", result);
        
        // Verify the call
        verify(rs).getString("data");
    }
    
    @Test
    public void testGetJsonValueWithNullJson() throws SQLException {
        // Create mock objects
        ResultSet rs = mock(ResultSet.class);
        when(rs.getString("data")).thenReturn(null);
        
        // Test with null JSON
        String result = SQLUtil.getJsonValue(rs, "data", "user.name");
        assertNull(result);
        
        // Verify the call
        verify(rs).getString("data");
    }
    
    @Test
    public void testGetJsonValueWithInvalidPath() throws SQLException {
        // Create mock objects
        ResultSet rs = mock(ResultSet.class);
        when(rs.getString("data")).thenReturn("{\"user\":{\"name\":\"John\",\"age\":30}}");
        
        // Test with invalid path
        String result = SQLUtil.getJsonValue(rs, "data", "user.address.street");
        assertNull(result);
        
        // Verify the call
        verify(rs).getString("data");
    }
    
    @Test
    public void testBuildPaginatedQuery() {
        // Test with all parameters
        String result = SQLUtil.buildPaginatedQuery(
            "SELECT * FROM users",
            "WHERE age > 18",
            "name ASC",
            10,
            20
        );
        assertEquals("SELECT * FROM users WHERE age > 18 ORDER BY name ASC LIMIT 10 OFFSET 20", result);
        
        // Test without where clause
        result = SQLUtil.buildPaginatedQuery(
            "SELECT * FROM users",
            "",
            "name ASC",
            10,
            20
        );
        assertEquals("SELECT * FROM users ORDER BY name ASC LIMIT 10 OFFSET 20", result);
        
        // Test without order by
        result = SQLUtil.buildPaginatedQuery(
            "SELECT * FROM users",
            "WHERE age > 18",
            "",
            10,
            20
        );
        assertEquals("SELECT * FROM users WHERE age > 18 LIMIT 10 OFFSET 20", result);
        
        // Test without limit
        result = SQLUtil.buildPaginatedQuery(
            "SELECT * FROM users",
            "WHERE age > 18",
            "name ASC",
            0,
            20
        );
        assertEquals("SELECT * FROM users WHERE age > 18 ORDER BY name ASC OFFSET 20", result);
        
        // Test without offset
        result = SQLUtil.buildPaginatedQuery(
            "SELECT * FROM users",
            "WHERE age > 18",
            "name ASC",
            10,
            0
        );
        assertEquals("SELECT * FROM users WHERE age > 18 ORDER BY name ASC LIMIT 10", result);
    }
    
    @Test
    public void testBuildBatchInsert() {
        // Test with columns
        List<String> columns = Arrays.asList("id", "name", "age");
        String result = SQLUtil.buildBatchInsert("users", columns, 2);
        assertEquals("INSERT INTO users (id, name, age) VALUES (?, ?, ?), (?, ?, ?)", result);
        
        // Test with single batch
        result = SQLUtil.buildBatchInsert("users", columns, 1);
        assertEquals("INSERT INTO users (id, name, age) VALUES (?, ?, ?)", result);
    }
    
    @Test
    public void testGetCount() throws SQLException {
        // Create mock objects
        Connection connection = mock(Connection.class);
        PreparedStatement stmt = mock(PreparedStatement.class);
        ResultSet rs = mock(ResultSet.class);
        
        when(connection.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(rs);
        when(rs.next()).thenReturn(true);
        when(rs.getInt(1)).thenReturn(42);
        
        // Test with count query
        int result = SQLUtil.getCount(connection, "SELECT COUNT(*) FROM users");
        assertEquals(42, result);
        
        // Verify the calls
        verify(connection).prepareStatement("SELECT COUNT(*) FROM users");
        verify(stmt).executeQuery();
        verify(rs).next();
        verify(rs).getInt(1);
    }
    
    @Test
    public void testGetCountWithNoResults() throws SQLException {
        // Create mock objects
        Connection connection = mock(Connection.class);
        PreparedStatement stmt = mock(PreparedStatement.class);
        ResultSet rs = mock(ResultSet.class);
        
        when(connection.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(rs);
        when(rs.next()).thenReturn(false);
        
        // Test with count query
        int result = SQLUtil.getCount(connection, "SELECT COUNT(*) FROM users");
        assertEquals(0, result);
        
        // Verify the calls
        verify(connection).prepareStatement("SELECT COUNT(*) FROM users");
        verify(stmt).executeQuery();
        verify(rs).next();
    }
    
    @Test
    public void testExecuteQuery() throws SQLException {
        // Create mock objects
        Connection connection = mock(Connection.class);
        PreparedStatement stmt = mock(PreparedStatement.class);
        ResultSet rs = mock(ResultSet.class);
        
        when(connection.prepareStatement(anyString())).thenReturn(stmt);
        when(stmt.executeQuery()).thenReturn(rs);
        when(rs.next()).thenReturn(true, true, false);
        when(rs.getString("name")).thenReturn("John", "Jane");
        
        // Test with query
        List<String> result = SQLUtil.executeQuery(connection, "SELECT name FROM users", 
            resultSet -> {
                try {
                    return resultSet.getString("name");
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            });
        
        assertEquals(2, result.size());
        assertEquals("John", result.get(0));
        assertEquals("Jane", result.get(1));
        
        // Verify the calls
        verify(connection).prepareStatement("SELECT name FROM users");
        verify(stmt).executeQuery();
        verify(rs, times(3)).next();
        verify(rs, times(2)).getString("name");
    }
}
