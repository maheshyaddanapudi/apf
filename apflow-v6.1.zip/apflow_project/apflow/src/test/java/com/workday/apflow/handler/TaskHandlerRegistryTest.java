package com.workday.apflow.handler;

import com.workday.apflow.constants.TaskConstants;
import com.workday.apflow.execution.ExecutionQueuingInterceptor;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TaskHandlerRegistryTest {

    @Mock
    private TaskHandler todoTaskHandler;
    
    private TaskHandlerRegistry taskHandlerRegistry;
    
    @BeforeEach
    void setUp() {
        taskHandlerRegistry = new TaskHandlerRegistry();
    }
    
    @Test
    void testRegisterHandler() {
        // Setup
        when(todoTaskHandler.getType()).thenReturn(TaskConstants.TYPE_TODO);
        
        // Execute
        taskHandlerRegistry.registerHandler(todoTaskHandler);
        
        // Verify
        TaskHandler result = taskHandlerRegistry.getHandler(TaskConstants.TYPE_TODO);
        assertNotNull(result);
        assertEquals(todoTaskHandler, result);
    }
    
    @Test
    void testGetHandler_NotFound() {
        // Execute
        TaskHandler result = taskHandlerRegistry.getHandler("NON_EXISTENT_TYPE");
        
        // Verify
        assertNull(result);
    }
    
    @Test
    void testGetHandler_Found() {
        // Setup
        when(todoTaskHandler.getType()).thenReturn(TaskConstants.TYPE_TODO);
        taskHandlerRegistry.registerHandler(todoTaskHandler);
        
        // Execute
        TaskHandler result = taskHandlerRegistry.getHandler(TaskConstants.TYPE_TODO);
        
        // Verify
        assertNotNull(result);
        assertEquals(todoTaskHandler, result);
    }
}
