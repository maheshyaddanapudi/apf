package com.workday.apflow.dao;

import com.workday.apflow.model.WorkflowHistory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class WorkflowHistoryDAOTest {

    private WorkflowHistoryDAO workflowHistoryDAO;

    @BeforeEach
    void setUp() {
        // Create a mock implementation of the WorkflowHistoryDAO interface
        workflowHistoryDAO = Mockito.mock(WorkflowHistoryDAO.class);
        
        // Setup mock behavior
        WorkflowHistory mockHistory = new WorkflowHistory();
        mockHistory.setWorkflowInstanceId(1);
        mockHistory.setEventType("WORKFLOW_STARTED");
        mockHistory.setEventDetails("{}");
        mockHistory.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        mockHistory.setCreatedBy("system");
        
        List<WorkflowHistory> workflowHistoryList = new ArrayList<>();
        workflowHistoryList.add(mockHistory);
        
        WorkflowHistory mockTaskHistory = new WorkflowHistory();
        mockTaskHistory.setTaskInstanceId(1);
        mockTaskHistory.setEventType("TASK_STARTED");
        mockTaskHistory.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        
        List<WorkflowHistory> taskHistoryList = new ArrayList<>();
        taskHistoryList.add(mockTaskHistory);
        
        when(workflowHistoryDAO.createHistoryRecord(any(WorkflowHistory.class))).thenReturn(1);
        when(workflowHistoryDAO.getHistoryForWorkflow(1)).thenReturn(workflowHistoryList);
        when(workflowHistoryDAO.getHistoryByWorkflowInstance(1)).thenReturn(workflowHistoryList);
        when(workflowHistoryDAO.getHistoryByTaskInstance(1)).thenReturn(taskHistoryList);
        when(workflowHistoryDAO.archiveOldHistory(any(LocalDateTime.class))).thenReturn(0);
    }

    @Test
    void testCreateHistoryRecord() {
        // Setup
        WorkflowHistory history = new WorkflowHistory();
        history.setWorkflowInstanceId(1);
        history.setEventType("WORKFLOW_STARTED");
        history.setEventDetails("{}");
        history.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        history.setCreatedBy("system");

        // Execute
        Integer id = workflowHistoryDAO.createHistoryRecord(history);

        // Verify
        assertNotNull(id);
        assertEquals(1, id.intValue());
        verify(workflowHistoryDAO).createHistoryRecord(history);
    }

    @Test
    void testGetHistoryForWorkflow() {
        // Setup
        Integer workflowInstanceId = 1;

        // Execute
        List<WorkflowHistory> historyList = workflowHistoryDAO.getHistoryForWorkflow(workflowInstanceId);

        // Verify
        assertNotNull(historyList);
        assertFalse(historyList.isEmpty());
        assertEquals(1, historyList.size());
        
        WorkflowHistory history = historyList.get(0);
        assertEquals(workflowInstanceId, history.getWorkflowInstanceId());
        assertEquals("WORKFLOW_STARTED", history.getEventType());
        assertNotNull(history.getCreatedAt());
        assertEquals("system", history.getCreatedBy());
        verify(workflowHistoryDAO).getHistoryForWorkflow(workflowInstanceId);
    }

    @Test
    void testGetHistoryByWorkflowInstance() {
        // Setup
        Integer workflowInstanceId = 1;

        // Execute
        List<WorkflowHistory> historyList = workflowHistoryDAO.getHistoryByWorkflowInstance(workflowInstanceId);

        // Verify
        assertNotNull(historyList);
        assertFalse(historyList.isEmpty());
        assertEquals(1, historyList.size());
        
        WorkflowHistory history = historyList.get(0);
        assertEquals(workflowInstanceId, history.getWorkflowInstanceId());
        assertEquals("WORKFLOW_STARTED", history.getEventType());
        verify(workflowHistoryDAO).getHistoryByWorkflowInstance(workflowInstanceId);
    }

    @Test
    void testGetHistoryByTaskInstance() {
        // Setup
        Integer taskInstanceId = 1;

        // Execute
        List<WorkflowHistory> historyList = workflowHistoryDAO.getHistoryByTaskInstance(taskInstanceId);

        // Verify
        assertNotNull(historyList);
        assertFalse(historyList.isEmpty());
        assertEquals(1, historyList.size());
        
        WorkflowHistory history = historyList.get(0);
        assertEquals(taskInstanceId, history.getTaskInstanceId());
        assertEquals("TASK_STARTED", history.getEventType());
        verify(workflowHistoryDAO).getHistoryByTaskInstance(taskInstanceId);
    }

    @Test
    void testArchiveOldHistory() {
        // Setup
        LocalDateTime olderThan = LocalDateTime.now().minusDays(30);

        // Execute
        int archivedCount = workflowHistoryDAO.archiveOldHistory(olderThan);

        // Verify
        assertEquals(0, archivedCount);
        verify(workflowHistoryDAO).archiveOldHistory(olderThan);
    }
}
