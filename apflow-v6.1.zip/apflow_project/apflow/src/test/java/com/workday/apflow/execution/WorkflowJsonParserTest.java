package com.workday.apflow.execution;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.workday.apflow.constants.WorkflowConstants;
import com.workday.apflow.dto.workflow.*;
import com.workday.apflow.util.JsonUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class WorkflowJsonParserTest {
    
    private String instanceJsonStr;
    private WorkflowInstanceDTO instanceDto;
    private ObjectMapper objectMapper = new ObjectMapper();
    private ObjectNode instanceJson;
    
    @BeforeEach
    void setUp() {
        // Setup JSON structure
        instanceJson = objectMapper.createObjectNode();
        instanceJson.put(WorkflowConstants.FIELD_CURRENT_POSITION, 0);
        
        // Add sequence
        ObjectNode taskGroupItem = objectMapper.createObjectNode();
        taskGroupItem.put(WorkflowConstants.FIELD_ID, "tg1");
        taskGroupItem.put(WorkflowConstants.FIELD_TYPE, WorkflowConstants.TYPE_TASK_GROUP);
        taskGroupItem.put("taskGroupType", "HORIZONTAL");
        
        instanceJson.set(WorkflowConstants.FIELD_SEQUENCE, objectMapper.createArrayNode().add(taskGroupItem));
        
        // Add task groups
        ObjectNode taskGroups = objectMapper.createObjectNode();
        ObjectNode taskGroup = objectMapper.createObjectNode();
        taskGroup.put(WorkflowConstants.FIELD_TYPE, "HORIZONTAL");
        taskGroup.put(WorkflowConstants.FIELD_NAME, "Test Task Group");
        taskGroup.put(WorkflowConstants.FIELD_INITIALIZED, true);
        taskGroups.set("tg1", taskGroup);
        instanceJson.set(WorkflowConstants.PROP_TASK_GROUPS, taskGroups);
        
        instanceJsonStr = JsonUtil.toString(instanceJson);
        
        // Create equivalent DTO structure
        instanceDto = new WorkflowInstanceDTO();
        instanceDto.setCurrentPosition(0);
        
        List<SequenceItemDTO> sequence = new ArrayList<>();
        TaskGroupSequenceItemDTO taskGroupItem1 = new TaskGroupSequenceItemDTO();
        taskGroupItem1.setId("tg1");
        taskGroupItem1.setType(WorkflowConstants.TYPE_TASK_GROUP);
        taskGroupItem1.setTaskGroupType("HORIZONTAL");
        sequence.add(taskGroupItem1);
        instanceDto.setSequence(sequence);
        
        Map<String, TaskGroupDTO> taskGroups1 = new HashMap<>();
        TaskGroupDTO taskGroupDto = new TaskGroupDTO();
        taskGroupDto.setId("tg1");
        taskGroupDto.setType("HORIZONTAL");
        taskGroupDto.setName("Test Task Group");
        taskGroupDto.setInitialized(true);
        taskGroups1.put("tg1", taskGroupDto);
        instanceDto.setTaskGroups(taskGroups1);
    }
    
    @Test
    void testParseInstanceJson() {
        // Execute
        WorkflowInstanceDTO result = WorkflowJsonParser.parseWorkflowInstance(instanceJsonStr);
        
        // Verify
        assertNotNull(result);
        assertEquals(0, result.getCurrentPosition());
        assertNotNull(result.getSequence());
        assertFalse(result.getSequence().isEmpty());
        assertNotNull(result.getTaskGroups());
        assertTrue(result.getTaskGroups().containsKey("tg1"));
    }
    
    @Test
    void testParseInstanceJson_NullJson() {
        // Execute
        WorkflowInstanceDTO result = WorkflowJsonParser.parseWorkflowInstance(null);
        
        // Verify
        assertNotNull(result);
        assertEquals(0, result.getCurrentPosition());
        assertNotNull(result.getSequence());
        assertTrue(result.getSequence().isEmpty());
    }
    
    @Test
    void testParseInstanceJson_EmptyJson() {
        // Execute
        WorkflowInstanceDTO result = WorkflowJsonParser.parseWorkflowInstance("");
        
        // Verify
        assertNotNull(result);
        assertEquals(0, result.getCurrentPosition());
        assertNotNull(result.getSequence());
        assertTrue(result.getSequence().isEmpty());
    }
    
    @Test
    void testParseInstanceJson_InvalidJson() {
        // Execute & Verify
        Exception exception = assertThrows(RuntimeException.class, () -> {
            WorkflowJsonParser.parseWorkflowInstance("invalid json");
        });
        
        assertTrue(exception.getMessage().contains("Error parsing workflow instance JSON"));
    }
    
    @Test
    void testSerializeWorkflowInstance() {
        // Execute
        String json = WorkflowJsonParser.serializeWorkflowInstance(instanceDto);
        
        // Verify
        assertNotNull(json);
        assertTrue(json.contains("\"currentPosition\":0"));
        assertTrue(json.contains("\"sequence\""));
        assertTrue(json.contains("\"taskGroups\""));
        assertTrue(json.contains("\"tg1\""));
    }
    
    @Test
    void testSerializeWorkflowInstance_WithStandaloneTasks() {
        // Setup
        Map<String, TaskDTO> standaloneTasks = new HashMap<>();
        TaskDTO taskDto = new TaskDTO();
        taskDto.setId("task1");
        taskDto.setName("Test Task");
        taskDto.setType("TODO");
        standaloneTasks.put("task1", taskDto);
        instanceDto.setStandaloneTasks(standaloneTasks);
        
        // Execute
        String json = WorkflowJsonParser.serializeWorkflowInstance(instanceDto);
        
        // Verify
        assertNotNull(json);
        assertTrue(json.contains("\"standaloneTasks\""));
        assertTrue(json.contains("\"task1\""));
    }
    
    @Test
    void testSerializeWorkflowInstance_NullDto() {
        // Execute & Verify
        Exception exception = assertThrows(RuntimeException.class, () -> {
            WorkflowJsonParser.serializeWorkflowInstance(null);
        });
        
        assertTrue(exception.getMessage().contains("Error serializing workflow instance DTO"));
    }
    
    @Test
    void testGetTaskGroup() {
        // Execute
        TaskGroupDTO result = WorkflowJsonParser.getTaskGroup(instanceDto, "tg1");
        
        // Verify
        assertNotNull(result);
        assertEquals("HORIZONTAL", result.getType());
        assertEquals("Test Task Group", result.getName());
    }
    
    @Test
    void testGetTaskGroup_NotFound() {
        // Execute
        TaskGroupDTO result = WorkflowJsonParser.getTaskGroup(instanceDto, "non_existent");
        
        // Verify
        assertNull(result);
    }
    
    @Test
    void testGetTaskGroup_NullTaskGroups() {
        // Setup
        instanceDto.setTaskGroups(null);
        
        // Execute
        TaskGroupDTO result = WorkflowJsonParser.getTaskGroup(instanceDto, "tg1");
        
        // Verify
        assertNull(result);
    }
    
    @Test
    void testGetStandaloneTask() {
        // Setup
        Map<String, TaskDTO> standaloneTasks = new HashMap<>();
        TaskDTO taskDto = new TaskDTO();
        taskDto.setId("task1");
        taskDto.setName("Test Task");
        taskDto.setType("TODO");
        standaloneTasks.put("task1", taskDto);
        instanceDto.setStandaloneTasks(standaloneTasks);
        
        // Execute
        TaskDTO result = WorkflowJsonParser.getStandaloneTask(instanceDto, "task1");
        
        // Verify
        assertNotNull(result);
        assertEquals("task1", result.getId());
        assertEquals("Test Task", result.getName());
        assertEquals("TODO", result.getType());
    }
    
    @Test
    void testGetStandaloneTask_NotFound() {
        // Setup
        Map<String, TaskDTO> standaloneTasks = new HashMap<>();
        instanceDto.setStandaloneTasks(standaloneTasks);
        
        // Execute
        TaskDTO result = WorkflowJsonParser.getStandaloneTask(instanceDto, "non_existent");
        
        // Verify
        assertNull(result);
    }
    
    @Test
    void testGetStandaloneTask_NullStandaloneTasks() {
        // Setup
        instanceDto.setStandaloneTasks(null);
        
        // Execute
        TaskDTO result = WorkflowJsonParser.getStandaloneTask(instanceDto, "task1");
        
        // Verify
        assertNull(result);
    }
    
    @Test
    void testParseInstanceJsonToNode() {
        // Execute
        JsonNode result = WorkflowJsonParser.parseInstanceJsonToNode(instanceJsonStr);
        
        // Verify
        assertNotNull(result);
        assertTrue(result.has(WorkflowConstants.FIELD_CURRENT_POSITION));
        assertTrue(result.has(WorkflowConstants.FIELD_SEQUENCE));
        assertTrue(result.has(WorkflowConstants.PROP_TASK_GROUPS));
    }
    
    @Test
    void testParseInstanceJsonToNode_NullJson() {
        // Execute
        JsonNode result = WorkflowJsonParser.parseInstanceJsonToNode(null);
        
        // Verify
        assertNotNull(result);
        assertTrue(result.isObject());
        assertEquals(0, result.size());
    }
    
    @Test
    void testParseInstanceJsonToNode_EmptyJson() {
        // Execute
        JsonNode result = WorkflowJsonParser.parseInstanceJsonToNode("");
        
        // Verify
        assertNotNull(result);
        assertTrue(result.isObject());
        assertEquals(0, result.size());
    }
    
    @Test
    void testParseInstanceJsonToNode_InvalidJson() {
        // Execute & Verify
        Exception exception = assertThrows(RuntimeException.class, () -> {
            WorkflowJsonParser.parseInstanceJsonToNode("invalid json");
        });
        
        assertTrue(exception.getMessage().contains("Error parsing instance JSON to node"));
    }
    
    @Test
    void testGetCurrentSequenceItem() {
        // Execute
        SequenceItemDTO item = WorkflowJsonParser.getCurrentSequenceItem(instanceDto);
        
        // Verify
        assertNotNull(item);
        assertTrue(item instanceof TaskGroupSequenceItemDTO);
        assertEquals("tg1", item.getId());
        assertEquals(WorkflowConstants.TYPE_TASK_GROUP, item.getType());
    }
    
    @Test
    void testGetCurrentSequenceItem_InvalidPosition() {
        // Setup
        instanceDto.setCurrentPosition(10); // Invalid position
        
        // Execute
        SequenceItemDTO item = WorkflowJsonParser.getCurrentSequenceItem(instanceDto);
        
        // Verify
        assertNull(item);
    }
    
    @Test
    void testGetCurrentSequenceItem_NegativePosition() {
        // Setup
        instanceDto.setCurrentPosition(-1); // Invalid position
        
        // Execute
        SequenceItemDTO item = WorkflowJsonParser.getCurrentSequenceItem(instanceDto);
        
        // Verify
        assertNull(item);
    }
    
    @Test
    void testGetCurrentSequenceItemFromDto_NullSequence() {
        // Setup
        instanceDto.setSequence(null);
        
        // Execute
        SequenceItemDTO item = WorkflowJsonParser.getCurrentSequenceItem(instanceDto);
        
        // Verify
        assertNull(item);
    }
    
    @Test
    void testGetCurrentSequenceItemFromDto_NullDto() {
        // Execute
        SequenceItemDTO item = WorkflowJsonParser.getCurrentSequenceItem((WorkflowInstanceDTO) null);
        
        // Verify
        assertNull(item);
    }
    
    @Test
    void testGetCurrentSequenceItemFromDto_NullPosition() {
        // Setup
        instanceDto.setCurrentPosition(null);
        
        // Execute
        SequenceItemDTO item = WorkflowJsonParser.getCurrentSequenceItem(instanceDto);
        
        // Verify
        assertNull(item);
    }
    
    @Test
    void testGetCurrentSequenceItemFromJson() {
        // Execute
        JsonNode item = WorkflowJsonParser.getCurrentSequenceItem(instanceJson);
        
        // Verify
        assertNotNull(item);
        assertEquals(WorkflowConstants.TYPE_TASK_GROUP, item.get(WorkflowConstants.FIELD_TYPE).asText());
        assertEquals("tg1", item.get(WorkflowConstants.FIELD_ID).asText());
    }
    
    @Test
    void testGetCurrentSequenceItemFromJson_InvalidPosition() {
        // Setup
        ((ObjectNode) instanceJson).put(WorkflowConstants.FIELD_CURRENT_POSITION, 10); // Invalid position
        
        // Execute
        JsonNode item = WorkflowJsonParser.getCurrentSequenceItem(instanceJson);
        
        // Verify
        assertNull(item);
    }
    
    @Test
    void testGetCurrentSequenceItemFromJson_NullJson() {
        // Execute
        JsonNode item = WorkflowJsonParser.getCurrentSequenceItem((JsonNode) null);
        
        // Verify
        assertNull(item);
    }
    
    @Test
    void testGetCurrentSequenceItemFromJson_NoSequence() {
        // Setup
        ObjectNode jsonWithoutSequence = objectMapper.createObjectNode();
        jsonWithoutSequence.put(WorkflowConstants.FIELD_CURRENT_POSITION, 0);
        
        // Execute
        JsonNode item = WorkflowJsonParser.getCurrentSequenceItem(jsonWithoutSequence);
        
        // Verify
        assertNull(item);
    }
    
    @Test
    void testGetCurrentSequenceItemFromJson_NoPosition() {
        // Setup
        ObjectNode jsonWithoutPosition = objectMapper.createObjectNode();
        jsonWithoutPosition.set(WorkflowConstants.FIELD_SEQUENCE, objectMapper.createArrayNode());
        
        // Execute
        JsonNode item = WorkflowJsonParser.getCurrentSequenceItem(jsonWithoutPosition);
        
        // Verify
        assertNull(item);
    }
    
    @Test
    void testGetTaskGroupState() {
        // Execute
        TaskGroupDTO taskGroupDto = WorkflowJsonParser.getTaskGroupState(instanceDto, "tg1");
        
        // Verify
        assertNotNull(taskGroupDto);
        assertEquals("HORIZONTAL", taskGroupDto.getType());
        assertEquals("Test Task Group", taskGroupDto.getName());
    }
    
    @Test
    void testGetTaskGroupState_NotFound() {
        // Execute
        TaskGroupDTO taskGroupDto = WorkflowJsonParser.getTaskGroupState(instanceDto, "non_existent");
        
        // Verify
        assertNull(taskGroupDto);
    }
    
    @Test
    void testGetTaskGroupStateFromJson() {
        // Execute
        JsonNode taskGroupState = WorkflowJsonParser.getTaskGroupState(instanceJson, "tg1");
        
        // Verify
        assertNotNull(taskGroupState);
        assertEquals("HORIZONTAL", taskGroupState.get(WorkflowConstants.FIELD_TYPE).asText());
        assertEquals("Test Task Group", taskGroupState.get(WorkflowConstants.FIELD_NAME).asText());
    }
    
    @Test
    void testGetTaskGroupStateFromJson_NotFound() {
        // Execute
        JsonNode taskGroupState = WorkflowJsonParser.getTaskGroupState(instanceJson, "non_existent");
        
        // Verify
        assertNull(taskGroupState);
    }
    
    @Test
    void testGetTaskGroupStateFromJson_NullJson() {
        // Execute
        JsonNode taskGroupState = WorkflowJsonParser.getTaskGroupState((JsonNode) null, "tg1");
        
        // Verify
        assertNull(taskGroupState);
    }
    
    @Test
    void testGetTaskGroupStateFromJson_NoTaskGroups() {
        // Setup
        ObjectNode jsonWithoutTaskGroups = objectMapper.createObjectNode();
        
        // Execute
        JsonNode taskGroupState = WorkflowJsonParser.getTaskGroupState(jsonWithoutTaskGroups, "tg1");
        
        // Verify
        assertNull(taskGroupState);
    }
}
