package com.workday.apflow.dto.request;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TaskInstanceRequestTest {

    @Test
    void testDefaultConstructor() {
        TaskInstanceRequest request = new TaskInstanceRequest();
        assertNotNull(request);
        assertNull(request.getWorkflowInstanceId());
        assertNull(request.getName());
        assertNull(request.getType());
        assertNull(request.getAssignment());
        assertNull(request.getOperatorId());
        assertNull(request.getOperatorType());
        assertNull(request.getInputJson());
    }

    @Test
    void testGettersAndSetters() {
        TaskInstanceRequest request = new TaskInstanceRequest();
        
        // Test workflowInstanceId
        Integer workflowInstanceId = 123;
        request.setWorkflowInstanceId(workflowInstanceId);
        assertEquals(workflowInstanceId, request.getWorkflowInstanceId());
        
        // Test name
        String name = "Test Task";
        request.setName(name);
        assertEquals(name, request.getName());
        
        // Test type
        String type = "APPROVAL";
        request.setType(type);
        assertEquals(type, request.getType());
        
        // Test assignment
        String assignment = "user123";
        request.setAssignment(assignment);
        assertEquals(assignment, request.getAssignment());
        
        // Test operatorId
        String operatorId = "op456";
        request.setOperatorId(operatorId);
        assertEquals(operatorId, request.getOperatorId());
        
        // Test operatorType
        String operatorType = "FORK";
        request.setOperatorType(operatorType);
        assertEquals(operatorType, request.getOperatorType());
        
        // Test inputJson
        String inputJson = "{\"key\":\"value\"}";
        request.setInputJson(inputJson);
        assertEquals(inputJson, request.getInputJson());
    }

    @Test
    void testEqualsAndHashCode() {
        TaskInstanceRequest request1 = new TaskInstanceRequest();
        request1.setWorkflowInstanceId(123);
        request1.setName("Test Task");
        request1.setType("APPROVAL");
        request1.setAssignment("user123");
        request1.setOperatorId("op456");
        request1.setOperatorType("FORK");
        request1.setInputJson("{\"key\":\"value\"}");
        
        TaskInstanceRequest request2 = new TaskInstanceRequest();
        request2.setWorkflowInstanceId(123);
        request2.setName("Test Task");
        request2.setType("APPROVAL");
        request2.setAssignment("user123");
        request2.setOperatorId("op456");
        request2.setOperatorType("FORK");
        request2.setInputJson("{\"key\":\"value\"}");
        
        TaskInstanceRequest request3 = new TaskInstanceRequest();
        request3.setWorkflowInstanceId(456); // Different ID
        request3.setName("Test Task");
        request3.setType("APPROVAL");
        request3.setAssignment("user123");
        request3.setOperatorId("op456");
        request3.setOperatorType("FORK");
        request3.setInputJson("{\"key\":\"value\"}");
        
        // Test equals
        assertEquals(request1, request1); // Same object
        assertEquals(request1, request2); // Equal objects
        assertNotEquals(request1, request3); // Different workflowInstanceId
        assertNotEquals(request1, null); // Null
        assertNotEquals(request1, new Object()); // Different class
        
        // Test hashCode
        assertEquals(request1.hashCode(), request2.hashCode());
        assertNotEquals(request1.hashCode(), request3.hashCode());
    }

    @Test
    void testToString() {
        TaskInstanceRequest request = new TaskInstanceRequest();
        request.setWorkflowInstanceId(123);
        request.setName("Test Task");
        request.setType("APPROVAL");
        request.setAssignment("user123");
        request.setOperatorId("op456");
        request.setOperatorType("FORK");
        request.setInputJson("{\"key\":\"value\"}");
        
        String toString = request.toString();
        assertNotNull(toString);
        assertTrue(toString.contains("123"));
        assertTrue(toString.contains("Test Task"));
        assertTrue(toString.contains("APPROVAL"));
        assertTrue(toString.contains("user123"));
        assertTrue(toString.contains("op456"));
        assertTrue(toString.contains("FORK"));
        assertTrue(toString.contains("{\"key\":\"value\"}"));
    }

    @Test
    void testBuilder() {
        TaskInstanceRequest request = TaskInstanceRequest.builder()
            .workflowInstanceId(123)
            .name("Test Task")
            .type("APPROVAL")
            .assignment("user123")
            .operatorId("op456")
            .operatorType("FORK")
            .inputJson("{\"key\":\"value\"}")
            .build();
        
        assertNotNull(request);
        assertEquals(123, request.getWorkflowInstanceId());
        assertEquals("Test Task", request.getName());
        assertEquals("APPROVAL", request.getType());
        assertEquals("user123", request.getAssignment());
        assertEquals("op456", request.getOperatorId());
        assertEquals("FORK", request.getOperatorType());
        assertEquals("{\"key\":\"value\"}", request.getInputJson());
    }
}
