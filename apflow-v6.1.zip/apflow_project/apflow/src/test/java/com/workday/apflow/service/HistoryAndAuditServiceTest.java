package com.workday.apflow.service;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.workday.apflow.dao.WorkflowHistoryDAO;
import com.workday.apflow.model.WorkflowHistory;
import com.workday.apflow.util.JsonUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class HistoryAndAuditServiceTest {

    @Mock
    private WorkflowHistoryDAO historyDAO;
    
    private HistoryAndAuditService historyAndAuditService;
    
    @BeforeEach
    void setUp() {
        historyAndAuditService = new HistoryAndAuditService(historyDAO);
    }
    
    @Test
    void testAddWorkflowHistory() {
        // Setup
        Integer workflowInstanceId = 1;
        String eventType = "WORKFLOW_STARTED";
        ObjectNode detailsJson = JsonUtil.createObjectNode().put("key", "value");
        String username = "test-user";
        
        when(historyDAO.createHistoryRecord(any(WorkflowHistory.class))).thenReturn(1);
        
        // Execute
        WorkflowHistory result = historyAndAuditService.addWorkflowHistory(workflowInstanceId, eventType, detailsJson, username);
        
        // Verify
        assertNotNull(result);
        assertEquals(workflowInstanceId, result.getWorkflowInstanceId());
        assertEquals(eventType, result.getEventType());
        verify(historyDAO, times(1)).createHistoryRecord(any(WorkflowHistory.class));
    }
    
    @Test
    void testAddTaskHistory() {
        // Setup
        Integer workflowInstanceId = 1;
        Integer taskId = 2;
        String eventType = "TASK_STARTED";
        ObjectNode detailsJson = JsonUtil.createObjectNode().put("key", "value");
        String username = "test-user";
        
        when(historyDAO.createHistoryRecord(any(WorkflowHistory.class))).thenReturn(1);
        
        // Execute
        WorkflowHistory result = historyAndAuditService.addTaskHistory(workflowInstanceId, taskId, eventType, detailsJson, username);
        
        // Verify
        assertNotNull(result);
        assertEquals(workflowInstanceId, result.getWorkflowInstanceId());
        assertEquals(taskId, result.getTaskInstanceId());
        assertEquals(eventType, result.getEventType());
        verify(historyDAO, times(1)).createHistoryRecord(any(WorkflowHistory.class));
    }
    
    @Test
    void testGetHistoryForWorkflow() {
        // Setup
        Integer workflowInstanceId = 1;
        List<WorkflowHistory> historyList = new ArrayList<>();
        WorkflowHistory history = new WorkflowHistory();
        history.setId(1);
        history.setWorkflowInstanceId(workflowInstanceId);
        historyList.add(history);
        
        when(historyDAO.getHistoryForWorkflow(workflowInstanceId)).thenReturn(historyList);
        
        // Execute
        List<WorkflowHistory> result = historyAndAuditService.getHistoryForWorkflow(workflowInstanceId);
        
        // Verify
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(workflowInstanceId, result.get(0).getWorkflowInstanceId());
        verify(historyDAO, times(1)).getHistoryForWorkflow(workflowInstanceId);
    }
    
    @Test
    void testArchiveOldHistory() {
        // Setup
        LocalDateTime olderThan = LocalDateTime.now().minusDays(30);
        int archivedCount = 10;
        
        when(historyDAO.archiveOldHistory(olderThan)).thenReturn(archivedCount);
        
        // Execute
        int result = historyAndAuditService.archiveOldHistory(olderThan);
        
        // Verify
        assertEquals(archivedCount, result);
        verify(historyDAO, times(1)).archiveOldHistory(olderThan);
    }
}
