package com.workday.apflow.dto;

import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

public class UserDTOTest {

    @Test
    public void testDefaultConstructor() {
        UserDTO userDTO = new UserDTO();
        
        assertNotNull(userDTO);
        assertNull(userDTO.getId());
        assertNull(userDTO.getUsername());
        assertNull(userDTO.getDisplayName());
        assertNull(userDTO.getEmail());
        assertNull(userDTO.getDepartment());
    }
    
    @Test
    public void testParameterizedConstructor() {
        UUID id = UUID.randomUUID();
        String username = "johndoe";
        String displayName = "John Doe";
        String email = "john.doe@example.com";
        
        UserDTO userDTO = new UserDTO(id, username, displayName, email);
        
        assertEquals(id, userDTO.getId());
        assertEquals(username, userDTO.getUsername());
        assertEquals(displayName, userDTO.getDisplayName());
        assertEquals(email, userDTO.getEmail());
        assertNull(userDTO.getDepartment());
    }
    
    @Test
    public void testSettersAndGetters() {
        UserDTO userDTO = new UserDTO();
        
        UUID id = UUID.randomUUID();
        String username = "johndoe";
        String displayName = "John Doe";
        String email = "john.doe@example.com";
        String department = "Engineering";
        
        userDTO.setId(id);
        userDTO.setUsername(username);
        userDTO.setDisplayName(displayName);
        userDTO.setEmail(email);
        userDTO.setDepartment(department);
        
        assertEquals(id, userDTO.getId());
        assertEquals(username, userDTO.getUsername());
        assertEquals(displayName, userDTO.getDisplayName());
        assertEquals(email, userDTO.getEmail());
        assertEquals(department, userDTO.getDepartment());
    }
    
    @Test
    public void testEqualsAndHashCode() {
        UUID id1 = UUID.fromString("00000000-0000-0000-0000-000000000001");
        UUID id2 = UUID.fromString("00000000-0000-0000-0000-000000000002");
        
        UserDTO userDTO1 = new UserDTO(id1, "johndoe", "John Doe", "john.doe@example.com");
        UserDTO userDTO2 = new UserDTO(id1, "johndoe", "John Doe", "john.doe@example.com");
        UserDTO userDTO3 = new UserDTO(id2, "janedoe", "Jane Doe", "jane.doe@example.com");
        
        // Test reflexivity
        assertEquals(userDTO1, userDTO1);
        
        // Test symmetry
        assertEquals(userDTO1, userDTO2);
        assertEquals(userDTO2, userDTO1);
        
        // Test transitivity
        assertNotEquals(userDTO1, userDTO3);
        assertNotEquals(userDTO2, userDTO3);
        
        // Test null and different class
        assertNotEquals(userDTO1, null);
        assertNotEquals(userDTO1, new Object());
        
        // Test hashCode
        assertEquals(userDTO1.hashCode(), userDTO1.hashCode());
        assertEquals(userDTO1.hashCode(), userDTO2.hashCode());
        assertNotEquals(userDTO1.hashCode(), userDTO3.hashCode());
    }
}
