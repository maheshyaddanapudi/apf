package com.workday.apflow.dao;
import com.workday.apflow.model.TaskInstance;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
public class TaskInstanceDAOTest {
    @Mock
    private TaskInstanceDAO taskInstanceDAO;
    
    @BeforeEach
    void setUp() {
        // Using mock instead of direct instantiation since TaskInstanceDAO is abstract
    }
    
    @Test
    void testCreateTaskInstance() {
        // Setup
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setName("Test Task");
        taskInstance.setType("TODO");
        taskInstance.setStatus("PENDING");
        
        TaskInstance expected = new TaskInstance();
        expected.setId(1);
        expected.setName("Test Task");
        expected.setType("TODO");
        expected.setStatus("PENDING");
        
        when(taskInstanceDAO.createTaskInstance(taskInstance)).thenReturn(expected);
        
        // Execute
        TaskInstance result = taskInstanceDAO.createTaskInstance(taskInstance);
        
        // Verify
        assertNotNull(result);
        assertNotNull(result.getId());
        assertEquals("Test Task", result.getName());
        verify(taskInstanceDAO).createTaskInstance(taskInstance);
    }
    
    @Test
    void testGetTaskInstance() {
        // Setup
        Integer taskInstanceId = 1;
        TaskInstance expected = new TaskInstance();
        expected.setId(taskInstanceId);
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(expected);
        
        // Execute
        TaskInstance result = taskInstanceDAO.getTaskInstance(taskInstanceId);
        
        // Verify
        assertNotNull(result);
        assertEquals(taskInstanceId, result.getId());
        verify(taskInstanceDAO).getTaskInstance(taskInstanceId);
    }
    
    @Test
    void testGetTaskInstancesByWorkflowInstance() {
        // Setup
        Integer workflowInstanceId = 1;
        List<TaskInstance> expected = new ArrayList<>();
        expected.add(new TaskInstance());
        
        when(taskInstanceDAO.getTaskInstancesByWorkflowInstance(workflowInstanceId)).thenReturn(expected);
        
        // Execute
        List<TaskInstance> result = taskInstanceDAO.getTaskInstancesByWorkflowInstance(workflowInstanceId);
        
        // Verify
        assertNotNull(result);
        verify(taskInstanceDAO).getTaskInstancesByWorkflowInstance(workflowInstanceId);
    }
    
    @Test
    void testGetTaskInstancesByStatus() {
        // Setup
        String status = "PENDING";
        List<TaskInstance> expected = new ArrayList<>();
        expected.add(new TaskInstance());
        
        when(taskInstanceDAO.getTaskInstancesByStatus(status)).thenReturn(expected);
        
        // Execute
        List<TaskInstance> result = taskInstanceDAO.getTaskInstancesByStatus(status);
        
        // Verify
        assertNotNull(result);
        verify(taskInstanceDAO).getTaskInstancesByStatus(status);
    }
    
    @Test
    void testGetTaskInstancesByAssignment() {
        // Setup
        String assignment = "test-user";
        List<TaskInstance> expected = new ArrayList<>();
        expected.add(new TaskInstance());
        
        when(taskInstanceDAO.getTaskInstancesByAssignment(assignment)).thenReturn(expected);
        
        // Execute
        List<TaskInstance> result = taskInstanceDAO.getTaskInstancesByAssignment(assignment);
        
        // Verify
        assertNotNull(result);
        verify(taskInstanceDAO).getTaskInstancesByAssignment(assignment);
    }
    
    @Test
    void testUpdateTaskInstance() {
        // Setup
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(1);
        taskInstance.setName("Test Task");
        taskInstance.setStatus("COMPLETED");
        
        when(taskInstanceDAO.updateTaskInstance(taskInstance)).thenReturn(taskInstance);
        
        // Execute
        TaskInstance result = taskInstanceDAO.updateTaskInstance(taskInstance);
        
        // Verify
        assertNotNull(result);
        assertEquals(1, result.getId());
        assertEquals("COMPLETED", result.getStatus());
        verify(taskInstanceDAO).updateTaskInstance(taskInstance);
    }
    
    @Test
    void testDeleteTaskInstance() {
        // Setup
        Integer taskInstanceId = 1;
        
        // Execute
        taskInstanceDAO.deleteTaskInstance(taskInstanceId);
        
        // Verify
        verify(taskInstanceDAO).deleteTaskInstance(taskInstanceId);
    }
}
