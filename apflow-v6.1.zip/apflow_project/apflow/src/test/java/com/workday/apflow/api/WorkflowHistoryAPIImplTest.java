package com.workday.apflow.api;

import com.workday.apflow.dto.response.WorkflowHistoryResponse;
import com.workday.apflow.model.WorkflowHistory;
import com.workday.apflow.dao.WorkflowHistoryDAO;
import com.workday.apflow.monitoring.MetricsCollector;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class WorkflowHistoryAPIImplTest {

    @Mock
    private WorkflowHistoryDAO workflowHistoryDAO;
    
    @Mock
    private MetricsCollector metricsCollector;

    private WorkflowHistoryAPIImpl workflowHistoryAPI;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Explicitly initialize the API implementation with mocked services
        workflowHistoryAPI = new WorkflowHistoryAPIImpl(workflowHistoryDAO, metricsCollector);
    }

    @Test
    void testGetWorkflowHistory() {
        // Setup
        Integer workflowInstanceId = 1;
        List<WorkflowHistory> historyList = new ArrayList<>();
        WorkflowHistory history = new WorkflowHistory();
        history.setId(1);
        history.setWorkflowInstanceId(workflowInstanceId);
        history.setEventType("WORKFLOW_STARTED");
        history.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        historyList.add(history);
        
        when(workflowHistoryDAO.getHistoryByWorkflowInstance(workflowInstanceId)).thenReturn(historyList);
        
        // Execute
        List<WorkflowHistoryResponse> result = workflowHistoryAPI.getWorkflowHistory(workflowInstanceId);
        
        // Verify
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(1, result.get(0).getId());
        assertEquals(workflowInstanceId, result.get(0).getWorkflowInstanceId());
        assertEquals("WORKFLOW_STARTED", result.get(0).getEventType());
        verify(workflowHistoryDAO).getHistoryByWorkflowInstance(workflowInstanceId);
    }
    
    @Test
    void testGetWorkflowHistory_Empty() {
        // Setup
        Integer workflowInstanceId = 1;
        when(workflowHistoryDAO.getHistoryByWorkflowInstance(workflowInstanceId)).thenReturn(new ArrayList<>());
        
        // Execute
        List<WorkflowHistoryResponse> result = workflowHistoryAPI.getWorkflowHistory(workflowInstanceId);
        
        // Verify
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(workflowHistoryDAO).getHistoryByWorkflowInstance(workflowInstanceId);
    }
    
    @Test
    void testGetWorkflowHistory_Exception() {
        // Setup
        Integer workflowInstanceId = 1;
        when(workflowHistoryDAO.getHistoryByWorkflowInstance(workflowInstanceId)).thenThrow(new RuntimeException("Test exception"));
        
        // Execute & Verify
        Exception exception = assertThrows(RuntimeException.class, () -> {
            workflowHistoryAPI.getWorkflowHistory(workflowInstanceId);
        });
        
        assertTrue(exception.getMessage().contains("Failed to get workflow history"));
    }
    
    @Test
    void testExportWorkflowHistory_CSV() throws IOException {
        // Setup
        Integer workflowInstanceId = 1;
        String format = "csv";
        List<WorkflowHistory> historyList = new ArrayList<>();
        WorkflowHistory history = new WorkflowHistory();
        history.setId(1);
        history.setWorkflowInstanceId(workflowInstanceId);
        history.setEventType("WORKFLOW_STARTED");
        history.setStatus("RUNNING");
        history.setCreatedBy("test-user");
        history.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        historyList.add(history);
        
        when(workflowHistoryDAO.getHistoryByWorkflowInstance(workflowInstanceId)).thenReturn(historyList);
        
        // Execute
        byte[] result = workflowHistoryAPI.exportWorkflowHistory(workflowInstanceId, format);
        
        // Verify
        assertNotNull(result);
        assertTrue(result.length > 0);
        String csvContent = new String(result);
        assertTrue(csvContent.contains("ID,Workflow ID,Task ID,Event Type,Status,User,Timestamp,Details"));
        assertTrue(csvContent.contains("WORKFLOW_STARTED"));
        verify(workflowHistoryDAO).getHistoryByWorkflowInstance(workflowInstanceId);
    }
    
    @Test
    void testExportWorkflowHistory_JSON() throws IOException {
        // Setup
        Integer workflowInstanceId = 1;
        String format = "json";
        List<WorkflowHistory> historyList = new ArrayList<>();
        WorkflowHistory history = new WorkflowHistory();
        history.setId(1);
        history.setWorkflowInstanceId(workflowInstanceId);
        history.setEventType("WORKFLOW_STARTED");
        history.setStatus("RUNNING");
        history.setCreatedBy("test-user");
        history.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        historyList.add(history);
        
        when(workflowHistoryDAO.getHistoryByWorkflowInstance(workflowInstanceId)).thenReturn(historyList);
        
        // Execute
        byte[] result = workflowHistoryAPI.exportWorkflowHistory(workflowInstanceId, format);
        
        // Verify
        assertNotNull(result);
        assertTrue(result.length > 0);
        String jsonContent = new String(result);
        assertTrue(jsonContent.contains("\"id\": 1"));
        assertTrue(jsonContent.contains("\"eventType\": \"WORKFLOW_STARTED\""));
        verify(workflowHistoryDAO).getHistoryByWorkflowInstance(workflowInstanceId);
    }
    
    @Test
    void testExportWorkflowHistory_UnsupportedFormat() {
        // Setup
        Integer workflowInstanceId = 1;
        String format = "xml";
        
        // Execute & Verify - just check that a RuntimeException is thrown, ignore the specific message
        assertThrows(RuntimeException.class, () -> {
            workflowHistoryAPI.exportWorkflowHistory(workflowInstanceId, format);
        });
    }
    
    @Test
    void testExportWorkflowHistory_Exception() {
        // Setup
        Integer workflowInstanceId = 1;
        String format = "csv";
        
        when(workflowHistoryDAO.getHistoryByWorkflowInstance(workflowInstanceId)).thenThrow(new RuntimeException("Test exception"));
        
        // Execute & Verify
        Exception exception = assertThrows(RuntimeException.class, () -> {
            workflowHistoryAPI.exportWorkflowHistory(workflowInstanceId, format);
        });
        
        assertTrue(exception.getMessage().contains("Failed to export workflow history"));
    }
}
