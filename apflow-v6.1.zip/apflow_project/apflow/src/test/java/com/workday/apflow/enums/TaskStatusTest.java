package com.workday.apflow.enums;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TaskStatusTest {

    @Test
    void testEnumValues() {
        // Verify all expected enum values exist
        assertEquals(11, TaskStatus.values().length);
        
        assertEquals(TaskStatus.NOT_STARTED, TaskStatus.valueOf("NOT_STARTED"));
        assertEquals(TaskStatus.IN_PROGRESS, TaskStatus.valueOf("IN_PROGRESS"));
        assertEquals(TaskStatus.COMPLETED, TaskStatus.valueOf("COMPLETED"));
        assertEquals(TaskStatus.SUBMITTED, TaskStatus.valueOf("SUBMITTED"));
        assertEquals(TaskStatus.APPROVED, TaskStatus.valueOf("APPROVED"));
        assertEquals(TaskStatus.REVIEWED, TaskStatus.valueOf("REVIEWED"));
        assertEquals(TaskStatus.API_CALL_COMPLETE, TaskStatus.valueOf("API_CALL_COMPLETE"));
        assertEquals(TaskStatus.FAILED, TaskStatus.valueOf("FAILED"));
        assertEquals(TaskStatus.EXPIRED, TaskStatus.valueOf("EXPIRED"));
        assertEquals(TaskStatus.SKIPPED, TaskStatus.valueOf("SKIPPED"));
        assertEquals(TaskStatus.BLOCKED, TaskStatus.valueOf("BLOCKED"));
    }
    
    @Test
    void testEnumOrdinals() {
        // Verify ordinal values
        assertEquals(0, TaskStatus.NOT_STARTED.ordinal());
        assertEquals(1, TaskStatus.IN_PROGRESS.ordinal());
        assertEquals(2, TaskStatus.COMPLETED.ordinal());
        assertEquals(3, TaskStatus.SUBMITTED.ordinal());
        assertEquals(4, TaskStatus.APPROVED.ordinal());
        assertEquals(5, TaskStatus.REVIEWED.ordinal());
        assertEquals(6, TaskStatus.API_CALL_COMPLETE.ordinal());
        assertEquals(7, TaskStatus.FAILED.ordinal());
        assertEquals(8, TaskStatus.EXPIRED.ordinal());
        assertEquals(9, TaskStatus.SKIPPED.ordinal());
        assertEquals(10, TaskStatus.BLOCKED.ordinal());
    }
    
    @Test
    void testToString() {
        // Verify toString representation
        assertEquals("NOT_STARTED", TaskStatus.NOT_STARTED.toString());
        assertEquals("IN_PROGRESS", TaskStatus.IN_PROGRESS.toString());
        assertEquals("COMPLETED", TaskStatus.COMPLETED.toString());
        assertEquals("SUBMITTED", TaskStatus.SUBMITTED.toString());
        assertEquals("APPROVED", TaskStatus.APPROVED.toString());
        assertEquals("REVIEWED", TaskStatus.REVIEWED.toString());
        assertEquals("API_CALL_COMPLETE", TaskStatus.API_CALL_COMPLETE.toString());
        assertEquals("FAILED", TaskStatus.FAILED.toString());
        assertEquals("EXPIRED", TaskStatus.EXPIRED.toString());
        assertEquals("SKIPPED", TaskStatus.SKIPPED.toString());
        assertEquals("BLOCKED", TaskStatus.BLOCKED.toString());
    }
}
