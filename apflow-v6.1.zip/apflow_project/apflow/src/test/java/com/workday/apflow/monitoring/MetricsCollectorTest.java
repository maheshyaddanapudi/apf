package com.workday.apflow.monitoring;

import com.workday.apflow.dto.response.MetricsResponse;
import com.workday.apflow.dto.response.SlaStatusResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class MetricsCollectorTest {

    private MetricsCollector metricsCollector;

    @BeforeEach
    public void setUp() {
        metricsCollector = new MetricsCollector();
    }

    @Test
    public void testGetWorkflowMetrics() {
        // Arrange
        Integer workflowInstanceId = 123;

        // Act
        MetricsResponse response = metricsCollector.getWorkflowMetrics(workflowInstanceId);

        // Assert
        assertNotNull(response);
        assertEquals(workflowInstanceId, response.getWorkflowInstanceId());
        assertNotNull(response.getMetrics());
        
        Map<String, Object> metrics = response.getMetrics();
        assertTrue(metrics.containsKey("executionTime"));
        assertTrue(metrics.containsKey("taskCount"));
        assertTrue(metrics.containsKey("completedTaskCount"));
        assertTrue(metrics.containsKey("averageTaskTime"));
        assertTrue(metrics.containsKey("errorCount"));
        
        assertEquals(1250, metrics.get("executionTime"));
        assertEquals(5, metrics.get("taskCount"));
        assertEquals(3, metrics.get("completedTaskCount"));
        assertEquals(350, metrics.get("averageTaskTime"));
        assertEquals(0, metrics.get("errorCount"));
    }

    @Test
    public void testGetSlaStatus() {
        // Arrange
        Integer workflowInstanceId = 123;
        long currentTime = System.currentTimeMillis();

        // Act
        SlaStatusResponse response = metricsCollector.getSlaStatus(workflowInstanceId);

        // Assert
        assertNotNull(response);
        assertEquals(workflowInstanceId, response.getWorkflowInstanceId());
        assertEquals("ON_TRACK", response.getStatus());
        
        // Time assertions - these are approximate due to execution time differences
        assertTrue(response.getTargetCompletionTime() > currentTime);
        assertTrue(response.getEstimatedCompletionTime() > currentTime);
        assertTrue(response.getTargetCompletionTime() > response.getEstimatedCompletionTime());
        assertEquals(900000L, response.getElapsedTime());
    }

    @Test
    public void testRecordWorkflowEvent() {
        // This is a void method that just logs to console, so we're just testing it doesn't throw exceptions
        Integer workflowInstanceId = 123;
        String eventType = "COMPLETED";
        long duration = 1500L;

        // Act & Assert - no exception should be thrown
        assertDoesNotThrow(() -> metricsCollector.recordWorkflowEvent(workflowInstanceId, eventType, duration));
    }

    @Test
    public void testRecordTaskEvent() {
        // This is a void method that just logs to console, so we're just testing it doesn't throw exceptions
        Integer taskInstanceId = 456;
        String eventType = "STARTED";
        long duration = 0L;

        // Act & Assert - no exception should be thrown
        assertDoesNotThrow(() -> metricsCollector.recordTaskEvent(taskInstanceId, eventType, duration));
    }
}
