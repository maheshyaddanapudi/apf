package com.workday.apflow.handler;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TaskGroupHandlerRegistryTest {

    private TaskGroupHandlerRegistry registry;

    @Mock
    private TaskGroupHandler mockHandler1;

    @Mock
    private TaskGroupHandler mockHandler2;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        registry = new TaskGroupHandlerRegistry();
        
        when(mockHandler1.getType()).thenReturn("HORIZONTAL");
        when(mockHandler2.getType()).thenReturn("VERTICAL");
    }

    @Test
    void testRegisterHandler() {
        // Execute
        registry.registerHandler(mockHandler1);
        
        // Verify
        assertTrue(registry.hasHandler("HORIZONTAL"));
        assertSame(mockHandler1, registry.getHandler("HORIZONTAL"));
    }

    @Test
    void testRegisterMultipleHandlers() {
        // Execute
        registry.registerHandler(mockHandler1);
        registry.registerHandler(mockHandler2);
        
        // Verify
        assertTrue(registry.hasHandler("HORIZONTAL"));
        assertTrue(registry.hasHandler("VERTICAL"));
        assertSame(mockHandler1, registry.getHandler("HORIZONTAL"));
        assertSame(mockHandler2, registry.getHandler("VERTICAL"));
    }

    @Test
    void testGetHandlerNotFound() {
        // Execute & Verify
        assertNull(registry.getHandler("UNKNOWN"));
    }

    @Test
    void testHasHandlerTrue() {
        // Setup
        registry.registerHandler(mockHandler1);
        
        // Execute & Verify
        assertTrue(registry.hasHandler("HORIZONTAL"));
    }

    @Test
    void testHasHandlerFalse() {
        // Execute & Verify
        assertFalse(registry.hasHandler("HORIZONTAL"));
    }

    @Test
    void testGetAllHandlers() {
        // Setup
        registry.registerHandler(mockHandler1);
        registry.registerHandler(mockHandler2);
        
        // Execute
        Map<String, TaskGroupHandler> handlers = registry.getAllHandlers();
        
        // Verify
        assertNotNull(handlers);
        assertEquals(2, handlers.size());
        assertTrue(handlers.containsKey("HORIZONTAL"));
        assertTrue(handlers.containsKey("VERTICAL"));
        assertSame(mockHandler1, handlers.get("HORIZONTAL"));
        assertSame(mockHandler2, handlers.get("VERTICAL"));
    }

    @Test
    void testGetAllHandlersEmpty() {
        // Execute
        Map<String, TaskGroupHandler> handlers = registry.getAllHandlers();
        
        // Verify
        assertNotNull(handlers);
        assertTrue(handlers.isEmpty());
    }

    @Test
    void testGetAllHandlersIsDefensiveCopy() {
        // Setup
        registry.registerHandler(mockHandler1);
        
        // Execute
        Map<String, TaskGroupHandler> handlers = registry.getAllHandlers();
        handlers.clear(); // Modify the returned map
        
        // Verify the original registry is not affected
        assertTrue(registry.hasHandler("HORIZONTAL"));
    }
}
