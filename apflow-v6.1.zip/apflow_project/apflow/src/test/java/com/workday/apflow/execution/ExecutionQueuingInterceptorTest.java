package com.workday.apflow.execution;

import com.workday.apflow.constants.QueueConstants;
import com.workday.apflow.dao.WorkflowExecutionQueueDAO;
import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.model.WorkflowExecutionQueue;
import com.workday.apflow.model.WorkflowInstance;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ExecutionQueuingInterceptorTest {

    @Mock
    private WorkflowExecutionQueueDAO queueDAO;
    
    private ExecutionQueuingInterceptor interceptor;
    
    @BeforeEach
    void setUp() {
        interceptor = new ExecutionQueuingInterceptor(queueDAO);
    }
    
    @Test
    void testInterceptTaskCompletion_NewEntry() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        task.setWorkflowInstanceId(101);
        
        // No existing entry
        when(queueDAO.getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING))
            .thenReturn(null);
        
        WorkflowExecutionQueue createdEntry = new WorkflowExecutionQueue();
        createdEntry.setId(1);
        when(queueDAO.createQueueEntry(any(WorkflowExecutionQueue.class))).thenReturn(createdEntry);
        
        // Execute
        WorkflowExecutionQueue result = interceptor.interceptTaskCompletion(task);
        
        // Verify
        verify(queueDAO).getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING);
        verify(queueDAO).createQueueEntry(any(WorkflowExecutionQueue.class));
        verify(queueDAO, never()).updateQueueEntry(any(WorkflowExecutionQueue.class));
        
        assertTrue(result.isNewlyCreated());
        assertEquals(1, result.getId());
    }
    
    @Test
    void testInterceptTaskCompletion_ExistingEntry() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        task.setWorkflowInstanceId(101);
        
        // Existing entry
        WorkflowExecutionQueue existingEntry = new WorkflowExecutionQueue();
        existingEntry.setId(1);
        existingEntry.setWorkflowInstanceId(101);
        existingEntry.setStatus(QueueConstants.STATUS_PENDING);
        
        when(queueDAO.getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING))
            .thenReturn(existingEntry);
        
        when(queueDAO.updateQueueEntry(any(WorkflowExecutionQueue.class))).thenReturn(existingEntry);
        
        // Execute
        WorkflowExecutionQueue result = interceptor.interceptTaskCompletion(task);
        
        // Verify
        verify(queueDAO).getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING);
        verify(queueDAO, never()).createQueueEntry(any(WorkflowExecutionQueue.class));
        verify(queueDAO).updateQueueEntry(any(WorkflowExecutionQueue.class));
        
        assertFalse(result.isNewlyCreated());
        assertEquals(1, result.getId());
        assertNotNull(result.getUpdatedAt());
    }
    
    @Test
    void testInterceptWorkflowResume_NewEntry() {
        // Setup
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(101);
        
        // No existing entry
        when(queueDAO.getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING))
            .thenReturn(null);
        
        WorkflowExecutionQueue createdEntry = new WorkflowExecutionQueue();
        createdEntry.setId(1);
        when(queueDAO.createQueueEntry(any(WorkflowExecutionQueue.class))).thenReturn(createdEntry);
        
        // Execute
        WorkflowExecutionQueue result = interceptor.interceptWorkflowResume(workflow);
        
        // Verify
        verify(queueDAO).getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING);
        verify(queueDAO).createQueueEntry(any(WorkflowExecutionQueue.class));
        verify(queueDAO, never()).updateQueueEntry(any(WorkflowExecutionQueue.class));
        
        assertTrue(result.isNewlyCreated());
        assertEquals(1, result.getId());
    }
    
    @Test
    void testInterceptWorkflowResume_ExistingEntry() {
        // Setup
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(101);
        
        // Existing entry
        WorkflowExecutionQueue existingEntry = new WorkflowExecutionQueue();
        existingEntry.setId(1);
        existingEntry.setWorkflowInstanceId(101);
        existingEntry.setStatus(QueueConstants.STATUS_PENDING);
        
        when(queueDAO.getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING))
            .thenReturn(existingEntry);
        
        when(queueDAO.updateQueueEntry(any(WorkflowExecutionQueue.class))).thenReturn(existingEntry);
        
        // Execute
        WorkflowExecutionQueue result = interceptor.interceptWorkflowResume(workflow);
        
        // Verify
        verify(queueDAO).getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING);
        verify(queueDAO, never()).createQueueEntry(any(WorkflowExecutionQueue.class));
        verify(queueDAO).updateQueueEntry(any(WorkflowExecutionQueue.class));
        
        assertFalse(result.isNewlyCreated());
        assertEquals(1, result.getId());
        assertNotNull(result.getUpdatedAt());
    }
    
    @Test
    void testInterceptTaskRetry_NewEntry() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        task.setWorkflowInstanceId(101);
        
        // No existing entry
        when(queueDAO.getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING))
            .thenReturn(null);
        
        WorkflowExecutionQueue createdEntry = new WorkflowExecutionQueue();
        createdEntry.setId(1);
        createdEntry.setTaskInstanceId(1);
        createdEntry.setType(QueueConstants.TYPE_TASK_RETRY);
        when(queueDAO.createQueueEntry(any(WorkflowExecutionQueue.class))).thenAnswer(invocation -> {
            WorkflowExecutionQueue entry = invocation.getArgument(0);
            entry.setId(1);
            return entry;
        });
        
        // Execute
        WorkflowExecutionQueue result = interceptor.interceptTaskRetry(task);
        
        // Verify
        verify(queueDAO).getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING);
        verify(queueDAO).createQueueEntry(any(WorkflowExecutionQueue.class));
        verify(queueDAO, never()).updateQueueEntry(any(WorkflowExecutionQueue.class));
        
        assertTrue(result.isNewlyCreated());
        assertEquals(1, result.getId());
        assertEquals(1, result.getTaskInstanceId());
        assertEquals(QueueConstants.TYPE_TASK_RETRY, result.getType());
    }
    
    @Test
    void testInterceptTaskRetry_ExistingEntry() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        task.setWorkflowInstanceId(101);
        
        // Existing entry
        WorkflowExecutionQueue existingEntry = new WorkflowExecutionQueue();
        existingEntry.setId(1);
        existingEntry.setWorkflowInstanceId(101);
        existingEntry.setStatus(QueueConstants.STATUS_PENDING);
        
        when(queueDAO.getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING))
            .thenReturn(existingEntry);
        
        when(queueDAO.updateQueueEntry(any(WorkflowExecutionQueue.class))).thenAnswer(invocation -> {
            WorkflowExecutionQueue entry = invocation.getArgument(0);
            entry.setTaskInstanceId(1);
            entry.setType(QueueConstants.TYPE_TASK_RETRY);
            return entry;
        });
        
        // Execute
        WorkflowExecutionQueue result = interceptor.interceptTaskRetry(task);
        
        // Verify
        verify(queueDAO).getQueueEntryByWorkflowInstanceIdAndStatus(101, QueueConstants.STATUS_PENDING);
        verify(queueDAO, never()).createQueueEntry(any(WorkflowExecutionQueue.class));
        verify(queueDAO).updateQueueEntry(any(WorkflowExecutionQueue.class));
        
        assertFalse(result.isNewlyCreated());
        assertEquals(1, result.getId());
        assertEquals(1, result.getTaskInstanceId());
        assertEquals(QueueConstants.TYPE_TASK_RETRY, result.getType());
        assertNotNull(result.getUpdatedAt());
    }
}
