package com.workday.apflow.monitoring;

import org.junit.jupiter.api.Test;
import java.sql.Timestamp;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

class AuditEventTest {

    @Test
    void testDefaultConstructor() {
        AuditEvent auditEvent = new AuditEvent();
        assertNotNull(auditEvent);
        assertNull(auditEvent.getId());
        assertNull(auditEvent.getEventType());
        assertNull(auditEvent.getEventDetails());
        assertNull(auditEvent.getUserId());
        assertNull(auditEvent.getTimestamp());
        assertNull(auditEvent.getWorkflowInstanceId());
        assertNull(auditEvent.getTaskInstanceId());
    }

    @Test
    void testSetAndGetId() {
        AuditEvent auditEvent = new AuditEvent();
        Integer id = 123;
        auditEvent.setId(id);
        assertEquals(id, auditEvent.getId());
    }

    @Test
    void testSetAndGetEventType() {
        AuditEvent auditEvent = new AuditEvent();
        String eventType = "WORKFLOW_CREATED";
        auditEvent.setEventType(eventType);
        assertEquals(eventType, auditEvent.getEventType());
    }

    @Test
    void testSetAndGetEventDetails() {
        AuditEvent auditEvent = new AuditEvent();
        String eventDetails = "Workflow created with ID 123";
        auditEvent.setEventDetails(eventDetails);
        assertEquals(eventDetails, auditEvent.getEventDetails());
    }

    @Test
    void testSetAndGetUserId() {
        AuditEvent auditEvent = new AuditEvent();
        String userId = "user123";
        auditEvent.setUserId(userId);
        assertEquals(userId, auditEvent.getUserId());
    }

    @Test
    void testSetAndGetTimestamp() {
        AuditEvent auditEvent = new AuditEvent();
        Timestamp timestamp = Timestamp.from(Instant.now());
        auditEvent.setTimestamp(timestamp);
        assertEquals(timestamp, auditEvent.getTimestamp());
    }

    @Test
    void testSetAndGetWorkflowInstanceId() {
        AuditEvent auditEvent = new AuditEvent();
        Integer workflowInstanceId = 456;
        auditEvent.setWorkflowInstanceId(workflowInstanceId);
        assertEquals(workflowInstanceId, auditEvent.getWorkflowInstanceId());
    }

    @Test
    void testSetAndGetTaskInstanceId() {
        AuditEvent auditEvent = new AuditEvent();
        Integer taskInstanceId = 789;
        auditEvent.setTaskInstanceId(taskInstanceId);
        assertEquals(taskInstanceId, auditEvent.getTaskInstanceId());
    }

    @Test
    void testToString() {
        AuditEvent auditEvent = new AuditEvent();
        auditEvent.setId(123);
        auditEvent.setEventType("WORKFLOW_CREATED");
        auditEvent.setEventDetails("Workflow created with ID 123");
        auditEvent.setUserId("user123");
        Timestamp timestamp = Timestamp.valueOf("2025-04-03 12:00:00");
        auditEvent.setTimestamp(timestamp);
        auditEvent.setWorkflowInstanceId(456);
        auditEvent.setTaskInstanceId(789);
        
        String expected = "AuditEvent{" +
                "id=123" +
                ", eventType='WORKFLOW_CREATED'" +
                ", eventDetails='Workflow created with ID 123'" +
                ", userId='user123'" +
                ", timestamp=" + timestamp +
                ", workflowInstanceId=456" +
                ", taskInstanceId=789" +
                '}';
        
        assertEquals(expected, auditEvent.toString());
    }
}
