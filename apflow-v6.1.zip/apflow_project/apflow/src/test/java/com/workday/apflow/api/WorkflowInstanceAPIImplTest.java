package com.workday.apflow.api;

import com.workday.apflow.dto.request.WorkflowInstanceRequest;
import com.workday.apflow.dto.response.WorkflowInstanceResponse;
import com.workday.apflow.model.WorkflowInstance;
import com.workday.apflow.service.WorkflowInstanceService;
import com.workday.apflow.service.WorkflowControlService;
import com.workday.apflow.dao.WorkflowInstanceDAO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class WorkflowInstanceAPIImplTest {

    @Mock
    private WorkflowControlService workflowControlService;

    @Mock
    private WorkflowInstanceDAO workflowInstanceDAO;
    
    @Mock
    private WorkflowInstanceService workflowInstanceService;

    private WorkflowInstanceAPIImpl workflowInstanceAPI;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        // Explicitly initialize the API implementation with mocked services
        workflowInstanceAPI = new WorkflowInstanceAPIImpl(workflowInstanceService, workflowControlService);
    }

    @Test
    void testGetWorkflowInstance() {
        // Setup
        Integer workflowId = 123;
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowId);
        workflow.setName("Test Workflow");
        workflow.setStatus("RUNNING");

        when(workflowInstanceService.getWorkflowInstance(workflowId)).thenReturn(workflow);

        // Execute
        WorkflowInstanceResponse response = workflowInstanceAPI.getWorkflowInstance(workflowId);

        // Verify
        assertNotNull(response);
        assertEquals(workflowId, response.getId());
        assertEquals("Test Workflow", response.getName());
        assertEquals("RUNNING", response.getStatus());
        verify(workflowInstanceService).getWorkflowInstance(workflowId);
    }

    @Test
    void testGetWorkflowInstanceNotFound() {
        // Setup
        Integer workflowId = 123;
        when(workflowInstanceService.getWorkflowInstance(workflowId)).thenReturn(null);

        // Execute
        WorkflowInstanceResponse response = workflowInstanceAPI.getWorkflowInstance(workflowId);

        // Verify
        assertNull(response);
        verify(workflowInstanceService).getWorkflowInstance(workflowId);
    }

    @Test
    void testGetAllWorkflowInstances() {
        // Setup
        List<WorkflowInstance> workflows = new ArrayList<>();
        WorkflowInstance workflow1 = new WorkflowInstance();
        workflow1.setId(1);
        workflow1.setName("Workflow 1");
        workflow1.setStatus("COMPLETED");

        WorkflowInstance workflow2 = new WorkflowInstance();
        workflow2.setId(2);
        workflow2.setName("Workflow 2");
        workflow2.setStatus("RUNNING");

        workflows.add(workflow1);
        workflows.add(workflow2);

        when(workflowInstanceService.getAllWorkflowInstances()).thenReturn(workflows);

        // Execute
        List<WorkflowInstanceResponse> responses = workflowInstanceAPI.getAllWorkflowInstances();

        // Verify
        assertNotNull(responses);
        assertEquals(2, responses.size());
        assertEquals(1, responses.get(0).getId());
        assertEquals("Workflow 1", responses.get(0).getName());
        assertEquals("COMPLETED", responses.get(0).getStatus());
        assertEquals(2, responses.get(1).getId());
        assertEquals("Workflow 2", responses.get(1).getName());
        assertEquals("RUNNING", responses.get(1).getStatus());
        verify(workflowInstanceService).getAllWorkflowInstances();
    }

    @Test
    void testGetAllWorkflowInstancesEmpty() {
        // Setup
        when(workflowInstanceService.getAllWorkflowInstances()).thenReturn(new ArrayList<>());

        // Execute
        List<WorkflowInstanceResponse> responses = workflowInstanceAPI.getAllWorkflowInstances();

        // Verify
        assertNotNull(responses);
        assertTrue(responses.isEmpty());
        verify(workflowInstanceService).getAllWorkflowInstances();
    }

    @Test
    void testUpdateWorkflowInstance() {
        // Setup
        Integer workflowId = 123;
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        request.setName("Updated Workflow");

        WorkflowInstance updatedWorkflow = new WorkflowInstance();
        updatedWorkflow.setId(workflowId);
        updatedWorkflow.setName("Updated Workflow");
        updatedWorkflow.setStatus("RUNNING");

        when(workflowInstanceService.getWorkflowInstance(workflowId)).thenReturn(updatedWorkflow);
        when(workflowControlService.updateWorkflow(eq(workflowId), any())).thenReturn(updatedWorkflow);

        // Execute
        WorkflowInstanceResponse response = workflowInstanceAPI.updateWorkflowInstance(workflowId, request);

        // Verify
        assertNotNull(response);
        assertEquals(workflowId, response.getId());
        assertEquals("Updated Workflow", response.getName());
        assertEquals("RUNNING", response.getStatus());
        verify(workflowControlService).updateWorkflow(eq(workflowId), any());
    }

    @Test
    void testGetWorkflowInstancesByStatus() {
        // Setup
        String status = "RUNNING";
        List<WorkflowInstance> workflows = new ArrayList<>();
        WorkflowInstance workflow1 = new WorkflowInstance();
        workflow1.setId(1);
        workflow1.setName("Workflow 1");
        workflow1.setStatus(status);

        WorkflowInstance workflow2 = new WorkflowInstance();
        workflow2.setId(2);
        workflow2.setName("Workflow 2");
        workflow2.setStatus(status);

        workflows.add(workflow1);
        workflows.add(workflow2);

        when(workflowInstanceService.getWorkflowInstancesByStatus(status)).thenReturn(workflows);

        // Execute
        List<WorkflowInstanceResponse> responses = workflowInstanceAPI.getWorkflowInstancesByStatus(status);

        // Verify
        assertNotNull(responses);
        assertEquals(2, responses.size());
        assertEquals(1, responses.get(0).getId());
        assertEquals("Workflow 1", responses.get(0).getName());
        assertEquals(status, responses.get(0).getStatus());
        assertEquals(2, responses.get(1).getId());
        assertEquals("Workflow 2", responses.get(1).getName());
        assertEquals(status, responses.get(1).getStatus());
        verify(workflowInstanceService).getWorkflowInstancesByStatus(status);
    }

    @Test
    void testGetWorkflowInstancesByStatusEmpty() {
        // Setup
        String status = "FAILED";
        when(workflowInstanceService.getWorkflowInstancesByStatus(status)).thenReturn(new ArrayList<>());

        // Execute
        List<WorkflowInstanceResponse> responses = workflowInstanceAPI.getWorkflowInstancesByStatus(status);

        // Verify
        assertNotNull(responses);
        assertTrue(responses.isEmpty());
        verify(workflowInstanceService).getWorkflowInstancesByStatus(status);
    }
}
