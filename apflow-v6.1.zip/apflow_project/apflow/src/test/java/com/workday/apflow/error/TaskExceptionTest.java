package com.workday.apflow.error;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class TaskExceptionTest {

    @Test
    void testConstructorWithMessageAndErrorDetails() {
        // Setup
        String message = "Task execution failed";
        String errorCode = "TASK-001";
        String errorType = "EXECUTION_ERROR";
        boolean recoverable = true;
        
        // Execute
        TaskException exception = new TaskException(message, errorCode, errorType, recoverable);
        
        // Verify
        assertEquals(message, exception.getMessage());
        assertEquals(errorCode, exception.getErrorCode());
        assertEquals(errorType, exception.getErrorType());
        assertEquals(String.valueOf(recoverable), exception.getRecoverable());
        assertNull(exception.getTaskInstanceId());
    }
    
    @Test
    void testConstructorWithMessageErrorDetailsAndTaskId() {
        // Setup
        String message = "Task execution failed";
        String errorCode = "TASK-001";
        String errorType = "EXECUTION_ERROR";
        boolean recoverable = true;
        Integer taskInstanceId = 123;
        
        // Execute
        TaskException exception = new TaskException(message, errorCode, errorType, recoverable, taskInstanceId);
        
        // Verify
        assertEquals(message, exception.getMessage());
        assertEquals(errorCode, exception.getErrorCode());
        assertEquals(errorType, exception.getErrorType());
        assertEquals(String.valueOf(recoverable), exception.getRecoverable());
        assertEquals(taskInstanceId, exception.getTaskInstanceId());
    }
    
    @Test
    void testConstructorWithCauseAndErrorDetails() {
        // Setup
        String message = "Task execution failed";
        Throwable cause = new RuntimeException("Original error");
        String errorCode = "TASK-001";
        String errorType = "EXECUTION_ERROR";
        boolean recoverable = true;
        
        // Execute
        TaskException exception = new TaskException(message, cause, errorCode, errorType, recoverable);
        
        // Verify
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
        assertEquals(errorCode, exception.getErrorCode());
        assertEquals(errorType, exception.getErrorType());
        assertEquals(String.valueOf(recoverable), exception.getRecoverable());
        assertNull(exception.getTaskInstanceId());
    }
    
    @Test
    void testConstructorWithCauseErrorDetailsAndTaskId() {
        // Setup
        String message = "Task execution failed";
        Throwable cause = new RuntimeException("Original error");
        String errorCode = "TASK-001";
        String errorType = "EXECUTION_ERROR";
        boolean recoverable = true;
        Integer taskInstanceId = 123;
        
        // Execute
        TaskException exception = new TaskException(message, cause, errorCode, errorType, recoverable, taskInstanceId);
        
        // Verify
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
        assertEquals(errorCode, exception.getErrorCode());
        assertEquals(errorType, exception.getErrorType());
        assertEquals(String.valueOf(recoverable), exception.getRecoverable());
        assertEquals(taskInstanceId, exception.getTaskInstanceId());
    }
    
    @Test
    void testInheritanceFromWorkflowException() {
        // Setup
        TaskException exception = new TaskException("Task execution failed", "TASK-001", "EXECUTION_ERROR", true);
        
        // Verify
        assertTrue(exception instanceof WorkflowException);
    }
    
    @Test
    void testToString() {
        // Setup
        String message = "Task execution failed";
        String errorCode = "TASK-001";
        String errorType = "EXECUTION_ERROR";
        boolean recoverable = true;
        Integer taskInstanceId = 123;
        
        TaskException exception = new TaskException(message, errorCode, errorType, recoverable, taskInstanceId);
        
        // Execute
        String result = exception.toString();
        
        // Verify
        assertNotNull(result);
        assertTrue(result.contains(message));
    }
    
    @Test
    void testRecoverableAndNonRecoverableExceptions() {
        // Setup
        TaskException recoverableException = new TaskException("Recoverable error", "TASK-001", "TEMPORARY_ERROR", true);
        TaskException nonRecoverableException = new TaskException("Non-recoverable error", "TASK-002", "FATAL_ERROR", false);
        
        // Verify
        assertEquals("true", recoverableException.getRecoverable());
        assertEquals("false", nonRecoverableException.getRecoverable());
    }
    
    @Test
    void testDifferentErrorTypes() {
        // Setup
        TaskException validationException = new TaskException("Validation error", "TASK-001", "VALIDATION_ERROR", true);
        TaskException timeoutException = new TaskException("Timeout error", "TASK-002", "TIMEOUT_ERROR", false);
        TaskException authorizationException = new TaskException("Authorization error", "TASK-003", "AUTHORIZATION_ERROR", false);
        
        // Verify
        assertEquals("VALIDATION_ERROR", validationException.getErrorType());
        assertEquals("TIMEOUT_ERROR", timeoutException.getErrorType());
        assertEquals("AUTHORIZATION_ERROR", authorizationException.getErrorType());
    }
    
    @Test
    void testDifferentErrorCodes() {
        // Setup
        TaskException exception1 = new TaskException("Error 1", "TASK-001", "ERROR", true);
        TaskException exception2 = new TaskException("Error 2", "TASK-002", "ERROR", true);
        TaskException exception3 = new TaskException("Error 3", "TASK-003", "ERROR", true);
        
        // Verify
        assertEquals("TASK-001", exception1.getErrorCode());
        assertEquals("TASK-002", exception2.getErrorCode());
        assertEquals("TASK-003", exception3.getErrorCode());
    }
    
    @Test
    void testNullTaskInstanceId() {
        // Setup
        TaskException exception = new TaskException("Task execution failed", "TASK-001", "EXECUTION_ERROR", true);
        
        // Verify
        assertNull(exception.getTaskInstanceId());
    }
}
