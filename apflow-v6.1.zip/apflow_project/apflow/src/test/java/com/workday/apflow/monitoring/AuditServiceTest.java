package com.workday.apflow.monitoring;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;

import java.sql.Timestamp;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class AuditServiceTest {

    private AuditService auditService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        auditService = new AuditService();
    }

    @Test
    void testRecordEvent() {
        // Setup
        AuditEvent event = new AuditEvent();
        event.setEventType("TEST_EVENT");
        event.setEventDetails("Test event details");
        event.setUserId("user123");
        event.setTimestamp(Timestamp.from(Instant.now()));
        event.setWorkflowInstanceId(123);
        
        // Execute
        auditService.recordEvent(event);
        
        // Verify
        List<AuditEvent> events = auditService.getEventsByWorkflowInstance(123);
        assertNotNull(events);
        assertEquals(1, events.size());
        assertEquals("TEST_EVENT", events.get(0).getEventType());
        assertEquals("Test event details", events.get(0).getEventDetails());
        assertEquals("user123", events.get(0).getUserId());
        assertEquals(123, events.get(0).getWorkflowInstanceId());
    }

    @Test
    void testRecordWorkflowEvent() {
        // Execute
        auditService.recordWorkflowEvent(123, "WORKFLOW_CREATED", "Workflow created", "user123");
        
        // Verify
        List<AuditEvent> events = auditService.getEventsByWorkflowInstance(123);
        assertNotNull(events);
        assertEquals(1, events.size());
        assertEquals("WORKFLOW_CREATED", events.get(0).getEventType());
        assertEquals("Workflow created", events.get(0).getEventDetails());
        assertEquals("user123", events.get(0).getUserId());
        assertEquals(123, events.get(0).getWorkflowInstanceId());
        assertNotNull(events.get(0).getTimestamp());
    }

    @Test
    void testRecordTaskEvent() {
        // Execute
        auditService.recordTaskEvent(456, "TASK_COMPLETED", "Task completed", "user123");
        
        // Verify
        List<AuditEvent> events = auditService.getEventsByTaskInstance(456);
        assertNotNull(events);
        assertEquals(1, events.size());
        assertEquals("TASK_COMPLETED", events.get(0).getEventType());
        assertEquals("Task completed", events.get(0).getEventDetails());
        assertEquals("user123", events.get(0).getUserId());
        assertEquals(456, events.get(0).getTaskInstanceId());
        assertNotNull(events.get(0).getTimestamp());
    }

    @Test
    void testGetEventsByWorkflowInstance() {
        // Setup
        auditService.recordWorkflowEvent(123, "WORKFLOW_CREATED", "Workflow created", "user123");
        auditService.recordWorkflowEvent(123, "WORKFLOW_STARTED", "Workflow started", "user123");
        auditService.recordWorkflowEvent(456, "WORKFLOW_CREATED", "Another workflow created", "user456");
        
        // Execute
        List<AuditEvent> events = auditService.getEventsByWorkflowInstance(123);
        
        // Verify
        assertNotNull(events);
        assertEquals(2, events.size());
        assertEquals("WORKFLOW_CREATED", events.get(0).getEventType());
        assertEquals("WORKFLOW_STARTED", events.get(1).getEventType());
    }

    @Test
    void testGetEventsByTaskInstance() {
        // Setup
        auditService.recordTaskEvent(123, "TASK_CREATED", "Task created", "user123");
        auditService.recordTaskEvent(123, "TASK_STARTED", "Task started", "user123");
        auditService.recordTaskEvent(456, "TASK_CREATED", "Another task created", "user456");
        
        // Execute
        List<AuditEvent> events = auditService.getEventsByTaskInstance(123);
        
        // Verify
        assertNotNull(events);
        assertEquals(2, events.size());
        assertEquals("TASK_CREATED", events.get(0).getEventType());
        assertEquals("TASK_STARTED", events.get(1).getEventType());
    }

    @Test
    void testGetEventsByDateRange() {
        // Setup
        Timestamp now = Timestamp.from(Instant.now());
        Timestamp yesterday = Timestamp.from(Instant.now().minus(1, ChronoUnit.DAYS));
        Timestamp tomorrow = Timestamp.from(Instant.now().plus(1, ChronoUnit.DAYS));
        
        AuditEvent event1 = new AuditEvent();
        event1.setEventType("EVENT_1");
        event1.setTimestamp(yesterday);
        
        AuditEvent event2 = new AuditEvent();
        event2.setEventType("EVENT_2");
        event2.setTimestamp(now);
        
        AuditEvent event3 = new AuditEvent();
        event3.setEventType("EVENT_3");
        event3.setTimestamp(tomorrow);
        
        auditService.recordEvent(event1);
        auditService.recordEvent(event2);
        auditService.recordEvent(event3);
        
        // Execute
        List<AuditEvent> events = auditService.getEventsByDateRange(yesterday, now);
        
        // Verify
        assertNotNull(events);
        assertEquals(2, events.size());
        assertEquals("EVENT_1", events.get(0).getEventType());
        assertEquals("EVENT_2", events.get(1).getEventType());
    }

    @Test
    void testGetEventsByUser() {
        // Setup
        auditService.recordWorkflowEvent(123, "WORKFLOW_CREATED", "Workflow created", "user123");
        auditService.recordWorkflowEvent(456, "WORKFLOW_CREATED", "Another workflow created", "user456");
        auditService.recordTaskEvent(789, "TASK_CREATED", "Task created", "user123");
        
        // Execute
        List<AuditEvent> events = auditService.getEventsByUser("user123");
        
        // Verify
        assertNotNull(events);
        assertEquals(2, events.size());
    }

    @Test
    void testGetEventsByType() {
        // Setup
        auditService.recordWorkflowEvent(123, "WORKFLOW_CREATED", "Workflow created", "user123");
        auditService.recordWorkflowEvent(456, "WORKFLOW_STARTED", "Workflow started", "user456");
        auditService.recordTaskEvent(789, "WORKFLOW_CREATED", "Task with workflow type", "user123");
        
        // Execute
        List<AuditEvent> events = auditService.getEventsByType("WORKFLOW_CREATED");
        
        // Verify
        assertNotNull(events);
        assertEquals(2, events.size());
    }
}
