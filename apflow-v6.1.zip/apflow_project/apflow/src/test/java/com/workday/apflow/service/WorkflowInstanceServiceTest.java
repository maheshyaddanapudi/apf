package com.workday.apflow.service;

import com.workday.apflow.dao.WorkflowInstanceDAO;
import com.workday.apflow.dto.request.WorkflowInstanceRequest;
import com.workday.apflow.dto.workflow.WorkflowInstanceDTO;
import com.workday.apflow.model.WorkflowInstance;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class WorkflowInstanceServiceTest {

    @Mock
    private WorkflowInstanceDAO workflowInstanceDAO;

    private WorkflowInstanceService workflowInstanceService;

    private WorkflowInstanceRequest mockRequest;
    private WorkflowInstance mockInstance;

    @BeforeEach
    public void setUp() {
        // Create a concrete implementation of the WorkflowInstanceService
        workflowInstanceService = new WorkflowInstanceService() {
            @Override
            public WorkflowInstance createWorkflowInstance(WorkflowInstanceRequest request) {
                WorkflowInstance instance = new WorkflowInstance();
                instance.setName(request.getName());
                instance.setCreatedBy(request.getCreatedBy());
                instance.setStatus("PENDING");
                instance.setCreatedAt(new Timestamp(System.currentTimeMillis()));
                return workflowInstanceDAO.createWorkflowInstance(instance);
            }

            @Override
            public WorkflowInstance startWorkflowInstance(Integer workflowInstanceId) {
                WorkflowInstance instance = workflowInstanceDAO.getWorkflowInstance(workflowInstanceId);
                if (instance != null) {
                    instance.setStatus("RUNNING");
                    instance.setStartedAt(new Timestamp(System.currentTimeMillis()));
                    return workflowInstanceDAO.updateWorkflowInstance(instance);
                }
                return null;
            }

            @Override
            public WorkflowInstance getWorkflowInstance(Integer workflowInstanceId) {
                return workflowInstanceDAO.getWorkflowInstance(workflowInstanceId);
            }

            @Override
            public List<WorkflowInstance> getAllWorkflowInstances() {
                return workflowInstanceDAO.getAllWorkflowInstances();
            }

            @Override
            public List<WorkflowInstance> getWorkflowInstancesByStatus(String status) {
                return workflowInstanceDAO.getWorkflowInstancesByStatus(status);
            }

            @Override
            public List<WorkflowInstance> getWorkflowInstancesByCreator(String creator) {
                return new ArrayList<>();
            }

            @Override
            public List<WorkflowInstance> getWorkflowInstancesByDateRange(Date startDate, Date endDate) {
                return new ArrayList<>();
            }

            @Override
            public WorkflowInstance updateWorkflowInstance(WorkflowInstance workflowInstance) {
                return workflowInstanceDAO.updateWorkflowInstance(workflowInstance);
            }

            @Override
            public WorkflowInstance cancelWorkflowInstance(Integer workflowInstanceId) {
                WorkflowInstance instance = workflowInstanceDAO.getWorkflowInstance(workflowInstanceId);
                if (instance != null) {
                    instance.setStatus("TERMINATED");
                    instance.setCompletedAt(new Timestamp(System.currentTimeMillis()));
                    return workflowInstanceDAO.updateWorkflowInstance(instance);
                }
                return null;
            }
        };
        
        // Create a mock request
        mockRequest = new WorkflowInstanceRequest();
        mockRequest.setName("Test Workflow");
        mockRequest.setCreatedBy("test-user");
        
        Map<String, Object> inputData = new HashMap<>();
        inputData.put("key1", "value1");
        mockRequest.setInputData(inputData);
        
        Map<String, Object> operatorProps = new HashMap<>();
        operatorProps.put("assignees", List.of("user1", "user2"));
        String operatorId = mockRequest.addOperator("dynamicFork", operatorProps);
        
        Map<String, Object> taskProps = new HashMap<>();
        taskProps.put("priority", "high");
        mockRequest.addTaskToOperator(operatorId, "Review Document", "TODO", taskProps);
        
        String standaloneTaskId = mockRequest.addStandaloneTask("Final Approval", "TODO", taskProps);
        mockRequest.setSequence(List.of(operatorId, standaloneTaskId));
        
        // Create a mock instance
        mockInstance = new WorkflowInstance();
        mockInstance.setId(1);
        mockInstance.setName("Test Workflow");
        mockInstance.setStatus("PENDING");
        mockInstance.setCreatedBy("test-user");
        mockInstance.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        mockInstance.setInstanceDto(new WorkflowInstanceDTO());
    }

    @Test
    public void testCreateWorkflowInstance() {
        // Mock DAO to return the instance
        when(workflowInstanceDAO.createWorkflowInstance(any(WorkflowInstance.class)))
                .thenReturn(mockInstance);

        // Execute test
        WorkflowInstance result = workflowInstanceService.createWorkflowInstance(mockRequest);

        // Verify result
        assertNotNull(result);
        assertEquals(mockInstance.getId(), result.getId());
        assertEquals(mockInstance.getName(), result.getName());
        assertEquals("PENDING", result.getStatus());
        assertEquals(mockInstance.getCreatedBy(), result.getCreatedBy());
        
        // Verify DAO was called
        verify(workflowInstanceDAO).createWorkflowInstance(any(WorkflowInstance.class));
    }

    @Test
    public void testGetWorkflowInstance() {
        // Mock DAO to return the instance
        when(workflowInstanceDAO.getWorkflowInstance(anyInt()))
                .thenReturn(mockInstance);

        // Execute test
        WorkflowInstance result = workflowInstanceService.getWorkflowInstance(1);

        // Verify result
        assertNotNull(result);
        assertEquals(mockInstance.getId(), result.getId());
        assertEquals(mockInstance.getName(), result.getName());
        
        // Verify DAO was called
        verify(workflowInstanceDAO).getWorkflowInstance(1);
    }

    @Test
    public void testGetAllWorkflowInstances() {
        // Create a list of instances
        List<WorkflowInstance> instances = new ArrayList<>();
        instances.add(mockInstance);
        
        WorkflowInstance instance2 = new WorkflowInstance();
        instance2.setId(2);
        instance2.setName("Another Workflow");
        instance2.setStatus("RUNNING");
        instances.add(instance2);
        
        // Mock DAO to return the instances
        when(workflowInstanceDAO.getAllWorkflowInstances())
                .thenReturn(instances);

        // Execute test
        List<WorkflowInstance> result = workflowInstanceService.getAllWorkflowInstances();

        // Verify result
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(1, result.get(0).getId());
        assertEquals(2, result.get(1).getId());
        
        // Verify DAO was called
        verify(workflowInstanceDAO).getAllWorkflowInstances();
    }

    @Test
    public void testGetWorkflowInstancesByStatus() {
        // Create a list of instances
        List<WorkflowInstance> instances = new ArrayList<>();
        instances.add(mockInstance);
        
        // Mock DAO to return the instances
        when(workflowInstanceDAO.getWorkflowInstancesByStatus(anyString()))
                .thenReturn(instances);

        // Execute test
        List<WorkflowInstance> result = workflowInstanceService.getWorkflowInstancesByStatus("PENDING");

        // Verify result
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("PENDING", result.get(0).getStatus());
        
        // Verify DAO was called
        verify(workflowInstanceDAO).getWorkflowInstancesByStatus("PENDING");
    }

    @Test
    public void testStartWorkflowInstance() {
        // Update mock instance for started state
        mockInstance.setStatus("RUNNING");
        mockInstance.setStartedAt(new Timestamp(System.currentTimeMillis()));
        
        // Mock DAO to return the instance
        when(workflowInstanceDAO.getWorkflowInstance(anyInt()))
                .thenReturn(mockInstance);
        when(workflowInstanceDAO.updateWorkflowInstance(any(WorkflowInstance.class)))
                .thenReturn(mockInstance);

        // Execute test
        WorkflowInstance result = workflowInstanceService.startWorkflowInstance(1);

        // Verify result
        assertNotNull(result);
        assertEquals("RUNNING", result.getStatus());
        assertNotNull(result.getStartedAt());
        
        // Verify DAO was called
        verify(workflowInstanceDAO).getWorkflowInstance(1);
        verify(workflowInstanceDAO).updateWorkflowInstance(any(WorkflowInstance.class));
    }

    @Test
    public void testCancelWorkflowInstance() {
        // Update mock instance for cancelled state
        mockInstance.setStatus("TERMINATED");
        mockInstance.setCompletedAt(new Timestamp(System.currentTimeMillis()));
        
        // Mock DAO to return the instance
        when(workflowInstanceDAO.getWorkflowInstance(anyInt()))
                .thenReturn(mockInstance);
        when(workflowInstanceDAO.updateWorkflowInstance(any(WorkflowInstance.class)))
                .thenReturn(mockInstance);

        // Execute test
        WorkflowInstance result = workflowInstanceService.cancelWorkflowInstance(1);

        // Verify result
        assertNotNull(result);
        assertEquals("TERMINATED", result.getStatus());
        assertNotNull(result.getCompletedAt());
        
        // Verify DAO was called
        verify(workflowInstanceDAO).getWorkflowInstance(1);
        verify(workflowInstanceDAO).updateWorkflowInstance(any(WorkflowInstance.class));
    }
    
    @Test
    public void testUpdateWorkflowInstance() {
        // Mock DAO to return the instance
        when(workflowInstanceDAO.updateWorkflowInstance(any(WorkflowInstance.class)))
                .thenReturn(mockInstance);

        // Execute test
        WorkflowInstance result = workflowInstanceService.updateWorkflowInstance(mockInstance);

        // Verify result
        assertNotNull(result);
        
        // Verify DAO was called
        verify(workflowInstanceDAO).updateWorkflowInstance(any(WorkflowInstance.class));
    }
    
    @Test
    public void testUpdateWorkflowInstanceWithCompletedStatus() {
        // Set up mock instance with completed status
        mockInstance.setStatus("COMPLETED");
        mockInstance.setCompletedAt(new Timestamp(System.currentTimeMillis()));
        
        // Mock DAO to return the instance
        when(workflowInstanceDAO.updateWorkflowInstance(any(WorkflowInstance.class)))
                .thenReturn(mockInstance);

        // Execute test
        WorkflowInstance result = workflowInstanceService.updateWorkflowInstance(mockInstance);

        // Verify result
        assertNotNull(result);
        assertEquals("COMPLETED", result.getStatus());
        assertNotNull(result.getCompletedAt());
        
        // Verify DAO was called
        verify(workflowInstanceDAO).updateWorkflowInstance(any(WorkflowInstance.class));
    }
    
    @Test
    public void testUpdateWorkflowInstanceWithFailedStatus() {
        // Set up mock instance with failed status
        mockInstance.setStatus("FAILED");
        mockInstance.setCompletedAt(new Timestamp(System.currentTimeMillis()));
        
        // Mock DAO to return the instance
        when(workflowInstanceDAO.updateWorkflowInstance(any(WorkflowInstance.class)))
                .thenReturn(mockInstance);

        // Execute test
        WorkflowInstance result = workflowInstanceService.updateWorkflowInstance(mockInstance);

        // Verify result
        assertNotNull(result);
        assertEquals("FAILED", result.getStatus());
        assertNotNull(result.getCompletedAt());
        
        // Verify DAO was called
        verify(workflowInstanceDAO).updateWorkflowInstance(any(WorkflowInstance.class));
    }
}
