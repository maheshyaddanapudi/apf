package com.workday.apflow.error;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class WorkflowExceptionTest {

    @Test
    void testConstructorWithMessageAndErrorDetails() {
        // Setup
        String message = "Workflow execution failed";
        String errorCode = "WF-001";
        String errorType = "EXECUTION_ERROR";
        String recoverable = "true";
        
        // Execute
        WorkflowException exception = new WorkflowException(message, errorCode, errorType, recoverable);
        
        // Verify
        assertEquals(message, exception.getMessage());
        assertEquals(errorCode, exception.getErrorCode());
        assertEquals(errorType, exception.getErrorType());
        assertEquals(recoverable, exception.getRecoverable());
        assertNull(exception.getWorkflowInstanceId());
    }
    
    @Test
    void testConstructorWithCauseAndErrorDetails() {
        // Setup
        String message = "Workflow execution failed";
        Throwable cause = new RuntimeException("Original error");
        String errorCode = "WF-001";
        String errorType = "EXECUTION_ERROR";
        String recoverable = "true";
        
        // Execute
        WorkflowException exception = new WorkflowException(message, cause, errorCode, errorType, recoverable);
        
        // Verify
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
        assertEquals(errorCode, exception.getErrorCode());
        assertEquals(errorType, exception.getErrorType());
        assertEquals(recoverable, exception.getRecoverable());
        assertNull(exception.getWorkflowInstanceId());
    }
    
    @Test
    void testConstructorWithWorkflowInstanceId() {
        // Setup
        String message = "Workflow execution failed";
        String errorCode = "WF-001";
        String errorType = "EXECUTION_ERROR";
        String recoverable = "true";
        Integer workflowInstanceId = 123;
        
        // Execute
        WorkflowException exception = new WorkflowException(message, errorCode, errorType, recoverable, workflowInstanceId);
        
        // Verify
        assertEquals(message, exception.getMessage());
        assertEquals(errorCode, exception.getErrorCode());
        assertEquals(errorType, exception.getErrorType());
        assertEquals(recoverable, exception.getRecoverable());
        assertEquals(workflowInstanceId, exception.getWorkflowInstanceId());
    }
    
    @Test
    void testConstructorWithCauseStringAndWorkflowInstanceId() {
        // Setup
        String message = "Workflow execution failed";
        String cause = "Original error";
        String errorCode = "WF-001";
        String errorType = "EXECUTION_ERROR";
        String recoverable = "true";
        Integer workflowInstanceId = 123;
        
        // Execute
        WorkflowException exception = new WorkflowException(message, cause, errorCode, errorType, recoverable, workflowInstanceId);
        
        // Verify
        assertEquals(message, exception.getMessage());
        assertNotNull(exception.getCause());
        assertEquals(errorCode, exception.getErrorCode());
        assertEquals(errorType, exception.getErrorType());
        assertEquals(recoverable, exception.getRecoverable());
        assertEquals(workflowInstanceId, exception.getWorkflowInstanceId());
    }
    
    @Test
    void testToString() {
        // Setup
        String message = "Workflow execution failed";
        String errorCode = "WF-001";
        String errorType = "EXECUTION_ERROR";
        String recoverable = "true";
        
        WorkflowException exception = new WorkflowException(message, errorCode, errorType, recoverable);
        
        // Execute
        String result = exception.toString();
        
        // Verify
        assertNotNull(result);
        assertTrue(result.contains(message));
    }
    
    @Test
    void testRecoverableAndNonRecoverableExceptions() {
        // Setup
        WorkflowException recoverableException = new WorkflowException("Recoverable error", "WF-001", "TEMPORARY_ERROR", "true");
        WorkflowException nonRecoverableException = new WorkflowException("Non-recoverable error", "WF-002", "FATAL_ERROR", "false");
        
        // Verify
        assertEquals("true", recoverableException.getRecoverable());
        assertEquals("false", nonRecoverableException.getRecoverable());
    }
    
    @Test
    void testDifferentErrorTypes() {
        // Setup
        WorkflowException validationException = new WorkflowException("Validation error", "WF-001", "VALIDATION_ERROR", "true");
        WorkflowException timeoutException = new WorkflowException("Timeout error", "WF-002", "TIMEOUT_ERROR", "false");
        WorkflowException authorizationException = new WorkflowException("Authorization error", "WF-003", "AUTHORIZATION_ERROR", "false");
        
        // Verify
        assertEquals("VALIDATION_ERROR", validationException.getErrorType());
        assertEquals("TIMEOUT_ERROR", timeoutException.getErrorType());
        assertEquals("AUTHORIZATION_ERROR", authorizationException.getErrorType());
    }
    
    @Test
    void testDifferentErrorCodes() {
        // Setup
        WorkflowException exception1 = new WorkflowException("Error 1", "WF-001", "ERROR", "true");
        WorkflowException exception2 = new WorkflowException("Error 2", "WF-002", "ERROR", "true");
        WorkflowException exception3 = new WorkflowException("Error 3", "WF-003", "ERROR", "true");
        
        // Verify
        assertEquals("WF-001", exception1.getErrorCode());
        assertEquals("WF-002", exception2.getErrorCode());
        assertEquals("WF-003", exception3.getErrorCode());
    }
    
    @Test
    void testNullErrorCodeAndType() {
        // Setup
        WorkflowException exception = new WorkflowException("Workflow execution failed", null, null, "true");
        
        // Verify
        assertNull(exception.getErrorCode());
        assertNull(exception.getErrorType());
    }
    
    @Test
    void testExceptionWithCause() {
        // Setup
        String message = "Workflow execution failed";
        Throwable cause = new IllegalArgumentException("Invalid argument");
        String errorCode = "WF-001";
        String errorType = "EXECUTION_ERROR";
        String recoverable = "true";
        
        // Execute
        WorkflowException exception = new WorkflowException(message, cause, errorCode, errorType, recoverable);
        
        // Verify
        assertEquals(message, exception.getMessage());
        assertEquals(cause, exception.getCause());
        assertEquals("Invalid argument", exception.getCause().getMessage());
    }
    
    @Test
    void testExceptionInheritance() {
        // Setup
        WorkflowException exception = new WorkflowException("Workflow execution failed", "WF-001", "EXECUTION_ERROR", "true");
        
        // Verify
        assertTrue(exception instanceof RuntimeException);
        assertTrue(exception instanceof Exception);
        assertTrue(exception instanceof Throwable);
    }
}
