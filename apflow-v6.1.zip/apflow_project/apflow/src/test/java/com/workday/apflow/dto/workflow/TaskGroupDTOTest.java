package com.workday.apflow.dto.workflow;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class TaskGroupDTOTest {

    @Test
    void testDefaultConstructor() {
        // Execute
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        
        // Verify
        assertNotNull(taskGroup);
        assertNull(taskGroup.getId());
        assertNull(taskGroup.getName());
        assertNull(taskGroup.getType());
        assertNull(taskGroup.getProperties());
        assertNull(taskGroup.getInput());
        assertNull(taskGroup.getOutput());
        assertFalse(taskGroup.isInitialized());
    }
    
    @Test
    void testParameterizedConstructor() {
        // Setup
        String id = "tg-123";
        String type = "APPROVAL";
        String name = "Approval Task Group";
        
        // Execute
        TaskGroupDTO taskGroup = new TaskGroupDTO(id, type, name);
        
        // Verify
        assertEquals(id, taskGroup.getId());
        assertEquals(type, taskGroup.getType());
        assertEquals(name, taskGroup.getName());
        assertNull(taskGroup.getProperties());
        assertNull(taskGroup.getInput());
        assertNull(taskGroup.getOutput());
        assertFalse(taskGroup.isInitialized());
    }
    
    @Test
    void testGettersAndSetters() {
        // Setup
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        String id = "tg-123";
        String type = "APPROVAL";
        String name = "Approval Task Group";
        Map<String, Object> properties = new HashMap<>();
        properties.put("priority", "high");
        Map<String, Object> input = new HashMap<>();
        input.put("requestId", "req-123");
        Map<String, Object> output = new HashMap<>();
        output.put("approved", true);
        boolean initialized = true;
        
        // Execute
        taskGroup.setId(id);
        taskGroup.setType(type);
        taskGroup.setName(name);
        taskGroup.setProperties(properties);
        taskGroup.setInput(input);
        taskGroup.setOutput(output);
        taskGroup.setInitialized(initialized);
        
        // Verify
        assertEquals(id, taskGroup.getId());
        assertEquals(type, taskGroup.getType());
        assertEquals(name, taskGroup.getName());
        assertEquals(properties, taskGroup.getProperties());
        assertEquals(input, taskGroup.getInput());
        assertEquals(output, taskGroup.getOutput());
        assertTrue(taskGroup.isInitialized());
    }
    
    @Test
    void testInputHandling() {
        // Setup
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        Map<String, Object> input = new HashMap<>();
        input.put("key1", "value1");
        input.put("key2", 123);
        input.put("key3", true);
        
        // Execute
        taskGroup.setInput(input);
        
        // Verify
        assertEquals(input, taskGroup.getInput());
        assertEquals("value1", taskGroup.getInput().get("key1"));
        assertEquals(123, taskGroup.getInput().get("key2"));
        assertEquals(true, taskGroup.getInput().get("key3"));
    }
    
    @Test
    void testOutputHandling() {
        // Setup
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        Map<String, Object> output = new HashMap<>();
        output.put("result", "success");
        output.put("count", 42);
        output.put("completed", true);
        
        // Execute
        taskGroup.setOutput(output);
        
        // Verify
        assertEquals(output, taskGroup.getOutput());
        assertEquals("success", taskGroup.getOutput().get("result"));
        assertEquals(42, taskGroup.getOutput().get("count"));
        assertEquals(true, taskGroup.getOutput().get("completed"));
    }
    
    @Test
    void testPropertiesHandling() {
        // Setup
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        Map<String, Object> properties = new HashMap<>();
        properties.put("priority", "high");
        properties.put("dueDate", "2023-12-31");
        properties.put("maxRetries", 3);
        
        // Execute
        taskGroup.setProperties(properties);
        
        // Verify
        assertEquals(properties, taskGroup.getProperties());
        assertEquals("high", taskGroup.getProperties().get("priority"));
        assertEquals("2023-12-31", taskGroup.getProperties().get("dueDate"));
        assertEquals(3, taskGroup.getProperties().get("maxRetries"));
    }
    
    @Test
    void testNullInput() {
        // Setup
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        
        // Execute
        taskGroup.setInput(null);
        
        // Verify
        assertNull(taskGroup.getInput());
    }
    
    @Test
    void testEmptyInput() {
        // Setup
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        Map<String, Object> emptyInput = new HashMap<>();
        
        // Execute
        taskGroup.setInput(emptyInput);
        
        // Verify
        assertNotNull(taskGroup.getInput());
        assertTrue(taskGroup.getInput().isEmpty());
    }
    
    @Test
    void testNullOutput() {
        // Setup
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        
        // Execute
        taskGroup.setOutput(null);
        
        // Verify
        assertNull(taskGroup.getOutput());
    }
    
    @Test
    void testEmptyOutput() {
        // Setup
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        Map<String, Object> emptyOutput = new HashMap<>();
        
        // Execute
        taskGroup.setOutput(emptyOutput);
        
        // Verify
        assertNotNull(taskGroup.getOutput());
        assertTrue(taskGroup.getOutput().isEmpty());
    }
    
    @Test
    void testNullProperties() {
        // Setup
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        
        // Execute
        taskGroup.setProperties(null);
        
        // Verify
        assertNull(taskGroup.getProperties());
    }
    
    @Test
    void testEmptyProperties() {
        // Setup
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        Map<String, Object> emptyProperties = new HashMap<>();
        
        // Execute
        taskGroup.setProperties(emptyProperties);
        
        // Verify
        assertNotNull(taskGroup.getProperties());
        assertTrue(taskGroup.getProperties().isEmpty());
    }
    
    @Test
    void testInitializedState() {
        // Setup
        TaskGroupDTO taskGroup = new TaskGroupDTO();
        assertFalse(taskGroup.isInitialized());
        
        // Execute
        taskGroup.setInitialized(true);
        
        // Verify
        assertTrue(taskGroup.isInitialized());
        
        // Execute again
        taskGroup.setInitialized(false);
        
        // Verify
        assertFalse(taskGroup.isInitialized());
    }
}
