package com.workday.apflow.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class JsonUtilTest {

    private ObjectMapper objectMapper;

    @BeforeEach
    public void setUp() {
        objectMapper = new ObjectMapper();
    }

    @Test
    public void testToJson() {
        // Create a test object
        Map<String, Object> testObject = new HashMap<>();
        testObject.put("name", "John Doe");
        testObject.put("age", 30);
        testObject.put("isActive", true);

        // Convert to JSON
        String json = JsonUtil.toJson(objectMapper, testObject);

        // Verify the result
        assertNotNull(json);
        assertTrue(json.contains("\"name\":\"John Doe\""));
        assertTrue(json.contains("\"age\":30"));
        assertTrue(json.contains("\"isActive\":true"));
    }

    @Test
    public void testToJsonWithNull() {
        // Convert null to JSON
        Exception exception = assertThrows(RuntimeException.class, () -> {
            JsonUtil.toJson(objectMapper, null);
        });

        // Verify the exception
        assertTrue(exception.getMessage().contains("Failed to convert object to JSON"));
    }

    @Test
    public void testFromJson() {
        // Create a JSON string
        String json = "{\"name\":\"John Doe\",\"age\":30,\"isActive\":true}";

        // Convert to object
        Map<?, ?> result = JsonUtil.fromJson(objectMapper, json, Map.class);

        // Verify the result
        assertNotNull(result);
        assertEquals("John Doe", result.get("name"));
        assertEquals(30, result.get("age"));
        assertEquals(true, result.get("isActive"));
    }

    @Test
    public void testFromJsonWithInvalidJson() {
        // Create an invalid JSON string
        String invalidJson = "{name:John Doe,age:30,isActive:true}";

        // Convert to object and expect exception
        Exception exception = assertThrows(RuntimeException.class, () -> {
            JsonUtil.fromJson(objectMapper, invalidJson, Map.class);
        });

        // Verify the exception
        assertTrue(exception.getMessage().contains("Failed to convert JSON to object"));
    }

    @Test
    public void testFromJsonWithNull() {
        // Convert null to object and expect exception
        Exception exception = assertThrows(RuntimeException.class, () -> {
            JsonUtil.fromJson(objectMapper, null, Map.class);
        });

        // Verify the exception
        assertTrue(exception.getMessage().contains("Failed to convert JSON to object"));
    }

    @Test
    public void testCreateObjectNode() {
        // Create an ObjectNode
        ObjectNode node = JsonUtil.createObjectNode();

        // Verify the result
        assertNotNull(node);
        assertTrue(node.isObject());
    }

    @Test
    public void testToString() {
        // Create a JsonNode
        ObjectNode node = objectMapper.createObjectNode();
        node.put("name", "John Doe");
        node.put("age", 30);
        node.put("isActive", true);

        // Convert to string
        String json = JsonUtil.toString(node);

        // Verify the result
        assertNotNull(json);
        assertTrue(json.contains("\"name\":\"John Doe\""));
        assertTrue(json.contains("\"age\":30"));
        assertTrue(json.contains("\"isActive\":true"));
    }

    @Test
    public void testToStringWithNull() {
        // Convert null to string and expect exception
        Exception exception = assertThrows(RuntimeException.class, () -> {
            JsonUtil.toString(null);
        });

        // Verify the exception
        assertTrue(exception.getMessage().contains("Failed to convert JsonNode to string"));
    }
}
