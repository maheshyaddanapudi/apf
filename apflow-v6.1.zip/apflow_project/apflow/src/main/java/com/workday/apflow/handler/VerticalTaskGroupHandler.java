package com.workday.apflow.handler;

import com.fasterxml.jackson.databind.JsonNode;
import com.workday.apflow.constants.TaskGroupConstants;
import com.workday.apflow.constants.TaskConstants;
import com.workday.apflow.dao.TaskGroupInstanceDAO;
import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.model.TaskGroupInstance;
import com.workday.apflow.model.TaskInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementation of the TaskGroupHandler interface for vertical task groups.
 * Vertical task groups execute tasks sequentially, ensuring that each task starts
 * only after the previous task completes.
 */
public class VerticalTaskGroupHandler implements TaskGroupHandler {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(VerticalTaskGroupHandler.class);
    private final TaskGroupInstanceDAO taskGroupInstanceDAO;
    private final TaskInstanceDAO taskInstanceDAO;
    private final TaskHandlerRegistry taskHandlerRegistry;
    
    /**
     * Constructor
     * @param taskGroupInstanceDAO The task group instance DAO
     * @param taskInstanceDAO The task instance DAO
     * @param taskHandlerRegistry The task handler registry
     */
    public VerticalTaskGroupHandler(
            TaskGroupInstanceDAO taskGroupInstanceDAO,
            TaskInstanceDAO taskInstanceDAO,
            TaskHandlerRegistry taskHandlerRegistry) {
        this.taskGroupInstanceDAO = taskGroupInstanceDAO;
        this.taskInstanceDAO = taskInstanceDAO;
        this.taskHandlerRegistry = taskHandlerRegistry;
    }
    
    @Override
    public String getType() {
        return TaskGroupConstants.TYPE_VERTICAL;
    }
    
    @Override
    public void initialize(TaskGroupInstance taskGroup) {
        LOGGER.info("Initializing vertical task group: {} for workflow: {}", 
                   taskGroup.getId(), taskGroup.getWorkflowInstanceId());
        
        try {
            Map<String, Object> properties = taskGroup.getPropertiesMap();
            
            // Initialize state properties
            if (!properties.containsKey(TaskGroupConstants.PROP_TASKS)) {
                properties.put(TaskGroupConstants.PROP_TASKS, new ArrayList<Integer>());
            }
            
            if (!properties.containsKey(TaskGroupConstants.PROP_CURRENT_INDEX)) {
                properties.put(TaskGroupConstants.PROP_CURRENT_INDEX, 0);
            }
            
            if (!properties.containsKey(TaskGroupConstants.PROP_TASK_DEFINITIONS)) {
                throw new RuntimeException("Vertical task group missing task definitions: " + taskGroup.getId());
            }
            
            // Update task group status
            taskGroup.setStatus(TaskGroupConstants.STATUS_RUNNING);
            taskGroup.setStartedAt(new Timestamp(System.currentTimeMillis()));
            taskGroup.setPropertiesMap(properties);
            
            // Save task group
            taskGroupInstanceDAO.updateTaskGroupInstance(taskGroup);
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to initialize vertical task group: {} for workflow: {}", 
                        taskGroup.getId(), taskGroup.getWorkflowInstanceId(), e);
            throw e;
        }
    }
    
    @Override
    public void initialize(Integer workflowInstanceId, String taskGroupId, JsonNode state) {
        LOGGER.info("Initializing vertical task group: {} for workflow: {}", 
                   taskGroupId, workflowInstanceId);
        
        try {
            // Find or create task group instance
            TaskGroupInstance taskGroup = taskGroupInstanceDAO.getTaskGroupInstanceByWorkflowAndTaskGroupId(
                workflowInstanceId, taskGroupId);
            
            if (taskGroup == null) {
                // Create new task group instance
                taskGroup = new TaskGroupInstance();
                taskGroup.setWorkflowInstanceId(workflowInstanceId);
                taskGroup.setTaskGroupId(taskGroupId);
                taskGroup.setType(getType());
                taskGroup.setStatus(TaskGroupConstants.STATUS_PENDING);
                taskGroup.setCreatedAt(new Timestamp(System.currentTimeMillis()));
                
                // Save task group
                taskGroupInstanceDAO.createTaskGroupInstance(taskGroup);
            }
            
            // Initialize task group
            initialize(taskGroup);
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to initialize vertical task group: {} for workflow: {}", 
                        taskGroupId, workflowInstanceId, e);
            throw e;
        }
    }
    
    @Override
    public void execute(TaskGroupInstance taskGroup) {
        LOGGER.info("Executing vertical task group: {} for workflow: {}", 
                   taskGroup.getId(), taskGroup.getWorkflowInstanceId());
        
        try {
            Map<String, Object> properties = taskGroup.getPropertiesMap();
            
            // Get current index and task definitions
            int currentIndex = (int) properties.get(TaskGroupConstants.PROP_CURRENT_INDEX);
            List<Map<String, Object>> taskDefinitions = 
                (List<Map<String, Object>>) properties.get(TaskGroupConstants.PROP_TASK_DEFINITIONS);
            
            // Check if we have more tasks to create
            if (currentIndex < taskDefinitions.size()) {
                // Get task definition for current index
                Map<String, Object> taskDef = taskDefinitions.get(currentIndex);
                
                // Extract task properties
                String taskType = (String) taskDef.get(TaskGroupConstants.PROP_TASK_TYPE);
                String taskName = (String) taskDef.get(TaskGroupConstants.PROP_TASK_NAME);
                String assignment = (String) taskDef.get(TaskGroupConstants.PROP_ASSIGNMENT);
                Map<String, Object> inputMap = (Map<String, Object>) taskDef.get(TaskGroupConstants.PROP_INPUT);
                
                // Get task handler
                TaskHandler handler = taskHandlerRegistry.getHandler(taskType);
                if (handler == null) {
                    throw new RuntimeException("Task handler not found for type: " + taskType);
                }
                
                // Create task
                TaskInstance task = new TaskInstance();
                task.setWorkflowInstanceId(taskGroup.getWorkflowInstanceId());
                task.setTaskGroupInstanceId(taskGroup.getId());
                task.setName(taskName);
                task.setType(taskType);
                task.setStatus(TaskConstants.STATUS_PENDING);
                task.setAssignment(assignment);
                task.setInputMap(inputMap);
                task.setCreatedBy(taskGroup.getCreatedBy());
                task.setCreatedAt(new Timestamp(System.currentTimeMillis()));
                
                // Save task
                taskInstanceDAO.createTaskInstance(task);
                
                // Execute task
                handler.execute(task);
                
                // Add task ID to list
                List<Integer> tasks = (List<Integer>) properties.get(TaskGroupConstants.PROP_TASKS);
                tasks.add(task.getId());
                
                // Increment current index
                properties.put(TaskGroupConstants.PROP_CURRENT_INDEX, currentIndex + 1);
                taskGroup.setPropertiesMap(properties);
                
                // Save task group
                taskGroupInstanceDAO.updateTaskGroupInstance(taskGroup);
            }
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to execute vertical task group: {} for workflow: {}", 
                        taskGroup.getId(), taskGroup.getWorkflowInstanceId(), e);
            throw e;
        }
    }
    
    @Override
    public void process(TaskGroupInstance taskGroup) {
        LOGGER.info("Processing vertical task group: {} for workflow: {}", 
                   taskGroup.getId(), taskGroup.getWorkflowInstanceId());
        
        try {
            // Check if task group is already initialized
            if (TaskGroupConstants.STATUS_PENDING.equals(taskGroup.getStatus())) {
                // Initialize task group
                initialize(taskGroup);
            }
            
            // Execute task group if it's in running state
            if (TaskGroupConstants.STATUS_RUNNING.equals(taskGroup.getStatus())) {
                Map<String, Object> properties = taskGroup.getPropertiesMap();
                
                // Get current index and task definitions
                int currentIndex = (int) properties.get(TaskGroupConstants.PROP_CURRENT_INDEX);
                List<Map<String, Object>> taskDefinitions = 
                    (List<Map<String, Object>>) properties.get(TaskGroupConstants.PROP_TASK_DEFINITIONS);
                
                // Get tasks
                List<Integer> taskIds = (List<Integer>) properties.get(TaskGroupConstants.PROP_TASKS);
                
                // If we have tasks and the last one is complete, create the next task
                if (!taskIds.isEmpty()) {
                    Integer lastTaskId = taskIds.get(taskIds.size() - 1);
                    TaskInstance lastTask = taskInstanceDAO.getTaskInstance(lastTaskId);
                    
                    if (lastTask != null && (
                        TaskConstants.STATUS_COMPLETED.equals(lastTask.getStatus()) ||
                        TaskConstants.STATUS_FAILED.equals(lastTask.getStatus()) ||
                        TaskConstants.STATUS_TERMINATED.equals(lastTask.getStatus()))) {
                        
                        // Last task is complete, check if we have more tasks to create
                        if (currentIndex < taskDefinitions.size()) {
                            // Create next task
                            execute(taskGroup);
                        } else {
                            // All tasks created and last one is complete, mark task group as complete
                            taskGroup.setStatus(TaskGroupConstants.STATUS_COMPLETED);
                            taskGroup.setCompletedAt(new Timestamp(System.currentTimeMillis()));
                            taskGroupInstanceDAO.updateTaskGroupInstance(taskGroup);
                        }
                    }
                } else if (currentIndex < taskDefinitions.size()) {
                    // No tasks created yet, create the first one
                    execute(taskGroup);
                }
                
                // Check if all tasks are complete
                boolean isComplete = evaluateCompletionCriteria(taskGroup);
                
                if (isComplete) {
                    // Update task group status to completed
                    taskGroup.setStatus(TaskGroupConstants.STATUS_COMPLETED);
                    taskGroup.setCompletedAt(new Timestamp(System.currentTimeMillis()));
                    taskGroupInstanceDAO.updateTaskGroupInstance(taskGroup);
                }
            }
        } catch (RuntimeException e) {
            LOGGER.error("Failed to process vertical task group: {} for workflow: {}", 
                        taskGroup.getId(), taskGroup.getWorkflowInstanceId(), e);
            throw e;
        }
    }
    
    @Override
    public boolean evaluateCompletionCriteria(TaskGroupInstance taskGroup) {
        LOGGER.info("Evaluating completion criteria for vertical task group: {} for workflow: {}", 
                   taskGroup.getId(), taskGroup.getWorkflowInstanceId());
        
        try {
            Map<String, Object> properties = taskGroup.getPropertiesMap();
            
            // Get current index and task definitions
            int currentIndex = (int) properties.get(TaskGroupConstants.PROP_CURRENT_INDEX);
            List<Map<String, Object>> taskDefinitions = 
                (List<Map<String, Object>>) properties.get(TaskGroupConstants.PROP_TASK_DEFINITIONS);
            
            // Get tasks
            List<Integer> taskIds = (List<Integer>) properties.get(TaskGroupConstants.PROP_TASKS);
            
            // If no tasks have been created yet, not complete
            if (taskIds.isEmpty()) {
                return false;
            }
            
            // If we haven't created all tasks yet, check if the last task is complete
            if (currentIndex < taskDefinitions.size()) {
                // Get the last task
                Integer lastTaskId = taskIds.get(taskIds.size() - 1);
                TaskInstance lastTask = taskInstanceDAO.getTaskInstance(lastTaskId);
                
                // Check if the last task is complete
                if (lastTask != null && (
                    TaskConstants.STATUS_COMPLETED.equals(lastTask.getStatus()) ||
                    TaskConstants.STATUS_FAILED.equals(lastTask.getStatus()) ||
                    TaskConstants.STATUS_TERMINATED.equals(lastTask.getStatus()))) {
                    // Last task is complete, we can create the next task
                    return false;
                } else {
                    // Last task is not complete, wait for it
                    return false;
                }
            }
            
            // We've created all tasks, check if the last one is complete
            Integer lastTaskId = taskIds.get(taskIds.size() - 1);
            TaskInstance lastTask = taskInstanceDAO.getTaskInstance(lastTaskId);
            
            // Check if the last task is complete
            return lastTask != null && (
                TaskConstants.STATUS_COMPLETED.equals(lastTask.getStatus()) ||
                TaskConstants.STATUS_FAILED.equals(lastTask.getStatus()) ||
                TaskConstants.STATUS_TERMINATED.equals(lastTask.getStatus()));
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to evaluate completion criteria for vertical task group: {} for workflow: {}", 
                        taskGroup.getId(), taskGroup.getWorkflowInstanceId(), e);
            throw e;
        }
    }
    
    @Override
    public boolean evaluateCompletionCriteria(Integer workflowInstanceId, String taskGroupId, JsonNode state) {
        LOGGER.info("Evaluating completion criteria for vertical task group: {} for workflow: {}", 
                   taskGroupId, workflowInstanceId);
        
        try {
            // Find task group instance
            TaskGroupInstance taskGroup = taskGroupInstanceDAO.getTaskGroupInstanceByWorkflowAndTaskGroupId(
                workflowInstanceId, taskGroupId);
            
            if (taskGroup == null) {
                // Task group not found, not complete
                return false;
            }
            
            // Evaluate completion criteria
            return evaluateCompletionCriteria(taskGroup);
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to evaluate completion criteria for vertical task group: {} for workflow: {}", 
                        taskGroupId, workflowInstanceId, e);
            throw e;
        }
    }
    
    @Override
    public TaskGroupInstance createAndInitialize(Integer workflowInstanceId, String name, Map<String, Object> inputMap, Integer parentGroupId, String createdBy) {
        LOGGER.info("Creating and initializing vertical task group: {} for workflow: {}", 
                   name, workflowInstanceId);
        
        try {
            // Create task group instance
            TaskGroupInstance taskGroup = new TaskGroupInstance();
            taskGroup.setWorkflowInstanceId(workflowInstanceId);
            taskGroup.setName(name);
            taskGroup.setType(getType());
            taskGroup.setStatus(TaskGroupConstants.STATUS_PENDING);
            taskGroup.setParentGroupId(parentGroupId);
            taskGroup.setCreatedBy(createdBy);
            taskGroup.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            taskGroup.setInputMap(inputMap);
            
            // Save task group
            taskGroupInstanceDAO.createTaskGroupInstance(taskGroup);
            
            // Initialize task group
            initialize(taskGroup);
            
            return taskGroup;
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to create and initialize vertical task group: {} for workflow: {}", 
                        name, workflowInstanceId, e);
            throw e;
        }
    }
    
    @Override
    public List<TaskInstance> getTasks(Integer taskGroupId) {
        return taskInstanceDAO.getTaskInstancesByTaskGroupId(taskGroupId);
    }
    
    @Override
    public List<TaskGroupInstance> getChildGroups(Integer taskGroupId) {
        return taskGroupInstanceDAO.getChildTaskGroupInstances(taskGroupId);
    }
}
