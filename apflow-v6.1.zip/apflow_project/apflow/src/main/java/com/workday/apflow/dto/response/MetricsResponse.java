package com.workday.apflow.dto.response;

import java.util.HashMap;
import java.util.Map;

/**
 * Response class for workflow metrics data.
 * Contains performance metrics and statistics for workflow instances.
 */
public class MetricsResponse {
    
    private Integer workflowInstanceId;
    private Map<String, Object> metrics;
    
    /**
     * Default constructor
     */
    public MetricsResponse() {
        this.metrics = new HashMap<>();
    }
    
    /**
     * Constructor with workflow instance ID
     * @param workflowInstanceId The workflow instance ID
     */
    public MetricsResponse(Integer workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
        this.metrics = new HashMap<>();
    }
    
    /**
     * Get workflow instance ID
     * @return The workflow instance ID
     */
    public Integer getWorkflowInstanceId() {
        return workflowInstanceId;
    }
    
    /**
     * Set workflow instance ID
     * @param workflowInstanceId The workflow instance ID
     */
    public void setWorkflowInstanceId(Integer workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
    }
    
    /**
     * Get metrics
     * @return Map of metrics
     */
    public Map<String, Object> getMetrics() {
        return metrics;
    }
    
    /**
     * Set metrics
     * @param metrics Map of metrics
     */
    public void setMetrics(Map<String, Object> metrics) {
        this.metrics = metrics != null ? metrics : new HashMap<>();
    }
    
    /**
     * Add a metric
     * @param key Metric key
     * @param value Metric value
     */
    public void addMetric(String key, Object value) {
        if (metrics == null) {
            metrics = new HashMap<>();
        }
        metrics.put(key, value);
    }
}
