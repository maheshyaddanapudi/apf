package com.workday.apflow.handler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.workday.apflow.constants.TaskConstants;
import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.execution.ExecutionQueuingInterceptor;
import com.workday.apflow.execution.WorkflowStateManager;
import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.model.WorkflowExecutionQueue;

import java.sql.Timestamp;
import java.util.Map;

/**
 * Handler for TODO type tasks.
 */
public class ToDoTaskHandler implements TaskHandler {
    
    private final TaskInstanceDAO taskInstanceDAO;
    private final ObjectMapper objectMapper;
    private final ExecutionQueuingInterceptor executionQueuingInterceptor;
    private final WorkflowStateManager workflowStateManager;
    
    public ToDoTaskHandler(TaskInstanceDAO taskInstanceDAO, 
                          ExecutionQueuingInterceptor executionQueuingInterceptor,
                          WorkflowStateManager workflowStateManager) {
        this.taskInstanceDAO = taskInstanceDAO;
        this.objectMapper = new ObjectMapper();
        this.executionQueuingInterceptor = executionQueuingInterceptor;
        this.workflowStateManager = workflowStateManager;
    }
    
    public ToDoTaskHandler(TaskInstanceDAO taskInstanceDAO) {
        this.taskInstanceDAO = taskInstanceDAO;
        this.objectMapper = new ObjectMapper();
        this.executionQueuingInterceptor = null;
        this.workflowStateManager = null;
    }
    
    @Override
    public String getType() {
        return TaskConstants.TYPE_TODO;
    }
    
    @Override
    public void execute(TaskInstance task) {
        task.setStatus(TaskConstants.STATUS_IN_PROGRESS);
        task.setStartedAt(new Timestamp(System.currentTimeMillis()));
        taskInstanceDAO.updateTaskInstance(task);
    }
    
    @Override
    public void complete(TaskInstance task) {
        task.setStatus(TaskConstants.STATUS_COMPLETED);
        task.setCompletedAt(new Timestamp(System.currentTimeMillis()));
        TaskInstance updatedTask = taskInstanceDAO.updateTaskInstance(task);
        
        // Queue workflow for state management if interceptor is available
        if (executionQueuingInterceptor != null) {
            WorkflowExecutionQueue queueEntry = executionQueuingInterceptor.interceptTaskCompletion(updatedTask);
            
            // If a new queue entry was created and we have a state manager, process it directly
            if (queueEntry != null && queueEntry.isNewlyCreated() && workflowStateManager != null) {
                workflowStateManager.processWorkflowInstance(updatedTask.getWorkflowInstanceId(), queueEntry);
            }
        }
    }
    
    @Override
    public TaskInstance createTask(Integer workflowInstanceId, String taskId, String name, String assignment, JsonNode properties) {
        TaskInstance task = new TaskInstance();
        task.setWorkflowInstanceId(workflowInstanceId);
        task.setTaskId(taskId);
        task.setName(name);
        task.setType(TaskConstants.TYPE_TODO);
        task.setStatus(TaskConstants.STATUS_PENDING);
        task.setAssignment(assignment);
        
        // Set task group instance ID if provided in properties
        if (properties != null && properties.has(TaskConstants.PROP_TASK_GROUP_ID)) {
            task.setTaskGroupInstanceId(properties.get(TaskConstants.PROP_TASK_GROUP_ID).asInt());
        }
        
        return taskInstanceDAO.createTaskInstance(task);
    }
    
    @Override
    public TaskInstance createTask(Integer workflowInstanceId, String name, String inputJson, 
                                  String assignment, Integer taskGroupInstanceId) {
        TaskInstance task = new TaskInstance();
        task.setWorkflowInstanceId(workflowInstanceId);
        task.setName(name);
        task.setType(TaskConstants.TYPE_TODO);
        task.setStatus(TaskConstants.STATUS_PENDING);
        task.setAssignment(assignment);
        task.setInputJson(inputJson);
        task.setTaskGroupInstanceId(taskGroupInstanceId);
        
        return taskInstanceDAO.createTaskInstance(task);
    }
    
    @Override
    public TaskInstance createAndExecute(Integer workflowInstanceId, String name, Map<String, Object> input, 
                                        String assignment, Integer taskGroupInstanceId) {
        String inputJson;
        try {
            inputJson = objectMapper.writeValueAsString(input);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to convert input map to JSON", e);
        }
        
        TaskInstance task = createTask(workflowInstanceId, name, inputJson, assignment, taskGroupInstanceId);
        execute(task);
        return task;
    }
    
    @Override
    public TaskInstance completeAndClose(TaskInstance task, Map<String, Object> output) {
        try {
            String outputJson = objectMapper.writeValueAsString(output);
            return completeAndClose(task, outputJson);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to convert output map to JSON", e);
        }
    }
    
    @Override
    public TaskInstance completeAndClose(TaskInstance task, String outputJson) {
        task.setStatus(TaskConstants.STATUS_COMPLETED);
        task.setOutputJson(outputJson);
        task.setCompletedAt(new Timestamp(System.currentTimeMillis()));
        TaskInstance updatedTask = taskInstanceDAO.updateTaskInstance(task);
        
        // Queue workflow for state management if interceptor is available
        if (executionQueuingInterceptor != null) {
            WorkflowExecutionQueue queueEntry = executionQueuingInterceptor.interceptTaskCompletion(updatedTask);
            
            // If a new queue entry was created and we have a state manager, process it directly
            if (queueEntry != null && queueEntry.isNewlyCreated() && workflowStateManager != null) {
                workflowStateManager.processWorkflowInstance(updatedTask.getWorkflowInstanceId(), queueEntry);
            }
        }
        
        return updatedTask;
    }
    
    @Override
    public TaskInstance moveToComplete(TaskInstance task, Map<String, Object> output) {
        try {
            String outputJson = objectMapper.writeValueAsString(output);
            return moveToComplete(task, outputJson);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to convert output map to JSON", e);
        }
    }
    
    @Override
    public TaskInstance moveToComplete(TaskInstance task, String outputJson) {
        task.setStatus(TaskConstants.STATUS_COMPLETED);
        task.setOutputJson(outputJson);
        task.setCompletedAt(new Timestamp(System.currentTimeMillis()));
        TaskInstance updatedTask = taskInstanceDAO.updateTaskInstance(task);
        
        // Queue workflow for state management if interceptor is available
        if (executionQueuingInterceptor != null) {
            WorkflowExecutionQueue queueEntry = executionQueuingInterceptor.interceptTaskCompletion(updatedTask);
            
            // If a new queue entry was created and we have a state manager, process it directly
            if (queueEntry != null && queueEntry.isNewlyCreated() && workflowStateManager != null) {
                workflowStateManager.processWorkflowInstance(updatedTask.getWorkflowInstanceId(), queueEntry);
            }
        }
        
        return updatedTask;
    }
    
    @Override
    public void close(TaskInstance task) {
        // No specific actions for close in ToDoTaskHandler
    }
}
