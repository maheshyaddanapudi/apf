package com.workday.apflow.service;

import com.workday.apflow.dao.WorkflowHistoryDAO;
import com.workday.apflow.model.WorkflowHistory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Service for history and audit.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class HistoryAndAuditService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(HistoryAndAuditService.class);
    private final WorkflowHistoryDAO historyDAO;
    
    /**
     * Constructor
     * @param historyDAO The workflow history DAO
     */
    public HistoryAndAuditService(WorkflowHistoryDAO historyDAO) {
        this.historyDAO = historyDAO;
    }
    
    /**
     * Add workflow history record
     * @param workflowInstanceId The workflow instance ID
     * @param eventType The event type
     * @param detailsJson The details JSON
     * @param username The username
     * @return The created history record
     */
    public WorkflowHistory addWorkflowHistory(Integer workflowInstanceId, String eventType, 
                                             ObjectNode detailsJson, String username) {
        try {
            LOGGER.info("Adding workflow history record for workflow: {}", workflowInstanceId);
            
            // Create history record
            WorkflowHistory history = new WorkflowHistory();
            history.setWorkflowInstanceId(workflowInstanceId);
            history.setEventType(eventType);
            history.setEventDetails(detailsJson.toString());
            history.setCreatedBy(username);
            
            // Save history record
            Integer historyId = historyDAO.createHistoryRecord(history);
            history.setId(historyId);
            
            return history;
        } catch (Exception e) {
            LOGGER.error("Failed to add workflow history record", e);
            throw new RuntimeException("Failed to add workflow history record", e);
        }
    }
    
    /**
     * Add task history record
     * @param workflowInstanceId The workflow instance ID
     * @param taskId The task ID
     * @param eventType The event type
     * @param detailsJson The details JSON
     * @param username The username
     * @return The created history record
     */
    public WorkflowHistory addTaskHistory(Integer workflowInstanceId, Integer taskId, String eventType, 
                                         ObjectNode detailsJson, String username) {
        try {
            LOGGER.info("Adding task history record for task: {}", taskId);
            
            // Create history record
            WorkflowHistory history = new WorkflowHistory();
            history.setWorkflowInstanceId(workflowInstanceId);
            history.setTaskInstanceId(taskId);
            history.setEventType(eventType);
            history.setEventDetails(detailsJson.toString());
            history.setCreatedBy(username);
            
            // Save history record
            Integer historyId = historyDAO.createHistoryRecord(history);
            history.setId(historyId);
            
            return history;
        } catch (Exception e) {
            LOGGER.error("Failed to add task history record", e);
            throw new RuntimeException("Failed to add task history record", e);
        }
    }
    
    /**
     * Get history for workflow
     * @param workflowInstanceId The workflow instance ID
     * @return The history records
     */
    public List<WorkflowHistory> getHistoryForWorkflow(Integer workflowInstanceId) {
        try {
            LOGGER.info("Getting history for workflow: {}", workflowInstanceId);
            
            // Get history records
            return historyDAO.getHistoryForWorkflow(workflowInstanceId);
        } catch (Exception e) {
            LOGGER.error("Failed to get history for workflow", e);
            throw new RuntimeException("Failed to get history for workflow", e);
        }
    }
    
    /**
     * Archive old history
     * @param olderThan The date to archive history older than
     * @return The number of records archived
     */
    public int archiveOldHistory(LocalDateTime olderThan) {
        try {
            LOGGER.info("Archiving history older than: {}", olderThan);
            
            // Archive history records
            return historyDAO.archiveOldHistory(olderThan);
        } catch (Exception e) {
            LOGGER.error("Failed to archive old history", e);
            throw new RuntimeException("Failed to archive old history", e);
        }
    }
}
