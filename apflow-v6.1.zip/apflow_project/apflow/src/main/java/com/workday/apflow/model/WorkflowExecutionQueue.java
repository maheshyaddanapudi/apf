package com.workday.apflow.model;

import java.sql.Timestamp;

/**
 * Model class for workflow execution queue.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class WorkflowExecutionQueue {
    
    private Integer id;
    private Integer workflowInstanceId;
    private Integer taskInstanceId;
    private String status;
    private String type;
    private Integer priority;
    private Timestamp createdAt;
    private Timestamp processedAt;
    private Timestamp updatedAt;
    private transient boolean newlyCreated;
    private boolean previouslyFailed;
    
    /**
     * Default constructor
     */
    public WorkflowExecutionQueue() {
        this.newlyCreated = false;
        this.previouslyFailed = false;
    }
    
    // Getters and setters
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getWorkflowInstanceId() {
        return workflowInstanceId;
    }
    
    public void setWorkflowInstanceId(Integer workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
    }
    
    public Integer getTaskInstanceId() {
        return taskInstanceId;
    }
    
    public void setTaskInstanceId(Integer taskInstanceId) {
        this.taskInstanceId = taskInstanceId;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public Integer getPriority() {
        return priority;
    }
    
    public void setPriority(Integer priority) {
        this.priority = priority;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getProcessedAt() {
        return processedAt;
    }
    
    public void setProcessedAt(Timestamp processedAt) {
        this.processedAt = processedAt;
    }
    
    public Timestamp getUpdatedAt() {
        return updatedAt;
    }
    
    public void setUpdatedAt(Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }
    
    public boolean isNewlyCreated() {
        return newlyCreated;
    }
    
    public void setNewlyCreated(boolean newlyCreated) {
        this.newlyCreated = newlyCreated;
    }
    
    public boolean isPreviouslyFailed() {
        return previouslyFailed;
    }
    
    public void setPreviouslyFailed(boolean previouslyFailed) {
        this.previouslyFailed = previouslyFailed;
    }
}
