package com.workday.apflow.dto.workflow;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * DTO for task state in the workflow instance.
 * This represents a task within the workflow instance JSON structure.
 */
public class TaskDTO {
    
    private String id;
    private String name;
    private String type;
    private String assignment;
    private Map<String, Object> properties;
    private Map<String, Object> inputData;
    private Map<String, Object> outputData;
    
    /**
     * Default constructor
     */
    public TaskDTO() {
        this.properties = new HashMap<>();
        this.inputData = new HashMap<>();
        this.outputData = new HashMap<>();
    }
    
    /**
     * Get id
     * @return Id
     */
    public String getId() {
        return id;
    }
    
    /**
     * Set id
     * @param id Id
     * @return This DTO for chaining
     */
    public TaskDTO setId(String id) {
        this.id = id;
        return this;
    }
    
    /**
     * Get name
     * @return Name
     */
    public String getName() {
        return name;
    }
    
    /**
     * Set name
     * @param name Name
     * @return This DTO for chaining
     */
    public TaskDTO setName(String name) {
        this.name = name;
        return this;
    }
    
    /**
     * Get type
     * @return Type
     */
    public String getType() {
        return type;
    }
    
    /**
     * Set type
     * @param type Type
     * @return This DTO for chaining
     */
    public TaskDTO setType(String type) {
        this.type = type;
        return this;
    }
    
    /**
     * Get assignment
     * @return Assignment
     */
    public String getAssignment() {
        return assignment;
    }
    
    /**
     * Set assignment
     * @param assignment Assignment
     * @return This DTO for chaining
     */
    public TaskDTO setAssignment(String assignment) {
        this.assignment = assignment;
        return this;
    }
    
    /**
     * Get properties
     * @return Properties
     */
    public Map<String, Object> getProperties() {
        return properties;
    }
    
    /**
     * Set properties
     * @param properties Properties
     * @return This DTO for chaining
     */
    public TaskDTO setProperties(Map<String, Object> properties) {
        this.properties = properties != null ? properties : new HashMap<>();
        return this;
    }
    
    /**
     * Get input data
     * @return Input data
     */
    public Map<String, Object> getInputData() {
        return inputData;
    }
    
    /**
     * Set input data
     * @param inputData Input data
     * @return This DTO for chaining
     */
    public TaskDTO setInputData(Map<String, Object> inputData) {
        this.inputData = inputData != null ? inputData : new HashMap<>();
        return this;
    }
    
    /**
     * Get output data
     * @return Output data
     */
    public Map<String, Object> getOutputData() {
        return outputData;
    }
    
    /**
     * Set output data
     * @param outputData Output data
     * @return This DTO for chaining
     */
    public TaskDTO setOutputData(Map<String, Object> outputData) {
        this.outputData = outputData != null ? outputData : new HashMap<>();
        return this;
    }
    
    /**
     * Add a property
     * @param key Property key
     * @param value Property value
     * @return This DTO for chaining
     */
    public TaskDTO addProperty(String key, Object value) {
        if (this.properties == null) {
            this.properties = new HashMap<>();
        }
        this.properties.put(key, value);
        return this;
    }
    
    /**
     * Add input data
     * @param key Input data key
     * @param value Input data value
     * @return This DTO for chaining
     */
    public TaskDTO addInputData(String key, Object value) {
        if (this.inputData == null) {
            this.inputData = new HashMap<>();
        }
        this.inputData.put(key, value);
        return this;
    }
    
    /**
     * Add output data
     * @param key Output data key
     * @param value Output data value
     * @return This DTO for chaining
     */
    public TaskDTO addOutputData(String key, Object value) {
        if (this.outputData == null) {
            this.outputData = new HashMap<>();
        }
        this.outputData.put(key, value);
        return this;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TaskDTO taskDTO = (TaskDTO) o;
        return Objects.equals(id, taskDTO.id) &&
               Objects.equals(name, taskDTO.name) &&
               Objects.equals(type, taskDTO.type) &&
               Objects.equals(assignment, taskDTO.assignment) &&
               Objects.equals(properties, taskDTO.properties) &&
               Objects.equals(inputData, taskDTO.inputData) &&
               Objects.equals(outputData, taskDTO.outputData);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id, name, type, assignment, properties, inputData, outputData);
    }
    
    @Override
    public String toString() {
        return "TaskDTO{" +
               "id='" + id + '\'' +
               ", name='" + name + '\'' +
               ", type='" + type + '\'' +
               ", assignment='" + assignment + '\'' +
               ", properties=" + properties +
               ", inputData=" + inputData +
               ", outputData=" + outputData +
               '}';
    }
}
