package com.workday.apflow.error;

/**
 * Base exception class for workflow-related exceptions.
 * Provides structured error information including error code, error type, and recoverability.
 */
public class WorkflowException extends RuntimeException {
    private final String errorCode;
    private final String errorType;
    private final String recoverable;
    private final Integer workflowInstanceId;
    
    /**
     * Constructor
     * @param message Error message
     * @param errorCode Error code from ErrorHandlingConstants
     * @param errorType Error type from ErrorHandlingConstants
     * @param recoverable Whether the error is recoverable
     */
    public WorkflowException(String message, String errorCode, String errorType, String recoverable) {
        super(message);
        this.errorCode = errorCode;
        this.errorType = errorType;
        this.recoverable = recoverable;
        this.workflowInstanceId = null;
    }
    
    /**
     * Constructor with cause
     * @param message Error message
     * @param cause Cause of the exception
     * @param errorCode Error code from ErrorHandlingConstants
     * @param errorType Error type from ErrorHandlingConstants
     * @param recoverable Whether the error is recoverable
     */
    public WorkflowException(String message, Throwable cause, String errorCode, String errorType, String recoverable) {
        super(message, cause);
        this.errorCode = errorCode;
        this.errorType = errorType;
        this.recoverable = recoverable;
        this.workflowInstanceId = null;
    }
    
    /**
     * Constructor with workflow instance ID
     * @param message Error message
     * @param errorCode Error code from ErrorHandlingConstants
     * @param errorType Error type from ErrorHandlingConstants
     * @param recoverable Whether the error is recoverable
     * @param workflowInstanceId The workflow instance ID
     */
    public WorkflowException(String message, String errorCode, String errorType, String recoverable, Integer workflowInstanceId) {
        super(message);
        this.errorCode = errorCode;
        this.errorType = errorType;
        this.recoverable = recoverable;
        this.workflowInstanceId = workflowInstanceId;
    }
    
    /**
     * Constructor with cause and workflow instance ID
     * @param message Error message
     * @param cause Cause of the exception
     * @param errorCode Error code from ErrorHandlingConstants
     * @param errorType Error type from ErrorHandlingConstants
     * @param recoverable Whether the error is recoverable
     * @param workflowInstanceId The workflow instance ID
     */
    public WorkflowException(String message, String cause, String errorCode, String errorType, String recoverable, Integer workflowInstanceId) {
        super(message, new RuntimeException(cause));
        this.errorCode = errorCode;
        this.errorType = errorType;
        this.recoverable = recoverable;
        this.workflowInstanceId = workflowInstanceId;
    }
    
    /**
     * Get the error code
     * @return Error code
     */
    public String getErrorCode() {
        return errorCode;
    }
    
    /**
     * Get the error type
     * @return Error type
     */
    public String getErrorType() {
        return errorType;
    }
    
    /**
     * Check if the error is recoverable
     * @return True if recoverable, false otherwise
     */
    public String getRecoverable() {
        return recoverable;
    }
    
    /**
     * Get the workflow instance ID
     * @return Workflow instance ID
     */
    public Integer getWorkflowInstanceId() {
        return workflowInstanceId;
    }
}
