package com.workday.apflow.dto.response;

import com.workday.apflow.dto.workflow.WorkflowInstanceDTO;
import com.workday.apflow.model.WorkflowInstance;
import com.workday.apflow.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Response DTO for workflow instance.
 * This is used to return workflow instance data to clients.
 */
public class WorkflowInstanceResponse {
    
    private Integer id;
    private String name;
    private String status;
    private Map<String, Object> inputData;
    private Map<String, Object> outputData;
    private WorkflowInstanceDTO instanceDto;
    private String createdBy;
    private Timestamp createdAt;
    private Timestamp startedAt;
    private Timestamp completedAt;
    
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    
    /**
     * Default constructor
     */
    public WorkflowInstanceResponse() {
        this.inputData = new HashMap<>();
        this.outputData = new HashMap<>();
    }
    
    /**
     * Constructor from WorkflowInstance model
     * @param instance The workflow instance model
     */
    public WorkflowInstanceResponse(WorkflowInstance instance) {
        this.id = instance.getId();
        this.name = instance.getName();
        this.status = instance.getStatus();
        this.createdBy = instance.getCreatedBy();
        this.createdAt = instance.getCreatedAt();
        this.startedAt = instance.getStartedAt();
        this.completedAt = instance.getCompletedAt();
        this.instanceDto = instance.getInstanceDto();
        
        // Initialize maps
        this.inputData = new HashMap<>();
        this.outputData = new HashMap<>();
        
        // Convert input JSON to map
        if (instance.getInputMap() != null) {
            this.inputData = instance.getInputMap();
        }
        
        // Convert output JSON to map
        if (instance.getOutputMap() != null) {
            this.outputData = instance.getOutputMap();
        }
    }
    
    /**
     * Create a response from a workflow instance model
     * @param instance The workflow instance model
     * @return The response DTO
     */
    public static WorkflowInstanceResponse fromModel(WorkflowInstance instance) {
        if (instance == null) {
            return null;
        }
        return new WorkflowInstanceResponse(instance);
    }
    
    /**
     * Builder class for WorkflowInstanceResponse
     */
    public static Builder builder() {
        return new Builder();
    }
    
    public static class Builder {
        private final WorkflowInstanceResponse response = new WorkflowInstanceResponse();
        
        public Builder id(Integer id) {
            response.setId(id);
            return this;
        }
        
        public Builder name(String name) {
            response.setName(name);
            return this;
        }
        
        public Builder status(String status) {
            response.setStatus(status);
            return this;
        }
        
        public Builder inputData(Map<String, Object> inputData) {
            response.setInputData(inputData);
            return this;
        }
        
        public Builder outputData(Map<String, Object> outputData) {
            response.setOutputData(outputData);
            return this;
        }
        
        public Builder instanceDto(WorkflowInstanceDTO instanceDto) {
            response.setInstanceDto(instanceDto);
            return this;
        }
        
        public Builder createdBy(String createdBy) {
            response.setCreatedBy(createdBy);
            return this;
        }
        
        public Builder createdAt(Timestamp createdAt) {
            response.setCreatedAt(createdAt);
            return this;
        }
        
        public Builder startedAt(Timestamp startedAt) {
            response.setStartedAt(startedAt);
            return this;
        }
        
        public Builder completedAt(Timestamp completedAt) {
            response.setCompletedAt(completedAt);
            return this;
        }
        
        public WorkflowInstanceResponse build() {
            return response;
        }
    }
    
    // Getters and setters
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Map<String, Object> getInputData() {
        return inputData != null ? inputData : new HashMap<>();
    }
    
    public void setInputData(Map<String, Object> inputData) {
        this.inputData = inputData != null ? inputData : new HashMap<>();
    }
    
    public Map<String, Object> getOutputData() {
        return outputData != null ? outputData : new HashMap<>();
    }
    
    public void setOutputData(Map<String, Object> outputData) {
        this.outputData = outputData != null ? outputData : new HashMap<>();
    }
    
    public WorkflowInstanceDTO getInstanceDto() {
        return instanceDto;
    }
    
    public void setInstanceDto(WorkflowInstanceDTO instanceDto) {
        this.instanceDto = instanceDto;
    }
    
    public String getCreatedBy() {
        return createdBy;
    }
    
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getStartedAt() {
        return startedAt;
    }
    
    public void setStartedAt(Timestamp startedAt) {
        this.startedAt = startedAt;
    }
    
    public Timestamp getCompletedAt() {
        return completedAt;
    }
    
    public void setCompletedAt(Timestamp completedAt) {
        this.completedAt = completedAt;
    }
    
    /**
     * Get the input JSON string (for backward compatibility)
     * @return The input JSON string
     */
    public String getInputJson() {
        if (inputData == null || inputData.isEmpty()) {
            return "{}";
        }
        return JsonUtil.toJson(OBJECT_MAPPER, inputData);
    }
    
    /**
     * Set the input JSON string (for backward compatibility)
     * @param inputJson The input JSON string
     */
    public void setInputJson(String inputJson) {
        if (inputJson == null || inputJson.isEmpty()) {
            this.inputData = new HashMap<>();
            return;
        }
        
        try {
            this.inputData = JsonUtil.fromJson(OBJECT_MAPPER, inputJson, Map.class);
        } catch (Exception e) {
            this.inputData = new HashMap<>();
        }
    }
    
    /**
     * Get the output JSON string (for backward compatibility)
     * @return The output JSON string
     */
    public String getOutputJson() {
        if (outputData == null || outputData.isEmpty()) {
            return "{}";
        }
        return JsonUtil.toJson(OBJECT_MAPPER, outputData);
    }
    
    /**
     * Set the output JSON string (for backward compatibility)
     * @param outputJson The output JSON string
     */
    public void setOutputJson(String outputJson) {
        if (outputJson == null || outputJson.isEmpty()) {
            this.outputData = new HashMap<>();
            return;
        }
        
        try {
            this.outputData = JsonUtil.fromJson(OBJECT_MAPPER, outputJson, Map.class);
        } catch (Exception e) {
            this.outputData = new HashMap<>();
        }
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WorkflowInstanceResponse that = (WorkflowInstanceResponse) o;
        return Objects.equals(id, that.id) &&
               Objects.equals(name, that.name) &&
               Objects.equals(status, that.status) &&
               Objects.equals(inputData, that.inputData) &&
               Objects.equals(outputData, that.outputData) &&
               Objects.equals(instanceDto, that.instanceDto) &&
               Objects.equals(createdBy, that.createdBy) &&
               Objects.equals(createdAt, that.createdAt) &&
               Objects.equals(startedAt, that.startedAt) &&
               Objects.equals(completedAt, that.completedAt);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id, name, status, inputData, outputData, instanceDto, createdBy, createdAt, startedAt, completedAt);
    }
    
    @Override
    public String toString() {
        return "WorkflowInstanceResponse{" +
               "id=" + id +
               ", name='" + name + '\'' +
               ", status='" + status + '\'' +
               ", inputData=" + inputData +
               ", outputData=" + outputData +
               ", instanceDto=" + instanceDto +
               ", createdBy='" + createdBy + '\'' +
               ", createdAt=" + createdAt +
               ", startedAt=" + startedAt +
               ", completedAt=" + completedAt +
               '}';
    }
}
