package com.workday.apflow.dao.impl;

import com.workday.apflow.dao.WorkflowHistoryDAO;
import com.workday.apflow.model.WorkflowHistory;
import com.workday.apflow.util.ClassProperties;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;

/**
 * PostgreSQL implementation of the WorkflowHistoryDAO interface.
 */
public class WorkflowHistoryDAOImpl implements WorkflowHistoryDAO {
    private static final Logger LOGGER = Logger.getLogger(WorkflowHistoryDAOImpl.class.getName());
    private final DataSource dataSource;

    /**
     * Constructor with DataSource injection.
     * 
     * @param dataSource The DataSource to use for database connections
     */
    public WorkflowHistoryDAOImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public List<WorkflowHistory> getHistoryByWorkflowInstance(Integer workflowInstanceId) {
        String sql = ClassProperties.getProperty("getHistoryByWorkflowInstance", "WorkflowHistoryDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, workflowInstanceId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<WorkflowHistory> historyList = new ArrayList<>();
                while (rs.next()) {
                    historyList.add(mapResultSetToWorkflowHistory(rs));
                }
                return historyList;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting history for workflow instance ID: " + workflowInstanceId, e);
        }
        
        return List.of();
    }

    @Override
    public List<WorkflowHistory> getHistoryByTaskInstance(Integer taskInstanceId) {
        String sql = ClassProperties.getProperty("getHistoryByTaskInstance", "WorkflowHistoryDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, taskInstanceId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<WorkflowHistory> historyList = new ArrayList<>();
                while (rs.next()) {
                    historyList.add(mapResultSetToWorkflowHistory(rs));
                }
                return historyList;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting history for task instance ID: " + taskInstanceId, e);
        }
        
        return List.of();
    }

    @Override
    public List<WorkflowHistory> getHistoryByDateRange(Date startDate, Date endDate) {
        String sql = ClassProperties.getProperty("getHistoryByDateRange", "WorkflowHistoryDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setTimestamp(1, new Timestamp(startDate.getTime()));
            stmt.setTimestamp(2, new Timestamp(endDate.getTime()));
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<WorkflowHistory> historyList = new ArrayList<>();
                while (rs.next()) {
                    historyList.add(mapResultSetToWorkflowHistory(rs));
                }
                return historyList;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting history for date range: " + startDate + " to " + endDate, e);
        }
        
        return List.of();
    }

    @Override
    public List<WorkflowHistory> getHistoryByUser(String userId) {
        String sql = ClassProperties.getProperty("getHistoryByUser", "WorkflowHistoryDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, userId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<WorkflowHistory> historyList = new ArrayList<>();
                while (rs.next()) {
                    historyList.add(mapResultSetToWorkflowHistory(rs));
                }
                return historyList;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting history for user: " + userId, e);
        }
        
        return List.of();
    }

    @Override
    public List<WorkflowHistory> getHistoryByStatus(String status) {
        String sql = ClassProperties.getProperty("getHistoryByStatus", "WorkflowHistoryDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<WorkflowHistory> historyList = new ArrayList<>();
                while (rs.next()) {
                    historyList.add(mapResultSetToWorkflowHistory(rs));
                }
                return historyList;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting history for status: " + status, e);
        }
        
        return List.of();
    }

    @Override
    public Integer createHistoryRecord(WorkflowHistory history) {
        String sql = ClassProperties.getProperty("createHistoryRecord", "WorkflowHistoryDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, history.getWorkflowInstanceId());
            
            if (history.getTaskInstanceId() != null) {
                stmt.setInt(2, history.getTaskInstanceId());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }
            
            // WorkflowHistory doesn't have taskGroupInstanceId field, so set to null
            stmt.setNull(3, Types.INTEGER);
            
            stmt.setString(4, history.getEventType());
            stmt.setString(5, history.getEventDetails() != null ? history.getEventDetails() : null);
            
            stmt.setTimestamp(6, history.getCreatedAt() != null ? 
                    history.getCreatedAt() : 
                    new Timestamp(System.currentTimeMillis()));
            
            stmt.setString(7, history.getCreatedBy());
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error creating history record", e);
        }
        
        return null;
    }

    @Override
    public Integer archiveOldHistory(LocalDateTime olderThan) {
        String sql = ClassProperties.getProperty("archiveOldHistory", "WorkflowHistoryDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setTimestamp(1, Timestamp.valueOf(olderThan));
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error archiving old history records", e);
        }
        
        return 0;
    }
    
    /**
     * Map a ResultSet row to a WorkflowHistory object.
     * 
     * @param rs The ResultSet containing workflow history data
     * @return A populated WorkflowHistory object
     * @throws SQLException If an error occurs accessing the ResultSet
     */
    private WorkflowHistory mapResultSetToWorkflowHistory(ResultSet rs) throws SQLException {
        WorkflowHistory history = new WorkflowHistory();
        
        history.setId(rs.getInt("id"));
        history.setWorkflowInstanceId(rs.getInt("workflow_instance_id"));
        
        int taskInstanceId = rs.getInt("task_instance_id");
        if (!rs.wasNull()) {
            history.setTaskInstanceId(taskInstanceId);
        }
        
        // WorkflowHistory doesn't have taskGroupInstanceId field, so ignore it
        
        history.setEventType(rs.getString("event_type"));
        
        String eventDetails = rs.getString("event_details");
        if (eventDetails != null) {
            history.setEventDetails(eventDetails);
        }
        
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            history.setCreatedAt(createdAt);
        }
        
        history.setCreatedBy(rs.getString("created_by"));
        
        return history;
    }
}
