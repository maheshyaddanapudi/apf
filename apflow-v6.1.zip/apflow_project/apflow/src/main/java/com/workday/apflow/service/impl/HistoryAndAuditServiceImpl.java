package com.workday.apflow.service.impl;

import com.workday.apflow.dao.WorkflowHistoryDAO;
import com.workday.apflow.model.WorkflowHistory;
import com.workday.apflow.service.HistoryAndAuditService;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Implementation of the history and audit service.
 */
public class HistoryAndAuditServiceImpl extends HistoryAndAuditService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(HistoryAndAuditServiceImpl.class);
    
    /**
     * Constructor with WorkflowHistoryDAO injection.
     * 
     * @param historyDAO The WorkflowHistoryDAO implementation
     */
    public HistoryAndAuditServiceImpl(WorkflowHistoryDAO historyDAO) {
        super(historyDAO);
    }
}
