package com.workday.apflow.api;

import com.workday.apflow.dto.response.WorkflowHistoryResponse;
import com.workday.apflow.dto.response.MetricsResponse;
import com.workday.apflow.model.WorkflowHistory;
import com.workday.apflow.dao.WorkflowHistoryDAO;
import com.workday.apflow.monitoring.MetricsCollector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Implementation of the WorkflowHistoryAPI.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class WorkflowHistoryAPIImpl implements WorkflowHistoryAPI {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowHistoryAPIImpl.class);
    private final WorkflowHistoryDAO workflowHistoryDAO;
    private final MetricsCollector metricsCollector;
    
    /**
     * Constructor
     * @param workflowHistoryDAO The workflow history DAO
     * @param metricsCollector The metrics collector
     */
    public WorkflowHistoryAPIImpl(WorkflowHistoryDAO workflowHistoryDAO, MetricsCollector metricsCollector) {
        this.workflowHistoryDAO = workflowHistoryDAO;
        this.metricsCollector = metricsCollector;
    }
    
    @Override
    public List<WorkflowHistoryResponse> getWorkflowHistory(Integer workflowInstanceId) {
        LOGGER.info("Getting workflow history for workflow instance: {}", workflowInstanceId);
        
        try {
            // Get workflow history
            List<WorkflowHistory> history = workflowHistoryDAO.getHistoryByWorkflowInstance(workflowInstanceId);
            
            // Convert to responses
            return history.stream()
                .map(WorkflowHistoryResponse::fromModel)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow history for workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to get workflow history", e);
        }
    }
    
    @Override
    public List<WorkflowHistoryResponse> getTaskHistory(Integer taskInstanceId) {
        LOGGER.info("Getting workflow history for task instance: {}", taskInstanceId);
        
        try {
            // Get task history
            List<WorkflowHistory> history = workflowHistoryDAO.getHistoryByTaskInstance(taskInstanceId);
            
            // Convert to responses
            return history.stream()
                .map(WorkflowHistoryResponse::fromModel)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow history for task instance: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to get task history", e);
        }
    }
    
    @Override
    public List<WorkflowHistoryResponse> getWorkflowHistoryByDateRange(Date startDate, Date endDate) {
        LOGGER.info("Getting workflow history by date range: {} to {}", startDate, endDate);
        
        try {
            // Get workflow history by date range
            List<WorkflowHistory> history = workflowHistoryDAO.getHistoryByDateRange(startDate, endDate);
            
            // Convert to responses
            return history.stream()
                .map(WorkflowHistoryResponse::fromModel)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow history by date range", e);
            throw new RuntimeException("Failed to get workflow history by date range", e);
        }
    }
    
    @Override
    public List<WorkflowHistoryResponse> getWorkflowHistoryByUser(String userId) {
        LOGGER.info("Getting workflow history by user: {}", userId);
        
        try {
            // Get workflow history by user
            List<WorkflowHistory> history = workflowHistoryDAO.getHistoryByUser(userId);
            
            // Convert to responses
            return history.stream()
                .map(WorkflowHistoryResponse::fromModel)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow history by user: {}", userId, e);
            throw new RuntimeException("Failed to get workflow history by user", e);
        }
    }
    
    @Override
    public List<WorkflowHistoryResponse> getWorkflowHistoryByStatus(String status) {
        LOGGER.info("Getting workflow history by status: {}", status);
        
        try {
            // Get workflow history by status
            List<WorkflowHistory> history = workflowHistoryDAO.getHistoryByStatus(status);
            
            // Convert to responses
            return history.stream()
                .map(WorkflowHistoryResponse::fromModel)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow history by status: {}", status, e);
            throw new RuntimeException("Failed to get workflow history by status", e);
        }
    }
    
    @Override
    public byte[] exportWorkflowHistory(Integer workflowInstanceId, String format) {
        LOGGER.info("Exporting workflow history for workflow instance: {} in format: {}", workflowInstanceId, format);
        
        try {
            // Get workflow history
            List<WorkflowHistory> history = workflowHistoryDAO.getHistoryByWorkflowInstance(workflowInstanceId);
            
            // Convert to responses
            List<WorkflowHistoryResponse> responses = history.stream()
                .map(WorkflowHistoryResponse::fromModel)
                .collect(Collectors.toList());
            
            // Export based on format
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            
            if ("CSV".equalsIgnoreCase(format)) {
                exportToCsv(responses, outputStream);
            } else if ("JSON".equalsIgnoreCase(format)) {
                exportToJson(responses, outputStream);
            } else {
                throw new IllegalArgumentException("Unsupported export format: " + format);
            }
            
            return outputStream.toByteArray();
            
        } catch (Exception e) {
            LOGGER.error("Failed to export workflow history for workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to export workflow history", e);
        }
    }
    
    @Override
    public List<WorkflowHistoryResponse> getWorkflowAuditEvents(Integer workflowInstanceId) {
        LOGGER.info("Getting workflow audit events for workflow instance: {}", workflowInstanceId);
        
        try {
            // Get workflow history
            List<WorkflowHistory> history = workflowHistoryDAO.getHistoryByWorkflowInstance(workflowInstanceId);
            
            // Filter for audit events only
            List<WorkflowHistory> auditEvents = history.stream()
                .filter(h -> "AUDIT".equals(h.getEventType()))
                .collect(Collectors.toList());
            
            // Convert to responses
            return auditEvents.stream()
                .map(WorkflowHistoryResponse::fromModel)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow audit events for workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to get workflow audit events", e);
        }
    }
    
    @Override
    public List<WorkflowHistoryResponse> getWorkflowHistoryWithMetrics(Integer workflowInstanceId) {
        LOGGER.info("Getting workflow history with metrics for workflow instance: {}", workflowInstanceId);
        
        try {
            // Get workflow history
            List<WorkflowHistory> history = workflowHistoryDAO.getHistoryByWorkflowInstance(workflowInstanceId);
            
            // Get metrics
            MetricsResponse metrics = metricsCollector.getWorkflowMetrics(workflowInstanceId);
            
            // Convert to responses
            List<WorkflowHistoryResponse> responses = history.stream()
                .map(h -> {
                    WorkflowHistoryResponse response = WorkflowHistoryResponse.fromModel(h);
                    // Add metrics data to the response details
                    if (metrics != null && metrics.getMetrics() != null) {
                        response.setDetails("Metrics: " + metrics.getMetrics().toString());
                    }
                    return response;
                })
                .collect(Collectors.toList());
            
            return responses;
            
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow history with metrics for workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to get workflow history with metrics", e);
        }
    }
    
    /**
     * Export workflow history to CSV format
     * @param history The workflow history responses
     * @param outputStream The output stream to write to
     * @throws Exception If an error occurs during export
     */
    private void exportToCsv(List<WorkflowHistoryResponse> history, ByteArrayOutputStream outputStream) throws Exception {
        try (OutputStreamWriter writer = new OutputStreamWriter(outputStream, StandardCharsets.UTF_8)) {
            // Write header
            writer.write("ID,Workflow ID,Task ID,Event Type,Status,User,Timestamp,Details\n");
            
            // Write data
            for (WorkflowHistoryResponse entry : history) {
                writer.write(String.format("%d,%d,%s,%s,%s,%s,%s,%s\n",
                    entry.getId(),
                    entry.getWorkflowInstanceId(),
                    entry.getTaskInstanceId() != null ? entry.getTaskInstanceId() : "",
                    entry.getEventType(),
                    entry.getStatus() != null ? entry.getStatus() : "",
                    entry.getUser() != null ? entry.getUser() : "",
                    entry.getTimestamp(),
                    entry.getDetails() != null ? "\"" + entry.getDetails().replace("\"", "\"\"") + "\"" : ""));
            }
        }
    }
    
    /**
     * Export workflow history to JSON format
     * @param history The workflow history responses
     * @param outputStream The output stream to write to
     * @throws Exception If an error occurs during export
     */
    private void exportToJson(List<WorkflowHistoryResponse> history, ByteArrayOutputStream outputStream) throws Exception {
        try (OutputStreamWriter writer = new OutputStreamWriter(outputStream, StandardCharsets.UTF_8)) {
            // Use simple JSON serialization for this example
            writer.write("[\n");
            
            for (int i = 0; i < history.size(); i++) {
                WorkflowHistoryResponse entry = history.get(i);
                writer.write("  {\n");
                writer.write(String.format("    \"id\": %d,\n", entry.getId()));
                writer.write(String.format("    \"workflowInstanceId\": %d,\n", entry.getWorkflowInstanceId()));
                
                if (entry.getTaskInstanceId() != null) {
                    writer.write(String.format("    \"taskInstanceId\": %d,\n", entry.getTaskInstanceId()));
                }
                
                writer.write(String.format("    \"eventType\": \"%s\",\n", entry.getEventType()));
                
                if (entry.getStatus() != null) {
                    writer.write(String.format("    \"status\": \"%s\",\n", entry.getStatus()));
                }
                
                if (entry.getUser() != null) {
                    writer.write(String.format("    \"user\": \"%s\",\n", entry.getUser()));
                }
                
                writer.write(String.format("    \"timestamp\": \"%s\"", entry.getTimestamp()));
                
                if (entry.getDetails() != null) {
                    writer.write(String.format(",\n    \"details\": \"%s\"\n", 
                        entry.getDetails().replace("\"", "\\\"").replace("\n", "\\n")));
                } else {
                    writer.write("\n");
                }
                
                writer.write("  }");
                
                if (i < history.size() - 1) {
                    writer.write(",\n");
                } else {
                    writer.write("\n");
                }
            }
            
            writer.write("]\n");
        }
    }
}
