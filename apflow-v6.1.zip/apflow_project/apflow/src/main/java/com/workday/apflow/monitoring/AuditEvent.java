package com.workday.apflow.monitoring;

import java.sql.Timestamp;

/**
 * Represents an audit event in the workflow system.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class AuditEvent {
    
    private Integer id;
    private String eventType;
    private String eventDetails;
    private String userId;
    private Timestamp timestamp;
    private Integer workflowInstanceId;
    private Integer taskInstanceId;
    
    /**
     * Default constructor
     */
    public AuditEvent() {
    }
    
    /**
     * Get the event ID
     * @return Event ID
     */
    public Integer getId() {
        return id;
    }
    
    /**
     * Set the event ID
     * @param id Event ID
     */
    public void setId(Integer id) {
        this.id = id;
    }
    
    /**
     * Get the event type
     * @return Event type
     */
    public String getEventType() {
        return eventType;
    }
    
    /**
     * Set the event type
     * @param eventType Event type
     */
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }
    
    /**
     * Get the event details
     * @return Event details
     */
    public String getEventDetails() {
        return eventDetails;
    }
    
    /**
     * Set the event details
     * @param eventDetails Event details
     */
    public void setEventDetails(String eventDetails) {
        this.eventDetails = eventDetails;
    }
    
    /**
     * Get the user ID
     * @return User ID
     */
    public String getUserId() {
        return userId;
    }
    
    /**
     * Set the user ID
     * @param userId User ID
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    /**
     * Get the timestamp
     * @return Timestamp
     */
    public Timestamp getTimestamp() {
        return timestamp;
    }
    
    /**
     * Set the timestamp
     * @param timestamp Timestamp
     */
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
    
    /**
     * Get the workflow instance ID
     * @return Workflow instance ID
     */
    public Integer getWorkflowInstanceId() {
        return workflowInstanceId;
    }
    
    /**
     * Set the workflow instance ID
     * @param workflowInstanceId Workflow instance ID
     */
    public void setWorkflowInstanceId(Integer workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
    }
    
    /**
     * Get the task instance ID
     * @return Task instance ID
     */
    public Integer getTaskInstanceId() {
        return taskInstanceId;
    }
    
    /**
     * Set the task instance ID
     * @param taskInstanceId Task instance ID
     */
    public void setTaskInstanceId(Integer taskInstanceId) {
        this.taskInstanceId = taskInstanceId;
    }
    
    @Override
    public String toString() {
        return "AuditEvent{" +
                "id=" + id +
                ", eventType='" + eventType + '\'' +
                ", eventDetails='" + eventDetails + '\'' +
                ", userId='" + userId + '\'' +
                ", timestamp=" + timestamp +
                ", workflowInstanceId=" + workflowInstanceId +
                ", taskInstanceId=" + taskInstanceId +
                '}';
    }
}
