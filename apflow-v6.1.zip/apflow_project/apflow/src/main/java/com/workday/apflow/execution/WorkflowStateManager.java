package com.workday.apflow.execution;

import com.workday.apflow.model.WorkflowInstance;
import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.model.TaskGroupInstance;
import com.workday.apflow.model.WorkflowExecutionQueue;
import com.workday.apflow.dao.WorkflowInstanceDAO;
import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.dao.TaskGroupInstanceDAO;
import com.workday.apflow.dao.WorkflowExecutionQueueDAO;
import com.workday.apflow.handler.TaskHandler;
import com.workday.apflow.handler.TaskHandlerRegistry;
import com.workday.apflow.handler.TaskGroupHandler;
import com.workday.apflow.handler.TaskGroupHandlerRegistry;
import com.workday.apflow.constants.WorkflowConstants;
import com.workday.apflow.constants.TaskConstants;
import com.workday.apflow.constants.TaskGroupConstants;
import com.workday.apflow.constants.QueueConstants;
import com.workday.apflow.dto.workflow.SequenceItemDTO;
import com.workday.apflow.dto.workflow.TaskSequenceItemDTO;
import com.workday.apflow.dto.workflow.TaskGroupSequenceItemDTO;
import com.workday.apflow.dto.workflow.WorkflowInstanceDTO;
import com.workday.apflow.dto.workflow.TaskGroupDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Manages workflow state and progression.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class WorkflowStateManager {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowStateManager.class);
    private final WorkflowInstanceDAO workflowInstanceDAO;
    private final TaskInstanceDAO taskInstanceDAO;
    private final TaskGroupInstanceDAO taskGroupInstanceDAO;
    private final TaskHandlerRegistry taskHandlerRegistry;
    private final TaskGroupHandlerRegistry taskGroupHandlerRegistry;
    private final WorkflowExecutionQueueDAO queueDAO;
    
    /**
     * Constructor
     * @param workflowInstanceDAO The workflow instance DAO
     * @param taskInstanceDAO The task instance DAO
     * @param taskGroupInstanceDAO The task group instance DAO
     * @param taskHandlerRegistry The task handler registry
     * @param taskGroupHandlerRegistry The task group handler registry
     * @param queueDAO The workflow execution queue DAO
     */
    public WorkflowStateManager(WorkflowInstanceDAO workflowInstanceDAO, 
                               TaskInstanceDAO taskInstanceDAO,
                               TaskGroupInstanceDAO taskGroupInstanceDAO,
                               TaskHandlerRegistry taskHandlerRegistry,
                               TaskGroupHandlerRegistry taskGroupHandlerRegistry,
                               WorkflowExecutionQueueDAO queueDAO) {
        this.workflowInstanceDAO = workflowInstanceDAO;
        this.taskInstanceDAO = taskInstanceDAO;
        this.taskGroupInstanceDAO = taskGroupInstanceDAO;
        this.taskHandlerRegistry = taskHandlerRegistry;
        this.taskGroupHandlerRegistry = taskGroupHandlerRegistry;
        this.queueDAO = queueDAO;
    }
    
    /**
     * Process a workflow instance
     * @param workflowInstanceId The workflow instance ID
     */
    public void processWorkflowInstance(Integer workflowInstanceId) {
        processWorkflowInstance(workflowInstanceId, null);
    }
    
    /**
     * Process a workflow instance with a queue entry
     * @param workflowInstanceId The workflow instance ID
     * @param queueEntry The queue entry (can be null)
     */
    public void processWorkflowInstance(Integer workflowInstanceId, WorkflowExecutionQueue queueEntry) {
        LOGGER.info("Processing workflow instance: {}", workflowInstanceId);
        
        boolean wasFailedBefore = false;
        
        // If queue entry is provided, update its status to PROCESSING
        if (queueEntry != null) {
            wasFailedBefore = QueueConstants.STATUS_FAILED.equals(queueEntry.getStatus());
            queueEntry.setStatus(QueueConstants.STATUS_PROCESSING);
            queueEntry.setProcessedAt(new java.sql.Timestamp(System.currentTimeMillis()));
            queueDAO.updateQueueEntry(queueEntry);
        }
        
        try {
            // Get workflow instance
            WorkflowInstance workflow = workflowInstanceDAO.getWorkflowInstance(workflowInstanceId);
            
            if (workflow == null) {
                LOGGER.error("Workflow instance not found: {}", workflowInstanceId);
                return;
            }
            
            // Check if workflow is in a state that can be processed
            if (WorkflowConstants.STATUS_PAUSED.equals(workflow.getStatus())) {
                LOGGER.info("Workflow instance is paused: {}", workflowInstanceId);
                return;
            }
            
            if (!WorkflowConstants.STATUS_RUNNING.equals(workflow.getStatus())) {
                LOGGER.info("Workflow instance is not in running state: {}", workflowInstanceId);
                return;
            }
            
            // Get instance DTO
            WorkflowInstanceDTO instanceDto = workflow.getInstanceDto();
            
            // Check if workflow has sequence and current position
            if (instanceDto.getSequence() == null || instanceDto.getSequence().isEmpty()) {
                LOGGER.error("Workflow instance DTO missing sequence: {}", workflowInstanceId);
                return;
            }
            
            // Get sequence and current position
            int currentPosition = instanceDto.getCurrentPosition();
            
            // Check if workflow is complete
            if (currentPosition >= instanceDto.getSequence().size()) {
                LOGGER.info("Workflow instance is complete: {}", workflowInstanceId);
                completeWorkflow(workflow);
                
                // If queue entry is provided, update its status to COMPLETED
                if (queueEntry != null) {
                    queueEntry.setStatus(QueueConstants.STATUS_COMPLETED);
                    queueDAO.updateQueueEntry(queueEntry);
                }
                
                return;
            }
            
            // Get current item in sequence
            SequenceItemDTO currentItem = instanceDto.getSequence().get(currentPosition);
            
            // Process current item based on its type
            if (currentItem instanceof TaskGroupSequenceItemDTO) {
                // Process task group
                processTaskGroup(workflow, instanceDto, (TaskGroupSequenceItemDTO) currentItem);
            } else if (currentItem instanceof TaskSequenceItemDTO) {
                // Process task
                processTask(workflow, instanceDto, (TaskSequenceItemDTO) currentItem);
            } else {
                LOGGER.error("Unknown sequence item type: {}", currentItem.getClass().getName());
            }
            
            // Update workflow instance
            workflow.setInstanceDto(instanceDto);
            workflowInstanceDAO.updateWorkflowInstance(workflow);
            
            // If queue entry is provided, update its status to COMPLETED
            if (queueEntry != null) {
                queueEntry.setStatus(QueueConstants.STATUS_COMPLETED);
                queueDAO.updateQueueEntry(queueEntry);
            }
            
        } catch (Exception e) {
            LOGGER.error("Error processing workflow instance: {}", workflowInstanceId, e);
            
            // If queue entry is provided, update its status to FAILED or FATAL
            if (queueEntry != null) {
                try {
                    // Create a new connection to update the queue entry
                    if (wasFailedBefore) {
                        // If it was already failed before, mark as FATAL
                        queueEntry.setStatus(QueueConstants.STATUS_FATAL);
                    } else {
                        // Otherwise, mark as FAILED
                        queueEntry.setStatus(QueueConstants.STATUS_FAILED);
                    }
                    queueDAO.updateQueueEntry(queueEntry);
                } catch (Exception ex) {
                    LOGGER.error("Failed to update queue entry status: {}", queueEntry.getId(), ex);
                }
            }
            
            // Re-throw the exception
            throw new RuntimeException("Error processing workflow instance", e);
        }
    }
    
    /**
     * Process a task group in the sequence
     * @param workflow The workflow instance
     * @param instanceDto The instance DTO
     * @param taskGroupItem The task group sequence item
     */
    private void processTaskGroup(WorkflowInstance workflow, WorkflowInstanceDTO instanceDto, 
                                TaskGroupSequenceItemDTO taskGroupItem) throws Exception {
        String taskGroupId = taskGroupItem.getId();
        String taskGroupType = taskGroupItem.getTaskGroupType();
        
        LOGGER.info("Processing task group: {} of type: {}", taskGroupId, taskGroupType);
        
        // Get task group state
        Map<String, TaskGroupDTO> taskGroups = instanceDto.getTaskGroups();
        if (taskGroups == null) {
            taskGroups = new HashMap<>();
            instanceDto.setTaskGroups(taskGroups);
        }
        
        TaskGroupDTO taskGroupDto = taskGroups.get(taskGroupId);
        
        // Check if task group exists
        if (taskGroupDto == null) {
            LOGGER.error("Task group state not found: {}", taskGroupId);
            return;
        }
        
        // Check if task group instance exists
        TaskGroupInstance existingTaskGroup = null;
        
        if (taskGroupItem.getTaskGroupInstanceId() != null) {
            existingTaskGroup = taskGroupInstanceDAO.getTaskGroupInstance(taskGroupItem.getTaskGroupInstanceId());
        }
        
        if (existingTaskGroup != null) {
            // Task group instance exists, check status
            if (TaskGroupConstants.STATUS_COMPLETED.equals(existingTaskGroup.getStatus()) || 
                TaskGroupConstants.STATUS_FAILED.equals(existingTaskGroup.getStatus()) || 
                TaskGroupConstants.STATUS_TERMINATED.equals(existingTaskGroup.getStatus())) {
                
                // Task group is in terminal state, move to next item in sequence
                instanceDto.setCurrentPosition(instanceDto.getCurrentPosition() + 1);
                LOGGER.info("Task group complete, moving to next item: {}", instanceDto.getCurrentPosition());
                
            } else if (TaskGroupConstants.STATUS_PENDING.equals(existingTaskGroup.getStatus())) {
                // Task group is pending, initialize it
                TaskGroupHandler handler = taskGroupHandlerRegistry.getHandler(taskGroupType);
                
                if (handler != null) {
                    handler.initialize(existingTaskGroup);
                } else {
                    LOGGER.error("Task group handler not found for type: {}", taskGroupType);
                }
            } else if (TaskGroupConstants.STATUS_RUNNING.equals(existingTaskGroup.getStatus())) {
                // Task group is running, check if it's complete
                TaskGroupHandler handler = taskGroupHandlerRegistry.getHandler(taskGroupType);
                
                if (handler != null) {
                    if (handler.evaluateCompletionCriteria(existingTaskGroup)) {
                        // Task group is complete, update status and move to next item
                        existingTaskGroup.setStatus(TaskGroupConstants.STATUS_COMPLETED);
                        existingTaskGroup.setCompletedAt(new java.sql.Timestamp(System.currentTimeMillis()));
                        taskGroupInstanceDAO.updateTaskGroupInstance(existingTaskGroup);
                        
                        instanceDto.setCurrentPosition(instanceDto.getCurrentPosition() + 1);
                        LOGGER.info("Task group complete, moving to next item: {}", instanceDto.getCurrentPosition());
                    } else {
                        // Task group is not complete, execute it
                        handler.execute(existingTaskGroup);
                    }
                } else {
                    LOGGER.error("Task group handler not found for type: {}", taskGroupType);
                }
            }
            
        } else {
            // Task group instance does not exist, create it
            String taskGroupName = taskGroupItem.getName();
            Map<String, Object> inputJson = taskGroupItem.getInputJson();
            
            // Get task group handler
            TaskGroupHandler handler = taskGroupHandlerRegistry.getHandler(taskGroupType);
            
            if (handler == null) {
                LOGGER.error("Task group handler not found for type: {}", taskGroupType);
                return;
            }
            
            // Create task group instance
            TaskGroupInstance taskGroup = handler.createAndInitialize(
                workflow.getId(),
                taskGroupName,
                inputJson,
                null, // No parent group for sequence items
                workflow.getCreatedBy()
            );
            
            // Update task group item with task group instance ID
            taskGroupItem.setTaskGroupInstanceId(taskGroup.getId());
            
            // Initialize task group
            handler.initialize(taskGroup);
        }
    }
    
    /**
     * Process a task in the sequence
     * @param workflow The workflow instance
     * @param instanceDto The instance DTO
     * @param taskItem The task sequence item
     */
    private void processTask(WorkflowInstance workflow, WorkflowInstanceDTO instanceDto, 
                            TaskSequenceItemDTO taskItem) throws Exception {
        String taskId = taskItem.getId();
        
        LOGGER.info("Processing task: {}", taskId);
        
        // Check if task instance exists
        TaskInstance existingTask = null;
        
        if (taskItem.getTaskInstanceId() != null) {
            existingTask = taskInstanceDAO.getTaskInstance(taskItem.getTaskInstanceId());
        }
        
        if (existingTask != null) {
            // Task instance exists, check status
            if (TaskConstants.STATUS_COMPLETED.equals(existingTask.getStatus()) || 
                TaskConstants.STATUS_FAILED.equals(existingTask.getStatus()) || 
                TaskConstants.STATUS_TERMINATED.equals(existingTask.getStatus())) {
                
                // Task is in terminal state, move to next item in sequence
                instanceDto.setCurrentPosition(instanceDto.getCurrentPosition() + 1);
                LOGGER.info("Task complete, moving to next item: {}", instanceDto.getCurrentPosition());
                
            } else if (TaskConstants.STATUS_PENDING.equals(existingTask.getStatus())) {
                // Task is pending, start it
                String taskType = existingTask.getType();
                TaskHandler handler = taskHandlerRegistry.getHandler(taskType);
                
                if (handler != null) {
                    handler.execute(existingTask);
                } else {
                    LOGGER.error("Task handler not found for type: {}", taskType);
                }
            }
            
        } else {
            // Task instance does not exist, create it
            String taskType = taskItem.getTaskType();
            String taskName = taskItem.getName();
            String assignment = taskItem.getAssignment();
            
            // Create task instance
            TaskInstance task = new TaskInstance();
            task.setWorkflowInstanceId(workflow.getId());
            task.setName(taskName);
            task.setType(taskType);
            task.setStatus(TaskConstants.STATUS_PENDING);
            task.setAssignment(assignment);
            task.setCreatedBy(workflow.getCreatedBy());
            task.setCreatedAt(new java.sql.Timestamp(System.currentTimeMillis()));
            
            // Set input JSON if available
            if (taskItem.getInputJson() != null) {
                task.setInputMap(taskItem.getInputJson());
            }
            
            // Save task instance
            taskInstanceDAO.createTaskInstance(task);
            
            // Update task item with task instance ID
            taskItem.setTaskInstanceId(task.getId());
            
            // Start task
            TaskHandler handler = taskHandlerRegistry.getHandler(taskType);
            
            if (handler != null) {
                handler.execute(task);
            } else {
                LOGGER.error("Task handler not found for type: {}", taskType);
            }
        }
    }
    
    /**
     * Complete a workflow instance
     * @param workflow The workflow instance
     */
    private void completeWorkflow(WorkflowInstance workflow) {
        LOGGER.info("Completing workflow instance: {}", workflow.getId());
        
        // Update workflow status
        workflow.setStatus(WorkflowConstants.STATUS_COMPLETED);
        workflow.setCompletedAt(new java.sql.Timestamp(System.currentTimeMillis()));
        
        // Save workflow instance
        workflowInstanceDAO.updateWorkflowInstance(workflow);
    }
}
