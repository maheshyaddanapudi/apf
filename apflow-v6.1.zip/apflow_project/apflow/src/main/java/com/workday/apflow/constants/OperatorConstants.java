package com.workday.apflow.constants;

/**
 * Constants for operator operations.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class OperatorConstants {
    
    // Operator type constants
    public static final String TYPE_DYNAMIC_FORK = "dynamicFork";
    public static final String TYPE_SEQUENCE = "sequence";
    
    // Operator property constants
    public static final String PROP_BRANCH_PROPERTY = "branchProperty";
    public static final String PROP_BRANCH_VALUES = "branchValues";
    public static final String PROP_TASK_TEMPLATE = "taskTemplate";
    public static final String PROP_TASK_TYPE = "taskType";
    public static final String PROP_TASK_NAME = "taskName";
    public static final String PROP_TASKS = "tasks";
    public static final String PROP_COMPLETION_CRITERIA = "completionCriteria";
    public static final String PROP_CURRENT_INDEX = "currentIndex";
    public static final String PROP_TASK_DEFINITIONS = "taskDefinitions";
    public static final String PROP_ASSIGNMENT = "assignment";
    public static final String PROP_INPUT = "input";
    
    // Completion criteria constants
    public static final String COMPLETION_ALL = "ALL";
    public static final String COMPLETION_ANY = "ANY";
    
    // Operator state constants
    public static final String STATE_INITIALIZED = "initialized";
    public static final String STATE_EXECUTING = "executing";
    public static final String STATE_COMPLETED = "completed";
    public static final String STATE_FAILED = "failed";
    
    // Event constants
    public static final String EVENT_OPERATOR_INITIALIZED = "OPERATOR_INITIALIZED";
    public static final String EVENT_OPERATOR_EXECUTING = "OPERATOR_EXECUTING";
    public static final String EVENT_OPERATOR_COMPLETED = "OPERATOR_COMPLETED";
    public static final String EVENT_OPERATOR_FAILED = "OPERATOR_FAILED";
}
