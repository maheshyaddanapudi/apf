package com.workday.apflow.execution;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.workday.apflow.constants.WorkflowConstants;
import com.workday.apflow.dto.workflow.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Utility class for parsing and serializing workflow JSON.
 */
public class WorkflowJsonParser {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowJsonParser.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    
    /**
     * Parse workflow instance JSON into a DTO
     * @param json The workflow instance JSON
     * @return The parsed workflow instance DTO
     */
    public static WorkflowInstanceDTO parseWorkflowInstance(String json) {
        try {
            WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
            
            if (json == null || json.isEmpty()) {
                return dto;
            }
            
            JsonNode rootNode = OBJECT_MAPPER.readTree(json);
            
            // Parse basic properties
            if (rootNode.has("id")) {
                dto.setId(rootNode.get("id").asText());
            }
            
            if (rootNode.has("name")) {
                dto.setName(rootNode.get("name").asText());
            }
            
            if (rootNode.has("description")) {
                dto.setDescription(rootNode.get("description").asText());
            }
            
            if (rootNode.has("status")) {
                dto.setStatus(rootNode.get("status").asText());
            }
            
            if (rootNode.has("currentPosition")) {
                dto.setCurrentPosition(rootNode.get("currentPosition").asInt());
            }
            
            // Parse metadata
            if (rootNode.has("metadata")) {
                JsonNode metadataNode = rootNode.get("metadata");
                Map<String, Object> metadata = OBJECT_MAPPER.convertValue(metadataNode, Map.class);
                dto.setMetadata(metadata);
            }
            
            // Parse input data
            if (rootNode.has("inputData")) {
                JsonNode inputDataNode = rootNode.get("inputData");
                Map<String, Object> inputData = OBJECT_MAPPER.convertValue(inputDataNode, Map.class);
                dto.setInputData(inputData);
            }
            
            // Parse output data
            if (rootNode.has("outputData")) {
                JsonNode outputDataNode = rootNode.get("outputData");
                Map<String, Object> outputData = OBJECT_MAPPER.convertValue(outputDataNode, Map.class);
                dto.setOutputData(outputData);
            }
            
            // Parse sequence
            if (rootNode.has("sequence")) {
                JsonNode sequenceNode = rootNode.get("sequence");
                List<SequenceItemDTO> sequence = new ArrayList<>();
                
                for (JsonNode itemNode : sequenceNode) {
                    String type = itemNode.has("type") ? itemNode.get("type").asText() : null;
                    
                    if (WorkflowConstants.TYPE_TASK.equals(type)) {
                        TaskSequenceItemDTO taskItem = OBJECT_MAPPER.convertValue(itemNode, TaskSequenceItemDTO.class);
                        sequence.add(taskItem);
                    } else if (WorkflowConstants.TYPE_TASK_GROUP.equals(type)) {
                        TaskGroupSequenceItemDTO taskGroupItem = OBJECT_MAPPER.convertValue(itemNode, TaskGroupSequenceItemDTO.class);
                        sequence.add(taskGroupItem);
                    } else {
                        LOGGER.warn("Unknown sequence item type: {}", type);
                    }
                }
                
                dto.setSequence(sequence);
            }
            
            // Parse task groups
            if (rootNode.has("taskGroups")) {
                JsonNode taskGroupsNode = rootNode.get("taskGroups");
                Map<String, TaskGroupDTO> taskGroups = new HashMap<>();
                
                taskGroupsNode.fields().forEachRemaining(entry -> {
                    String id = entry.getKey();
                    JsonNode taskGroupNode = entry.getValue();
                    TaskGroupDTO taskGroupDTO = OBJECT_MAPPER.convertValue(taskGroupNode, TaskGroupDTO.class);
                    taskGroups.put(id, taskGroupDTO);
                });
                
                dto.setTaskGroups(taskGroups);
            }
            
            // Parse standalone tasks
            if (rootNode.has("standaloneTasks")) {
                JsonNode tasksNode = rootNode.get("standaloneTasks");
                Map<String, TaskDTO> tasks = new HashMap<>();
                
                tasksNode.fields().forEachRemaining(entry -> {
                    String id = entry.getKey();
                    JsonNode taskNode = entry.getValue();
                    TaskDTO taskDTO = OBJECT_MAPPER.convertValue(taskNode, TaskDTO.class);
                    tasks.put(id, taskDTO);
                });
                
                dto.setStandaloneTasks(tasks);
            }
            
            return dto;
            
        } catch (Exception e) {
            LOGGER.error("Error parsing workflow instance JSON", e);
            throw new RuntimeException("Error parsing workflow instance JSON", e);
        }
    }
    
    /**
     * Serialize workflow instance DTO to JSON
     * @param dto The workflow instance DTO
     * @return The serialized JSON
     */
    public static String serializeWorkflowInstance(WorkflowInstanceDTO dto) {
        try {
            ObjectNode rootNode = OBJECT_MAPPER.createObjectNode();
            
            // Serialize basic properties
            if (dto.getId() != null) {
                rootNode.put("id", dto.getId());
            }
            
            if (dto.getName() != null) {
                rootNode.put("name", dto.getName());
            }
            
            if (dto.getDescription() != null) {
                rootNode.put("description", dto.getDescription());
            }
            
            if (dto.getStatus() != null) {
                rootNode.put("status", dto.getStatus());
            }
            
            if (dto.getCurrentPosition() != null) {
                rootNode.put("currentPosition", dto.getCurrentPosition());
            }
            
            // Serialize metadata
            if (dto.getMetadata() != null) {
                JsonNode metadataNode = OBJECT_MAPPER.valueToTree(dto.getMetadata());
                rootNode.set("metadata", metadataNode);
            }
            
            // Serialize input data
            if (dto.getInputData() != null) {
                JsonNode inputDataNode = OBJECT_MAPPER.valueToTree(dto.getInputData());
                rootNode.set("inputData", inputDataNode);
            }
            
            // Serialize output data
            if (dto.getOutputData() != null) {
                JsonNode outputDataNode = OBJECT_MAPPER.valueToTree(dto.getOutputData());
                rootNode.set("outputData", outputDataNode);
            }
            
            // Serialize sequence
            if (dto.getSequence() != null) {
                ArrayNode sequenceNode = OBJECT_MAPPER.createArrayNode();
                
                for (SequenceItemDTO item : dto.getSequence()) {
                    JsonNode itemNode = OBJECT_MAPPER.valueToTree(item);
                    sequenceNode.add(itemNode);
                }
                
                rootNode.set("sequence", sequenceNode);
            }
            
            // Serialize task groups
            if (dto.getTaskGroups() != null) {
                ObjectNode taskGroupsNode = OBJECT_MAPPER.createObjectNode();
                
                for (Map.Entry<String, TaskGroupDTO> entry : dto.getTaskGroups().entrySet()) {
                    String id = entry.getKey();
                    TaskGroupDTO taskGroupDTO = entry.getValue();
                    JsonNode taskGroupNode = OBJECT_MAPPER.valueToTree(taskGroupDTO);
                    taskGroupsNode.set(id, taskGroupNode);
                }
                
                rootNode.set("taskGroups", taskGroupsNode);
            }
            
            // Serialize standalone tasks
            if (dto.getStandaloneTasks() != null) {
                ObjectNode tasksNode = OBJECT_MAPPER.createObjectNode();
                
                for (Map.Entry<String, TaskDTO> entry : dto.getStandaloneTasks().entrySet()) {
                    String id = entry.getKey();
                    TaskDTO taskDTO = entry.getValue();
                    JsonNode taskNode = OBJECT_MAPPER.valueToTree(taskDTO);
                    tasksNode.set(id, taskNode);
                }
                
                rootNode.set("standaloneTasks", tasksNode);
            }
            
            return OBJECT_MAPPER.writeValueAsString(rootNode);
            
        } catch (Exception e) {
            LOGGER.error("Error serializing workflow instance DTO", e);
            throw new RuntimeException("Error serializing workflow instance DTO", e);
        }
    }
    
    /**
     * Get a task group from the workflow instance DTO
     * @param instanceDto The workflow instance DTO
     * @param taskGroupId The task group ID
     * @return The task group DTO, or null if not found
     */
    public static TaskGroupDTO getTaskGroup(WorkflowInstanceDTO instanceDto, String taskGroupId) {
        if (instanceDto.getTaskGroups() == null) {
            return null;
        }
        
        return instanceDto.getTaskGroups().get(taskGroupId);
    }
    
    /**
     * Get a standalone task from the workflow instance DTO
     * @param instanceDto The workflow instance DTO
     * @param taskId The task ID
     * @return The task DTO, or null if not found
     */
    public static TaskDTO getStandaloneTask(WorkflowInstanceDTO instanceDto, String taskId) {
        if (instanceDto.getStandaloneTasks() == null) {
            return null;
        }
        
        return instanceDto.getStandaloneTasks().get(taskId);
    }
    
    /**
     * Parse instance JSON to JsonNode
     * @param json The instance JSON
     * @return The parsed JsonNode
     */
    public static JsonNode parseInstanceJsonToNode(String json) {
        try {
            if (json == null || json.isEmpty()) {
                return OBJECT_MAPPER.createObjectNode();
            }
            
            return OBJECT_MAPPER.readTree(json);
        } catch (Exception e) {
            LOGGER.error("Error parsing instance JSON to node", e);
            throw new RuntimeException("Error parsing instance JSON to node", e);
        }
    }
    
    /**
     * Get the current sequence item from the workflow instance DTO
     * @param instanceDto The workflow instance DTO
     * @return The current sequence item, or null if not found
     */
    public static SequenceItemDTO getCurrentSequenceItem(WorkflowInstanceDTO instanceDto) {
        if (instanceDto == null || instanceDto.getSequence() == null || instanceDto.getCurrentPosition() == null) {
            return null;
        }
        
        int position = instanceDto.getCurrentPosition();
        List<SequenceItemDTO> sequence = instanceDto.getSequence();
        
        if (position < 0 || position >= sequence.size()) {
            return null;
        }
        
        return sequence.get(position);
    }
    
    /**
     * Get the current sequence item from the workflow instance JSON
     * @param instanceJson The workflow instance JSON as JsonNode
     * @return The current sequence item, or null if not found
     */
    public static JsonNode getCurrentSequenceItem(JsonNode instanceJson) {
        if (instanceJson == null || !instanceJson.has("sequence") || !instanceJson.has("currentPosition")) {
            return null;
        }
        
        int position = instanceJson.get("currentPosition").asInt();
        JsonNode sequenceNode = instanceJson.get("sequence");
        
        if (!sequenceNode.isArray() || position < 0 || position >= sequenceNode.size()) {
            return null;
        }
        
        return sequenceNode.get(position);
    }
    
    /**
     * Get the task group state from the workflow instance JSON
     * @param instanceJson The workflow instance JSON as JsonNode
     * @param taskGroupId The task group ID
     * @return The task group state as JsonNode, or null if not found
     */
    public static JsonNode getTaskGroupState(JsonNode instanceJson, String taskGroupId) {
        if (instanceJson == null || !instanceJson.has("taskGroups")) {
            return null;
        }
        
        JsonNode taskGroupsNode = instanceJson.get("taskGroups");
        
        if (!taskGroupsNode.has(taskGroupId)) {
            return null;
        }
        
        return taskGroupsNode.get(taskGroupId);
    }
    
    /**
     * Get the task group state from the workflow instance DTO
     * @param instanceDto The workflow instance DTO
     * @param taskGroupId The task group ID
     * @return The task group DTO, or null if not found
     */
    public static TaskGroupDTO getTaskGroupState(WorkflowInstanceDTO instanceDto, String taskGroupId) {
        return getTaskGroup(instanceDto, taskGroupId);
    }
}
