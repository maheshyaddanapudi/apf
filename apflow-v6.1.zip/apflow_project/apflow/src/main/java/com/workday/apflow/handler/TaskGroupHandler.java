package com.workday.apflow.handler;

import com.fasterxml.jackson.databind.JsonNode;
import com.workday.apflow.model.TaskGroupInstance;
import com.workday.apflow.model.TaskInstance;

import java.util.List;
import java.util.Map;

/**
 * Interface for task group handlers.
 * This is responsible for executing and managing task groups based on their type.
 */
public interface TaskGroupHandler {
    
    /**
     * Get the task group type that this handler supports
     * @return The task group type
     */
    String getType();
    
    /**
     * Initialize the task group
     * @param taskGroup The task group instance to initialize
     */
    void initialize(TaskGroupInstance taskGroup);
    
    /**
     * Initialize the task group
     * @param workflowInstanceId The workflow instance ID
     * @param taskGroupId The task group ID
     * @param state The task group state as JsonNode
     */
    void initialize(Integer workflowInstanceId, String taskGroupId, JsonNode state);
    
    /**
     * Execute the task group
     * @param taskGroup The task group instance to execute
     */
    void execute(TaskGroupInstance taskGroup);
    
    /**
     * Process the task group
     * @param taskGroup The task group instance to process
     */
    void process(TaskGroupInstance taskGroup);
    
    /**
     * Evaluate completion criteria for the task group
     * @param taskGroup The task group instance to evaluate
     * @return True if the task group is complete, false otherwise
     */
    boolean evaluateCompletionCriteria(TaskGroupInstance taskGroup);
    
    /**
     * Evaluate completion criteria for the task group
     * @param workflowInstanceId The workflow instance ID
     * @param taskGroupId The task group ID
     * @param state The task group state as JsonNode
     * @return True if the task group is complete, false otherwise
     */
    boolean evaluateCompletionCriteria(Integer workflowInstanceId, String taskGroupId, JsonNode state);
    
    /**
     * Create and initialize a new task group instance
     * @param workflowInstanceId The workflow instance ID
     * @param name The task group name
     * @param inputMap The input data for the task group
     * @param parentGroupId The parent group ID (can be null for top-level groups)
     * @param createdBy The user who created the task group
     * @return The created task group instance
     */
    TaskGroupInstance createAndInitialize(
        Integer workflowInstanceId,
        String name,
        Map<String, Object> inputMap,
        Integer parentGroupId,
        String createdBy
    );
    
    /**
     * Get tasks for this task group
     * @param taskGroupId The task group ID
     * @return List of task instances in this group
     */
    List<TaskInstance> getTasks(Integer taskGroupId);
    
    /**
     * Get child groups for this task group
     * @param taskGroupId The task group ID
     * @return List of child task group instances
     */
    List<TaskGroupInstance> getChildGroups(Integer taskGroupId);
}
