package com.workday.apflow.handler;

import com.fasterxml.jackson.databind.JsonNode;
import com.workday.apflow.model.TaskInstance;

import java.util.Map;

/**
 * Interface for task handlers.
 */
public interface TaskHandler {
    
    /**
     * Get the task type this handler supports
     * @return The task type
     */
    String getType();
    
    /**
     * Get the task type this handler supports (alias for getType for backward compatibility)
     * @return The task type
     */
    default String getTaskType() {
        return getType();
    }
    
    /**
     * Execute a task
     * @param task The task to execute
     */
    void execute(TaskInstance task);
    
    /**
     * Complete a task
     * @param task The task to complete
     */
    void complete(TaskInstance task);
    
    /**
     * Create a task
     * @param workflowInstanceId The workflow instance ID
     * @param taskId The task ID
     * @param name The task name
     * @param assignment The task assignment
     * @param properties The task properties
     * @return The created task instance
     */
    TaskInstance createTask(Integer workflowInstanceId, String taskId, String name, String assignment, JsonNode properties);
    
    /**
     * Create a task
     * @param workflowInstanceId The workflow instance ID
     * @param name The task name
     * @param inputJson The task input data as JSON string
     * @param assignment The task assignment
     * @param taskGroupInstanceId The task group instance ID
     * @return The created task instance
     */
    default TaskInstance createTask(Integer workflowInstanceId, String name, String inputJson, 
                                  String assignment, Integer taskGroupInstanceId) {
        // Default implementation that can be overridden by concrete handlers
        throw new UnsupportedOperationException("createTask not implemented for " + getType());
    }
    
    /**
     * Create and execute a new task
     * @param workflowInstanceId The workflow instance ID
     * @param name The task name
     * @param input The task input data
     * @param assignment The task assignment
     * @param taskGroupInstanceId The task group instance ID (optional)
     * @param description The task description (optional)
     * @return The created task instance ID
     */
    default Integer createAndExecute(Integer workflowInstanceId, String name, Map<String, Object> input, 
                                    String assignment, String taskGroupInstanceId, String description) {
        // Default implementation that can be overridden by concrete handlers
        throw new UnsupportedOperationException("createAndExecute not implemented for " + getType());
    }
    
    /**
     * Create and execute a new task
     * @param workflowInstanceId The workflow instance ID
     * @param name The task name
     * @param input The task input data
     * @param assignment The task assignment
     * @param taskGroupInstanceId The task group instance ID
     * @return The created task instance
     */
    default TaskInstance createAndExecute(Integer workflowInstanceId, String name, Map<String, Object> input, 
                                        String assignment, Integer taskGroupInstanceId) {
        // Default implementation that can be overridden by concrete handlers
        throw new UnsupportedOperationException("createAndExecute not implemented for " + getType());
    }
    
    /**
     * Complete and close a task
     * @param task The task to complete and close
     * @param output The task output data
     * @return The updated task instance
     */
    default TaskInstance completeAndClose(TaskInstance task, Map<String, Object> output) {
        // Default implementation that can be overridden by concrete handlers
        throw new UnsupportedOperationException("completeAndClose not implemented for " + getType());
    }
    
    /**
     * Complete and close a task
     * @param task The task to complete and close
     * @param outputJson The task output data as JSON string
     * @return The updated task instance
     */
    default TaskInstance completeAndClose(TaskInstance task, String outputJson) {
        // Default implementation that can be overridden by concrete handlers
        throw new UnsupportedOperationException("completeAndClose not implemented for " + getType());
    }
    
    /**
     * Move a task to complete status
     * @param task The task to move to complete
     * @param output The task output data
     * @return The updated task instance
     */
    default TaskInstance moveToComplete(TaskInstance task, Map<String, Object> output) {
        // Default implementation that can be overridden by concrete handlers
        throw new UnsupportedOperationException("moveToComplete not implemented for " + getType());
    }
    
    /**
     * Move a task to complete status
     * @param task The task to move to complete
     * @param outputJson The task output data as JSON string
     * @return The updated task instance
     */
    default TaskInstance moveToComplete(TaskInstance task, String outputJson) {
        // Default implementation that can be overridden by concrete handlers
        throw new UnsupportedOperationException("moveToComplete not implemented for " + getType());
    }
    
    /**
     * Close a task
     * @param task The task to close
     */
    default void close(TaskInstance task) {
        // Default implementation that can be overridden by concrete handlers
        // No-op by default
    }
}
