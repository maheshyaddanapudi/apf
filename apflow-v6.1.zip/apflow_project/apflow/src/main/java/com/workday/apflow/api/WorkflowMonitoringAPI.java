package com.workday.apflow.api;

import com.workday.apflow.dto.response.MetricsResponse;
import com.workday.apflow.dto.response.SlaStatusResponse;
import com.workday.apflow.monitoring.AuditEvent;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * API for workflow monitoring operations.
 * This interface provides methods for monitoring workflow performance, metrics, and SLA compliance.
 */
public interface WorkflowMonitoringAPI {
    
    /**
     * Get workflow metrics
     * @param workflowInstanceId The workflow instance ID
     * @return Metrics response for the workflow
     */
    MetricsResponse getWorkflowMetrics(Integer workflowInstanceId);
    
    /**
     * Get task metrics
     * @param taskInstanceId The task instance ID
     * @return Metrics response for the task
     */
    MetricsResponse getTaskMetrics(Integer taskInstanceId);
    
    /**
     * Get system metrics
     * @return Metrics response for the system
     */
    MetricsResponse getSystemMetrics();
    
    /**
     * Get workflow SLA status
     * @param workflowInstanceId The workflow instance ID
     * @return SLA status response for the workflow
     */
    SlaStatusResponse getWorkflowSlaStatus(Integer workflowInstanceId);
    
    /**
     * Get task SLA status
     * @param taskInstanceId The task instance ID
     * @return SLA status response for the task
     */
    SlaStatusResponse getTaskSlaStatus(Integer taskInstanceId);
    
    /**
     * Get SLA violations by date range
     * @param startDate The start date
     * @param endDate The end date
     * @return List of SLA status responses for violations in the date range
     */
    List<SlaStatusResponse> getSlaViolationsByDateRange(Date startDate, Date endDate);
    
    /**
     * Get audit events by workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return List of audit events for the workflow
     */
    List<AuditEvent> getAuditEventsByWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Get audit events by task instance
     * @param taskInstanceId The task instance ID
     * @return List of audit events for the task
     */
    List<AuditEvent> getAuditEventsByTaskInstance(Integer taskInstanceId);
    
    /**
     * Get audit events by date range
     * @param startDate The start date
     * @param endDate The end date
     * @return List of audit events in the date range
     */
    List<AuditEvent> getAuditEventsByDateRange(Date startDate, Date endDate);
    
    /**
     * Get audit events by user
     * @param userId The user ID
     * @return List of audit events for the user
     */
    List<AuditEvent> getAuditEventsByUser(String userId);
    
    /**
     * Get audit events by event type
     * @param eventType The event type
     * @return List of audit events of the specified type
     */
    List<AuditEvent> getAuditEventsByType(String eventType);
    
    /**
     * Define a new SLA
     * @param name The SLA name
     * @param thresholdMs The SLA threshold in milliseconds
     * @param description The SLA description
     * @return The SLA definition as a map
     */
    Map<String, Object> defineSla(String name, long thresholdMs, String description);
    
    /**
     * Get SLA compliance report for a workflow
     * @param workflowInstanceId The workflow instance ID
     * @return SLA compliance report as a map
     */
    Map<String, Object> getWorkflowSlaReport(Integer workflowInstanceId);
    
    /**
     * Get performance dashboard data
     * @return Performance dashboard data as a map
     */
    Map<String, Object> getPerformanceDashboardData();
}
