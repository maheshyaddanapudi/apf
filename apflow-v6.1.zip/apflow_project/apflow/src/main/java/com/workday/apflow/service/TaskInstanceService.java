package com.workday.apflow.service;

import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.dto.request.TaskInstanceRequest;
import com.workday.apflow.model.TaskInstance;

/**
 * Interface for task instance operations.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public interface TaskInstanceService {
    
    /**
     * Get the TaskInstanceDAO
     * @return The TaskInstanceDAO
     */
    TaskInstanceDAO getTaskInstanceDAO();
    
    /**
     * Create a task instance
     * @param request The task instance request
     * @return The created task instance
     */
    TaskInstance createTaskInstance(TaskInstanceRequest request);
    
    /**
     * Create multiple task instances
     * @param requests The list of task instance requests
     * @return The list of created task instances
     */
    java.util.List<TaskInstance> createTaskInstances(java.util.List<TaskInstanceRequest> requests);
    
    /**
     * Get a task instance by ID
     * @param taskInstanceId The task instance ID
     * @return The task instance
     */
    TaskInstance getTaskInstance(Integer taskInstanceId);
    
    /**
     * Get task instances by workflow instance ID
     * @param workflowInstanceId The workflow instance ID
     * @return List of task instances
     */
    java.util.List<TaskInstance> getTaskInstancesByWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Get task instances by status
     * @param status The status
     * @return List of task instances
     */
    java.util.List<TaskInstance> getTaskInstancesByStatus(String status);
    
    /**
     * Get task instances by assignment
     * @param assignment The assignment
     * @return List of task instances
     */
    java.util.List<TaskInstance> getTaskInstancesByAssignment(String assignment);
    
    /**
     * Cancel a task instance
     * @param taskInstanceId The task instance ID
     * @return The canceled task instance
     */
    TaskInstance cancelTaskInstance(Integer taskInstanceId);
    
    /**
     * Update a task instance
     * @param taskInstance The task instance to update
     * @return The updated task instance
     */
    TaskInstance updateTaskInstance(TaskInstance taskInstance);
    
    /**
     * Get tasks by due date
     * @param dueDate The due date
     * @return List of task instances
     */
    java.util.List<TaskInstance> getTasksByDueDate(java.util.Date dueDate);
    
    /**
     * Get overdue tasks
     * @return List of overdue task instances
     */
    java.util.List<TaskInstance> getOverdueTasks();
    
    /**
     * Get tasks by task group instance ID
     * @param taskGroupInstanceId The task group instance ID
     * @return List of task instances
     */
    java.util.List<TaskInstance> getTasksByTaskGroup(Integer taskGroupInstanceId);
    
    /**
     * Get tasks by type
     * @param type The task type
     * @return List of task instances
     */
    java.util.List<TaskInstance> getTasksByType(String type);
}
