package com.workday.apflow.model;

import java.sql.Timestamp;

/**
 * Model class for workflow history.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class WorkflowHistory {
    
    private Integer id;
    private Integer workflowInstanceId;
    private Integer taskInstanceId;
    private String eventType;
    private String eventDetails;
    private Timestamp createdAt;
    private String createdBy;
    private String status;
    
    /**
     * Default constructor
     */
    public WorkflowHistory() {
    }
    
    // Getters and setters
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getWorkflowInstanceId() {
        return workflowInstanceId;
    }
    
    public void setWorkflowInstanceId(Integer workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
    }
    
    public Integer getTaskInstanceId() {
        return taskInstanceId;
    }
    
    public void setTaskInstanceId(Integer taskInstanceId) {
        this.taskInstanceId = taskInstanceId;
    }
    
    public String getEventType() {
        return eventType;
    }
    
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }
    
    public String getEventDetails() {
        return eventDetails;
    }
    
    public void setEventDetails(String eventDetails) {
        this.eventDetails = eventDetails;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public String getCreatedBy() {
        return createdBy;
    }
    
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
}
