package com.workday.apflow.dto.request;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Objects;

/**
 * DTO for workflow instance requests.
 * This class provides methods for building workflow instances with operators and tasks.
 */
public class WorkflowInstanceRequest {
    
    private String name;
    private String createdBy;
    private Map<String, Object> inputData;
    private List<String> sequence;
    private Map<String, Map<String, Object>> operators;
    private Map<String, Map<String, Object>> standaloneTasks;
    
    /**
     * Default constructor
     */
    public WorkflowInstanceRequest() {
        this.sequence = new ArrayList<>();
        this.operators = new HashMap<>();
        this.standaloneTasks = new HashMap<>();
        this.inputData = new HashMap<>();
    }
    
    /**
     * Private constructor for builder
     */
    private WorkflowInstanceRequest(Builder builder) {
        this.name = builder.name;
        this.createdBy = builder.createdBy;
        this.inputData = builder.inputData != null ? builder.inputData : new HashMap<>();
        this.sequence = builder.sequence != null ? builder.sequence : new ArrayList<>();
        this.operators = builder.operators != null ? builder.operators : new HashMap<>();
        this.standaloneTasks = builder.standaloneTasks != null ? builder.standaloneTasks : new HashMap<>();
    }
    
    /**
     * Get name
     * @return Name
     */
    public String getName() {
        return name;
    }
    
    /**
     * Set name
     * @param name Name
     * @return This request for chaining
     */
    public WorkflowInstanceRequest setName(String name) {
        this.name = name;
        return this;
    }
    
    /**
     * Get created by
     * @return Created by
     */
    public String getCreatedBy() {
        return createdBy;
    }
    
    /**
     * Set created by
     * @param createdBy Created by
     * @return This request for chaining
     */
    public WorkflowInstanceRequest setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
        return this;
    }
    
    /**
     * Get input data
     * @return Input data
     */
    public Map<String, Object> getInputData() {
        return inputData;
    }
    
    /**
     * Set input data
     * @param inputData Input data
     * @return This request for chaining
     */
    public WorkflowInstanceRequest setInputData(Map<String, Object> inputData) {
        this.inputData = inputData != null ? inputData : new HashMap<>();
        return this;
    }
    
    /**
     * Add input data
     * @param key Input data key
     * @param value Input data value
     * @return This request for chaining
     */
    public WorkflowInstanceRequest addInputData(String key, Object value) {
        if (this.inputData == null) {
            this.inputData = new HashMap<>();
        }
        this.inputData.put(key, value);
        return this;
    }
    
    /**
     * Get input JSON (for backward compatibility)
     * @return Input JSON
     */
    public String getInputJson() {
        if (inputData == null || inputData.isEmpty()) {
            return null;
        }
        try {
            return com.workday.apflow.util.JsonUtil.toJson(new com.fasterxml.jackson.databind.ObjectMapper(), inputData);
        } catch (Exception e) {
            return "{}";
        }
    }
    
    /**
     * Set input JSON (for backward compatibility)
     * @param inputJson Input JSON
     * @return This request for chaining
     */
    public WorkflowInstanceRequest setInputJson(String inputJson) {
        if (inputJson == null || inputJson.isEmpty()) {
            this.inputData = new HashMap<>();
            return this;
        }
        
        try {
            this.inputData = com.workday.apflow.util.JsonUtil.fromJson(
                new com.fasterxml.jackson.databind.ObjectMapper(), 
                inputJson, 
                Map.class
            );
        } catch (Exception e) {
            this.inputData = new HashMap<>();
        }
        return this;
    }
    
    /**
     * Get sequence
     * @return Sequence
     */
    public List<String> getSequence() {
        return sequence;
    }
    
    /**
     * Set sequence
     * @param sequence Sequence
     * @return This request for chaining
     */
    public WorkflowInstanceRequest setSequence(List<String> sequence) {
        this.sequence = sequence;
        return this;
    }
    
    /**
     * Get operators
     * @return Operators
     */
    public Map<String, Map<String, Object>> getOperators() {
        return operators;
    }
    
    /**
     * Set operators
     * @param operators Operators
     * @return This request for chaining
     */
    public WorkflowInstanceRequest setOperators(Map<String, Map<String, Object>> operators) {
        this.operators = operators;
        return this;
    }
    
    /**
     * Get standalone tasks
     * @return Standalone tasks
     */
    public Map<String, Map<String, Object>> getStandaloneTasks() {
        return standaloneTasks;
    }
    
    /**
     * Set standalone tasks
     * @param standaloneTasks Standalone tasks
     * @return This request for chaining
     */
    public WorkflowInstanceRequest setStandaloneTasks(Map<String, Map<String, Object>> standaloneTasks) {
        this.standaloneTasks = standaloneTasks;
        return this;
    }
    
    /**
     * Add an operator to the workflow
     * @param type Operator type
     * @param properties Operator properties
     * @return Operator ID
     */
    public String addOperator(String type, Map<String, Object> properties) {
        String operatorId = "op-" + UUID.randomUUID().toString().substring(0, 8);
        Map<String, Object> operator = new HashMap<>();
        operator.put("type", type);
        operator.put("properties", properties != null ? properties : new HashMap<>());
        operator.put("tasks", new HashMap<>());
        operators.put(operatorId, operator);
        return operatorId;
    }
    
    /**
     * Add a task to an operator
     * @param operatorId Operator ID
     * @param name Task name
     * @param type Task type
     * @param properties Task properties
     * @return Task ID
     */
    public String addTaskToOperator(String operatorId, String name, String type, Map<String, Object> properties) {
        if (!operators.containsKey(operatorId)) {
            throw new IllegalArgumentException("Operator not found: " + operatorId);
        }
        
        String taskId = "task-" + UUID.randomUUID().toString().substring(0, 8);
        Map<String, Object> task = new HashMap<>();
        task.put("name", name);
        task.put("type", type);
        task.put("properties", properties != null ? properties : new HashMap<>());
        
        Map<String, Object> operator = operators.get(operatorId);
        @SuppressWarnings("unchecked")
        Map<String, Object> tasks = (Map<String, Object>) operator.get("tasks");
        tasks.put(taskId, task);
        
        return taskId;
    }
    
    /**
     * Add a standalone task to the workflow
     * @param name Task name
     * @param type Task type
     * @param properties Task properties
     * @return Task ID
     */
    public String addStandaloneTask(String name, String type, Map<String, Object> properties) {
        String taskId = "task-" + UUID.randomUUID().toString().substring(0, 8);
        Map<String, Object> task = new HashMap<>();
        task.put("name", name);
        task.put("type", type);
        task.put("properties", properties != null ? properties : new HashMap<>());
        standaloneTasks.put(taskId, task);
        return taskId;
    }
    
    /**
     * Create a new builder
     * @return Builder
     */
    public static Builder builder() {
        return new Builder();
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        WorkflowInstanceRequest that = (WorkflowInstanceRequest) o;
        return Objects.equals(name, that.name) &&
               Objects.equals(createdBy, that.createdBy) &&
               Objects.equals(inputData, that.inputData) &&
               Objects.equals(sequence, that.sequence) &&
               Objects.equals(operators, that.operators) &&
               Objects.equals(standaloneTasks, that.standaloneTasks);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(name, createdBy, inputData, sequence, operators, standaloneTasks);
    }
    
    @Override
    public String toString() {
        return "WorkflowInstanceRequest{" +
               "name='" + name + '\'' +
               ", createdBy='" + createdBy + '\'' +
               ", inputData=" + inputData +
               ", sequence=" + sequence +
               ", operators=" + operators +
               ", standaloneTasks=" + standaloneTasks +
               '}';
    }
    
    /**
     * Builder for WorkflowInstanceRequest
     */
    public static class Builder {
        private String name;
        private String createdBy;
        private Map<String, Object> inputData;
        private List<String> sequence;
        private Map<String, Map<String, Object>> operators;
        private Map<String, Map<String, Object>> standaloneTasks;
        
        /**
         * Set name
         * @param name Name
         * @return Builder
         */
        public Builder name(String name) {
            this.name = name;
            return this;
        }
        
        /**
         * Set created by
         * @param createdBy Created by
         * @return Builder
         */
        public Builder createdBy(String createdBy) {
            this.createdBy = createdBy;
            return this;
        }
        
        /**
         * Set input data
         * @param inputData Input data
         * @return Builder
         */
        public Builder inputData(Map<String, Object> inputData) {
            this.inputData = inputData;
            return this;
        }
        
        /**
         * Set input JSON (for backward compatibility)
         * @param inputJson Input JSON
         * @return Builder
         */
        public Builder inputJson(String inputJson) {
            if (inputJson == null || inputJson.isEmpty()) {
                this.inputData = new HashMap<>();
                return this;
            }
            
            try {
                this.inputData = com.workday.apflow.util.JsonUtil.fromJson(
                    new com.fasterxml.jackson.databind.ObjectMapper(), 
                    inputJson, 
                    Map.class
                );
            } catch (Exception e) {
                this.inputData = new HashMap<>();
            }
            return this;
        }
        
        /**
         * Set sequence
         * @param sequence Sequence
         * @return Builder
         */
        public Builder sequence(List<String> sequence) {
            this.sequence = sequence;
            return this;
        }
        
        /**
         * Set operators
         * @param operators Operators
         * @return Builder
         */
        public Builder operators(Map<String, Map<String, Object>> operators) {
            this.operators = operators;
            return this;
        }
        
        /**
         * Set standalone tasks
         * @param standaloneTasks Standalone tasks
         * @return Builder
         */
        public Builder standaloneTasks(Map<String, Map<String, Object>> standaloneTasks) {
            this.standaloneTasks = standaloneTasks;
            return this;
        }
        
        /**
         * Build WorkflowInstanceRequest
         * @return WorkflowInstanceRequest
         */
        public WorkflowInstanceRequest build() {
            return new WorkflowInstanceRequest(this);
        }
    }
}
