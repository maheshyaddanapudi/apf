package com.workday.apflow.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Registry for task handlers.
 */
public class TaskHandlerRegistry {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskHandlerRegistry.class);
    
    private final Map<String, TaskHandler> handlers = new HashMap<>();
    
    /**
     * Register a task handler
     * @param handler The task handler to register
     */
    public void registerHandler(TaskHandler handler) {
        if (handler == null) {
            throw new IllegalArgumentException("Handler cannot be null");
        }
        
        String type = handler.getType();
        if (type == null || type.isEmpty()) {
            throw new IllegalArgumentException("Handler type cannot be null or empty");
        }
        
        handlers.put(type, handler);
        LOGGER.info("Registered task handler for type: {}", type);
    }
    
    /**
     * Get a task handler by type
     * @param type The task type
     * @return The task handler, or null if not found
     */
    public TaskHandler getHandler(String type) {
        return handlers.get(type);
    }
    
    /**
     * Check if a handler exists for a given type
     * @param type The task type
     * @return True if a handler exists, false otherwise
     */
    public boolean hasHandler(String type) {
        return handlers.containsKey(type);
    }
    
    /**
     * Get all registered handlers
     * @return Map of task type to handler
     */
    public Map<String, TaskHandler> getHandlers() {
        return new HashMap<>(handlers);
    }
}
