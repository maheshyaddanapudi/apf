package com.workday.apflow.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class for JSON operations.
 */
public class JsonUtil {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(JsonUtil.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    
    /**
     * Convert an object to JSON string
     * @param mapper The object mapper
     * @param object The object to convert
     * @return The JSON string
     */
    public static String toJson(ObjectMapper mapper, Object object) {
        if (object == null) {
            throw new RuntimeException("Failed to convert object to JSON: object is null");
        }
        
        try {
            return mapper.writeValueAsString(object);
        } catch (Exception e) {
            LOGGER.error("Failed to convert object to JSON", e);
            throw new RuntimeException("Failed to convert object to JSON", e);
        }
    }
    
    /**
     * Convert a JSON string to an object
     * @param mapper The object mapper
     * @param json The JSON string
     * @param clazz The class of the object
     * @return The object
     */
    public static <T> T fromJson(ObjectMapper mapper, String json, Class<T> clazz) {
        try {
            return mapper.readValue(json, clazz);
        } catch (Exception e) {
            LOGGER.error("Failed to convert JSON to object", e);
            throw new RuntimeException("Failed to convert JSON to object", e);
        }
    }
    
    /**
     * Create a new ObjectNode
     * @return A new ObjectNode
     */
    public static ObjectNode createObjectNode() {
        return OBJECT_MAPPER.createObjectNode();
    }
    
    /**
     * Convert a JsonNode to a string
     * @param node The JsonNode to convert
     * @return The JSON string
     */
    public static String toString(JsonNode node) {
        if (node == null) {
            throw new RuntimeException("Failed to convert JsonNode to string: node is null");
        }
        
        try {
            return OBJECT_MAPPER.writeValueAsString(node);
        } catch (Exception e) {
            LOGGER.error("Failed to convert JsonNode to string", e);
            throw new RuntimeException("Failed to convert JsonNode to string", e);
        }
    }
}
