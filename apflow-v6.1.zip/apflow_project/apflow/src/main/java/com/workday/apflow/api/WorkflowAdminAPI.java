package com.workday.apflow.api;

import com.workday.apflow.dto.response.WorkflowInstanceResponse;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * API for workflow administrative operations.
 * This interface provides methods for system-wide administration of workflows and tasks.
 */
public interface WorkflowAdminAPI {
    
    /**
     * Pause all running workflows
     * @param reason The reason for pausing
     * @return Number of workflows paused
     */
    int pauseAllWorkflows(String reason);
    
    /**
     * Resume all paused workflows
     * @return Number of workflows resumed
     */
    int resumeAllWorkflows();
    
    /**
     * Retry all failed tasks
     * @return Number of tasks retried
     */
    int retryAllFailedTasks();
    
    /**
     * Retry all failed workflows
     * @return Number of workflows retried
     */
    int retryAllFailedWorkflows();
    
    /**
     * Archive completed workflows older than a specified date
     * @param olderThan The date threshold for archiving
     * @return Number of workflows archived
     */
    int archiveCompletedWorkflows(Date olderThan);
    
    /**
     * Purge archived workflows older than a specified date
     * @param olderThan The date threshold for purging
     * @return Number of workflows purged
     */
    int purgeArchivedWorkflows(Date olderThan);
    
    /**
     * Get system configuration
     * @return System configuration as a map
     */
    Map<String, Object> getSystemConfiguration();
    
    /**
     * Update system configuration
     * @param configuration The updated configuration
     * @return Updated system configuration as a map
     */
    Map<String, Object> updateSystemConfiguration(Map<String, Object> configuration);
    
    /**
     * Get system health status
     * @return System health status as a map
     */
    Map<String, Object> getSystemHealthStatus();
    
    /**
     * Get workflow execution statistics
     * @param startDate The start date
     * @param endDate The end date
     * @return Workflow execution statistics as a map
     */
    Map<String, Object> getWorkflowExecutionStatistics(Date startDate, Date endDate);
    
    /**
     * Manage user roles for workflow assignments
     * @param userId The user ID
     * @param roles The roles to assign
     * @return Updated user roles as a map
     */
    Map<String, Object> manageUserRoles(String userId, List<String> roles);
    
    /**
     * Create workflow template
     * @param templateName The template name
     * @param templateDefinition The template definition
     * @return The created template ID
     */
    Integer createWorkflowTemplate(String templateName, Map<String, Object> templateDefinition);
    
    /**
     * Update workflow template
     * @param templateId The template ID
     * @param templateDefinition The updated template definition
     * @return The updated template ID
     */
    Integer updateWorkflowTemplate(Integer templateId, Map<String, Object> templateDefinition);
    
    /**
     * Get workflow templates
     * @return List of workflow templates as maps
     */
    List<Map<String, Object>> getWorkflowTemplates();
    
    /**
     * Run system diagnostics
     * @return Diagnostics results as a map
     */
    Map<String, Object> runSystemDiagnostics();
    
    /**
     * Migrate all workflow instances to a new version
     * @param sourceVersionId The source version ID
     * @param targetVersionId The target version ID
     * @return List of migrated workflow instance responses
     */
    List<WorkflowInstanceResponse> migrateAllWorkflowInstances(Integer sourceVersionId, Integer targetVersionId);
}
