package com.workday.apflow.dto.request;

import java.util.Objects;

/**
 * DTO for task instance requests.
 */
public class TaskInstanceRequest {
    
    private Integer workflowInstanceId;
    private String name;
    private String type;
    private String assignment;
    private String operatorId;
    private String operatorType;
    private String inputJson;
    
    /**
     * Default constructor
     */
    public TaskInstanceRequest() {
    }
    
    /**
     * Private constructor for builder
     */
    private TaskInstanceRequest(Builder builder) {
        this.workflowInstanceId = builder.workflowInstanceId;
        this.name = builder.name;
        this.type = builder.type;
        this.assignment = builder.assignment;
        this.operatorId = builder.operatorId;
        this.operatorType = builder.operatorType;
        this.inputJson = builder.inputJson;
    }
    
    /**
     * Get workflow instance ID
     * @return Workflow instance ID
     */
    public Integer getWorkflowInstanceId() {
        return workflowInstanceId;
    }
    
    /**
     * Set workflow instance ID
     * @param workflowInstanceId Workflow instance ID
     */
    public void setWorkflowInstanceId(Integer workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
    }
    
    /**
     * Get name
     * @return Name
     */
    public String getName() {
        return name;
    }
    
    /**
     * Set name
     * @param name Name
     */
    public void setName(String name) {
        this.name = name;
    }
    
    /**
     * Get type
     * @return Type
     */
    public String getType() {
        return type;
    }
    
    /**
     * Set type
     * @param type Type
     */
    public void setType(String type) {
        this.type = type;
    }
    
    /**
     * Get assignment
     * @return Assignment
     */
    public String getAssignment() {
        return assignment;
    }
    
    /**
     * Set assignment
     * @param assignment Assignment
     */
    public void setAssignment(String assignment) {
        this.assignment = assignment;
    }
    
    /**
     * Get operator ID
     * @return Operator ID
     */
    public String getOperatorId() {
        return operatorId;
    }
    
    /**
     * Set operator ID
     * @param operatorId Operator ID
     */
    public void setOperatorId(String operatorId) {
        this.operatorId = operatorId;
    }
    
    /**
     * Get operator type
     * @return Operator type
     */
    public String getOperatorType() {
        return operatorType;
    }
    
    /**
     * Set operator type
     * @param operatorType Operator type
     */
    public void setOperatorType(String operatorType) {
        this.operatorType = operatorType;
    }
    
    /**
     * Get input JSON
     * @return Input JSON
     */
    public String getInputJson() {
        return inputJson;
    }
    
    /**
     * Set input JSON
     * @param inputJson Input JSON
     */
    public void setInputJson(String inputJson) {
        this.inputJson = inputJson;
    }
    
    /**
     * Create a new builder
     * @return Builder
     */
    public static Builder builder() {
        return new Builder();
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TaskInstanceRequest that = (TaskInstanceRequest) o;
        return Objects.equals(workflowInstanceId, that.workflowInstanceId) &&
               Objects.equals(name, that.name) &&
               Objects.equals(type, that.type) &&
               Objects.equals(assignment, that.assignment) &&
               Objects.equals(operatorId, that.operatorId) &&
               Objects.equals(operatorType, that.operatorType) &&
               Objects.equals(inputJson, that.inputJson);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(workflowInstanceId, name, type, assignment, operatorId, operatorType, inputJson);
    }
    
    @Override
    public String toString() {
        return "TaskInstanceRequest{" +
               "workflowInstanceId=" + workflowInstanceId +
               ", name='" + name + '\'' +
               ", type='" + type + '\'' +
               ", assignment='" + assignment + '\'' +
               ", operatorId='" + operatorId + '\'' +
               ", operatorType='" + operatorType + '\'' +
               ", inputJson='" + inputJson + '\'' +
               '}';
    }
    
    /**
     * Builder for TaskInstanceRequest
     */
    public static class Builder {
        private Integer workflowInstanceId;
        private String name;
        private String type;
        private String assignment;
        private String operatorId;
        private String operatorType;
        private String inputJson;
        
        /**
         * Set workflow instance ID
         * @param workflowInstanceId Workflow instance ID
         * @return Builder
         */
        public Builder workflowInstanceId(Integer workflowInstanceId) {
            this.workflowInstanceId = workflowInstanceId;
            return this;
        }
        
        /**
         * Set name
         * @param name Name
         * @return Builder
         */
        public Builder name(String name) {
            this.name = name;
            return this;
        }
        
        /**
         * Set type
         * @param type Type
         * @return Builder
         */
        public Builder type(String type) {
            this.type = type;
            return this;
        }
        
        /**
         * Set assignment
         * @param assignment Assignment
         * @return Builder
         */
        public Builder assignment(String assignment) {
            this.assignment = assignment;
            return this;
        }
        
        /**
         * Set operator ID
         * @param operatorId Operator ID
         * @return Builder
         */
        public Builder operatorId(String operatorId) {
            this.operatorId = operatorId;
            return this;
        }
        
        /**
         * Set operator type
         * @param operatorType Operator type
         * @return Builder
         */
        public Builder operatorType(String operatorType) {
            this.operatorType = operatorType;
            return this;
        }
        
        /**
         * Set input JSON
         * @param inputJson Input JSON
         * @return Builder
         */
        public Builder inputJson(String inputJson) {
            this.inputJson = inputJson;
            return this;
        }
        
        /**
         * Build TaskInstanceRequest
         * @return TaskInstanceRequest
         */
        public TaskInstanceRequest build() {
            return new TaskInstanceRequest(this);
        }
    }
}
