package com.workday.apflow.error;

/**
 * Exception class for task-related errors.
 * Extends WorkflowException with task-specific information.
 */
public class TaskException extends WorkflowException {
    private final Integer taskInstanceId;
    
    /**
     * Constructor
     * @param message Error message
     * @param errorCode Error code from ErrorHandlingConstants
     * @param errorType Error type from ErrorHandlingConstants
     * @param recoverable Whether the error is recoverable
     */
    public TaskException(String message, String errorCode, String errorType, boolean recoverable) {
        super(message, errorCode, errorType, String.valueOf(recoverable));
        this.taskInstanceId = null;
    }
    
    /**
     * Constructor with task instance ID
     * @param message Error message
     * @param errorCode Error code from ErrorHandlingConstants
     * @param errorType Error type from ErrorHandlingConstants
     * @param recoverable Whether the error is recoverable
     * @param taskInstanceId The task instance ID
     */
    public TaskException(String message, String errorCode, String errorType, boolean recoverable, Integer taskInstanceId) {
        super(message, errorCode, errorType, String.valueOf(recoverable), taskInstanceId);
        this.taskInstanceId = taskInstanceId;
    }
    
    /**
     * Constructor with cause
     * @param message Error message
     * @param cause Cause of the exception
     * @param errorCode Error code from ErrorHandlingConstants
     * @param errorType Error type from ErrorHandlingConstants
     * @param recoverable Whether the error is recoverable
     */
    public TaskException(String message, Throwable cause, String errorCode, String errorType, boolean recoverable) {
        super(message, cause, errorCode, errorType, String.valueOf(recoverable));
        this.taskInstanceId = null;
    }
    
    /**
     * Constructor with cause and task instance ID
     * @param message Error message
     * @param cause Cause of the exception
     * @param errorCode Error code from ErrorHandlingConstants
     * @param errorType Error type from ErrorHandlingConstants
     * @param recoverable Whether the error is recoverable
     * @param taskInstanceId The task instance ID
     */
    public TaskException(String message, Throwable cause, String errorCode, String errorType, boolean recoverable, Integer taskInstanceId) {
        super(message, cause, errorCode, errorType, String.valueOf(recoverable));
        this.taskInstanceId = taskInstanceId;
    }
    
    /**
     * Get the task instance ID
     * @return Task instance ID
     */
    public Integer getTaskInstanceId() {
        return taskInstanceId;
    }
}
