package com.workday.apflow.constants;

/**
 * Constants for workflow related operations.
 */
public class WorkflowConstants {
    
    // Workflow Status
    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_RUNNING = "RUNNING";
    public static final String STATUS_COMPLETED = "COMPLETED";
    public static final String STATUS_FAILED = "FAILED";
    public static final String STATUS_TERMINATED = "TERMINATED";
    public static final String STATUS_PAUSED = "PAUSED";
    public static final String STATUS_CANCELLED = "CANCELLED";
    
    // Sequence Item Types
    public static final String TYPE_TASK = "TASK";
    public static final String TYPE_TASK_GROUP = "TASK_GROUP";
    
    // Field Names
    public static final String FIELD_TYPE = "type";
    public static final String FIELD_NAME = "name";
    public static final String FIELD_ID = "id";
    public static final String FIELD_CURRENT_POSITION = "currentPosition";
    public static final String FIELD_INITIALIZED = "initialized";
    public static final String FIELD_SEQUENCE = "sequence";
    public static final String FIELD_TASK_TYPE = "taskType";
    public static final String FIELD_ASSIGNMENT = "assignment";
    public static final String FIELD_TASK_INSTANCE_ID = "taskInstanceId";
    
    // Property Keys
    public static final String PROP_CURRENT_POSITION = "currentPosition";
    public static final String PROP_SEQUENCE = "sequence";
    public static final String PROP_TASK_GROUPS = "taskGroups";
    public static final String PROP_STANDALONE_TASKS = "standaloneTasks";
    public static final String PROP_METADATA = "metadata";
    public static final String PROP_INPUT_DATA = "inputData";
    public static final String PROP_OUTPUT_DATA = "outputData";
    
    private WorkflowConstants() {
        // Private constructor to prevent instantiation
    }
}
