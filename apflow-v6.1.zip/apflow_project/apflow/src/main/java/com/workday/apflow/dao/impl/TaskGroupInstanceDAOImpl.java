package com.workday.apflow.dao.impl;

import com.workday.apflow.dao.TaskGroupInstanceDAO;
import com.workday.apflow.model.TaskGroupInstance;
import com.workday.apflow.util.ClassProperties;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;

/**
 * PostgreSQL implementation of the TaskGroupInstanceDAO interface.
 */
public class TaskGroupInstanceDAOImpl implements TaskGroupInstanceDAO {
    private static final Logger LOGGER = Logger.getLogger(TaskGroupInstanceDAOImpl.class.getName());
    private final DataSource dataSource;

    /**
     * Constructor with DataSource injection.
     * 
     * @param dataSource The DataSource to use for database connections
     */
    public TaskGroupInstanceDAOImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public TaskGroupInstance createTaskGroupInstance(TaskGroupInstance taskGroup) {
        String sql = ClassProperties.getProperty("createTaskGroupInstance", "TaskGroupInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, taskGroup.getWorkflowInstanceId());
            stmt.setString(2, taskGroup.getName());
            stmt.setString(3, taskGroup.getType());
            stmt.setString(4, taskGroup.getStatus());
            
            if (taskGroup.getParentGroupId() != null) {
                stmt.setInt(5, taskGroup.getParentGroupId());
            } else {
                stmt.setNull(5, Types.INTEGER);
            }
            
            stmt.setString(6, taskGroup.getCreatedBy());
            stmt.setTimestamp(7, taskGroup.getCreatedAt() != null ? 
                    taskGroup.getCreatedAt() : 
                    new Timestamp(System.currentTimeMillis()));
            stmt.setString(8, taskGroup.getInputJson());
            stmt.setString(9, taskGroup.getPropertiesJson());
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTaskGroupInstance(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error creating task group instance", e);
        }
        
        return null;
    }

    @Override
    public TaskGroupInstance getTaskGroupInstance(Integer id) {
        String sql = ClassProperties.getProperty("getTaskGroupInstance", "TaskGroupInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTaskGroupInstance(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task group instance with ID: " + id, e);
        }
        
        return null;
    }

    @Override
    public TaskGroupInstance getTaskGroupInstanceByWorkflowAndTaskGroupId(Integer workflowInstanceId, String taskGroupId) {
        String sql = ClassProperties.getProperty("getTaskGroupInstanceByWorkflowAndTaskGroupId", "TaskGroupInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, workflowInstanceId);
            stmt.setString(2, taskGroupId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTaskGroupInstance(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task group instance for workflow ID: " + workflowInstanceId + 
                    " and task group ID: " + taskGroupId, e);
        }
        
        return null;
    }

    @Override
    public TaskGroupInstance updateTaskGroupInstance(TaskGroupInstance taskGroup) {
        String sql = ClassProperties.getProperty("updateTaskGroupInstance", "TaskGroupInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, taskGroup.getStatus());
            
            if (taskGroup.getStartedAt() != null) {
                stmt.setTimestamp(2, taskGroup.getStartedAt());
            } else {
                stmt.setNull(2, Types.TIMESTAMP);
            }
            
            if (taskGroup.getCompletedAt() != null) {
                stmt.setTimestamp(3, taskGroup.getCompletedAt());
            } else {
                stmt.setNull(3, Types.TIMESTAMP);
            }
            
            stmt.setString(4, taskGroup.getOutputJson());
            stmt.setString(5, taskGroup.getPropertiesJson());
            stmt.setInt(6, taskGroup.getId());
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTaskGroupInstance(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error updating task group instance with ID: " + taskGroup.getId(), e);
        }
        
        return null;
    }

    @Override
    public boolean deleteTaskGroupInstance(Integer id) {
        String sql = ClassProperties.getProperty("deleteTaskGroupInstance", "TaskGroupInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting task group instance with ID: " + id, e);
        }
        
        return false;
    }

    @Override
    public List<TaskGroupInstance> getTaskGroupInstancesByWorkflowId(Integer workflowInstanceId) {
        String sql = ClassProperties.getProperty("getTaskGroupInstancesByWorkflowId", "TaskGroupInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, workflowInstanceId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<TaskGroupInstance> taskGroupInstances = new ArrayList<>();
                while (rs.next()) {
                    taskGroupInstances.add(mapResultSetToTaskGroupInstance(rs));
                }
                return taskGroupInstances;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task group instances for workflow ID: " + workflowInstanceId, e);
        }
        
        return List.of();
    }

    @Override
    public List<TaskGroupInstance> getChildTaskGroupInstances(Integer parentGroupId) {
        String sql = ClassProperties.getProperty("getChildTaskGroupInstances", "TaskGroupInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, parentGroupId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<TaskGroupInstance> taskGroupInstances = new ArrayList<>();
                while (rs.next()) {
                    taskGroupInstances.add(mapResultSetToTaskGroupInstance(rs));
                }
                return taskGroupInstances;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting child task group instances for parent ID: " + parentGroupId, e);
        }
        
        return List.of();
    }

    @Override
    public List<TaskGroupInstance> getTopLevelTaskGroupInstances(Integer workflowInstanceId) {
        String sql = ClassProperties.getProperty("getTopLevelTaskGroupInstances", "TaskGroupInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, workflowInstanceId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<TaskGroupInstance> taskGroupInstances = new ArrayList<>();
                while (rs.next()) {
                    taskGroupInstances.add(mapResultSetToTaskGroupInstance(rs));
                }
                return taskGroupInstances;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting top-level task group instances for workflow ID: " + workflowInstanceId, e);
        }
        
        return List.of();
    }

    @Override
    public List<TaskGroupInstance> getTaskGroupInstancesByStatus(String status) {
        String sql = ClassProperties.getProperty("getTaskGroupInstancesByStatus", "TaskGroupInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<TaskGroupInstance> taskGroupInstances = new ArrayList<>();
                while (rs.next()) {
                    taskGroupInstances.add(mapResultSetToTaskGroupInstance(rs));
                }
                return taskGroupInstances;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task group instances with status: " + status, e);
        }
        
        return List.of();
    }

    @Override
    public List<TaskGroupInstance> getTaskGroupInstancesByType(String type) {
        String sql = ClassProperties.getProperty("getTaskGroupInstancesByType", "TaskGroupInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, type);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<TaskGroupInstance> taskGroupInstances = new ArrayList<>();
                while (rs.next()) {
                    taskGroupInstances.add(mapResultSetToTaskGroupInstance(rs));
                }
                return taskGroupInstances;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task group instances with type: " + type, e);
        }
        
        return List.of();
    }
    
    /**
     * Map a ResultSet row to a TaskGroupInstance object.
     * 
     * @param rs The ResultSet containing task group instance data
     * @return A populated TaskGroupInstance object
     * @throws SQLException If an error occurs accessing the ResultSet
     */
    private TaskGroupInstance mapResultSetToTaskGroupInstance(ResultSet rs) throws SQLException {
        TaskGroupInstance taskGroup = new TaskGroupInstance();
        
        taskGroup.setId(rs.getInt("id"));
        taskGroup.setWorkflowInstanceId(rs.getInt("workflow_instance_id"));
        taskGroup.setName(rs.getString("name"));
        taskGroup.setType(rs.getString("type"));
        taskGroup.setStatus(rs.getString("status"));
        
        int parentGroupId = rs.getInt("parent_group_id");
        if (!rs.wasNull()) {
            taskGroup.setParentGroupId(parentGroupId);
        }
        
        taskGroup.setCreatedBy(rs.getString("created_by"));
        
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            taskGroup.setCreatedAt(createdAt);
        }
        
        Timestamp startedAt = rs.getTimestamp("started_at");
        if (startedAt != null) {
            taskGroup.setStartedAt(startedAt);
        }
        
        Timestamp completedAt = rs.getTimestamp("completed_at");
        if (completedAt != null) {
            taskGroup.setCompletedAt(completedAt);
        }
        
        String inputJson = rs.getString("input_json");
        if (inputJson != null) {
            taskGroup.setInputJson(inputJson);
        }
        
        String outputJson = rs.getString("output_json");
        if (outputJson != null) {
            taskGroup.setOutputJson(outputJson);
        }
        
        String propertiesJson = rs.getString("properties_json");
        if (propertiesJson != null) {
            taskGroup.setPropertiesJson(propertiesJson);
        }
        
        return taskGroup;
    }
}
