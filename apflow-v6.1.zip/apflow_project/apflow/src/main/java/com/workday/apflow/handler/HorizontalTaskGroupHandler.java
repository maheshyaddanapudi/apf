package com.workday.apflow.handler;

import com.fasterxml.jackson.databind.JsonNode;
import com.workday.apflow.constants.TaskGroupConstants;
import com.workday.apflow.constants.TaskConstants;
import com.workday.apflow.dao.TaskGroupInstanceDAO;
import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.model.TaskGroupInstance;
import com.workday.apflow.model.TaskInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Implementation of the TaskGroupHandler interface for horizontal task groups.
 * Horizontal task groups execute tasks in parallel, typically for the same task type
 * across different assignments.
 */
public class HorizontalTaskGroupHandler implements TaskGroupHandler {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(HorizontalTaskGroupHandler.class);
    private final TaskGroupInstanceDAO taskGroupInstanceDAO;
    private final TaskInstanceDAO taskInstanceDAO;
    private final TaskHandlerRegistry taskHandlerRegistry;
    
    /**
     * Constructor
     * @param taskGroupInstanceDAO The task group instance DAO
     * @param taskInstanceDAO The task instance DAO
     * @param taskHandlerRegistry The task handler registry
     */
    public HorizontalTaskGroupHandler(
            TaskGroupInstanceDAO taskGroupInstanceDAO,
            TaskInstanceDAO taskInstanceDAO,
            TaskHandlerRegistry taskHandlerRegistry) {
        this.taskGroupInstanceDAO = taskGroupInstanceDAO;
        this.taskInstanceDAO = taskInstanceDAO;
        this.taskHandlerRegistry = taskHandlerRegistry;
    }
    
    @Override
    public String getType() {
        return TaskGroupConstants.TYPE_HORIZONTAL;
    }
    
    @Override
    public void initialize(TaskGroupInstance taskGroup) {
        LOGGER.info("Initializing horizontal task group: {} for workflow: {}", 
                   taskGroup.getId(), taskGroup.getWorkflowInstanceId());
        
        try {
            Map<String, Object> properties = taskGroup.getPropertiesMap();
            
            // Check if task group has branch property
            if (!properties.containsKey(TaskGroupConstants.PROP_BRANCH_PROPERTY)) {
                throw new RuntimeException("Horizontal task group missing branch property: " + taskGroup.getId());
            }
            
            // Check if task group has task template
            if (!properties.containsKey(TaskGroupConstants.PROP_TASK_TEMPLATE)) {
                throw new RuntimeException("Horizontal task group missing task template: " + taskGroup.getId());
            }
            
            // Initialize tasks array if not exists
            if (!properties.containsKey(TaskGroupConstants.PROP_TASKS)) {
                properties.put(TaskGroupConstants.PROP_TASKS, new ArrayList<Integer>());
            }
            
            // Update task group status
            taskGroup.setStatus(TaskGroupConstants.STATUS_RUNNING);
            taskGroup.setStartedAt(new Timestamp(System.currentTimeMillis()));
            taskGroup.setPropertiesMap(properties);
            
            // Save task group
            taskGroupInstanceDAO.updateTaskGroupInstance(taskGroup);
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to initialize horizontal task group: {} for workflow: {}", 
                        taskGroup.getId(), taskGroup.getWorkflowInstanceId(), e);
            throw e;
        }
    }
    
    @Override
    public void initialize(Integer workflowInstanceId, String taskGroupId, JsonNode state) {
        LOGGER.info("Initializing horizontal task group: {} for workflow: {}", 
                   taskGroupId, workflowInstanceId);
        
        try {
            // Find or create task group instance
            TaskGroupInstance taskGroup = taskGroupInstanceDAO.getTaskGroupInstanceByWorkflowAndTaskGroupId(
                workflowInstanceId, taskGroupId);
            
            if (taskGroup == null) {
                // Create new task group instance
                taskGroup = new TaskGroupInstance();
                taskGroup.setWorkflowInstanceId(workflowInstanceId);
                taskGroup.setTaskGroupId(taskGroupId);
                taskGroup.setType(getType());
                taskGroup.setStatus(TaskGroupConstants.STATUS_PENDING);
                taskGroup.setCreatedAt(new Timestamp(System.currentTimeMillis()));
                
                // Save task group
                taskGroupInstanceDAO.createTaskGroupInstance(taskGroup);
            }
            
            // Initialize task group
            initialize(taskGroup);
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to initialize horizontal task group: {} for workflow: {}", 
                        taskGroupId, workflowInstanceId, e);
            throw e;
        }
    }
    
    @Override
    public void execute(TaskGroupInstance taskGroup) {
        LOGGER.info("Executing horizontal task group: {} for workflow: {}", 
                   taskGroup.getId(), taskGroup.getWorkflowInstanceId());
        
        try {
            Map<String, Object> properties = taskGroup.getPropertiesMap();
            
            // Get branch property and task template
            String branchProperty = (String) properties.get(TaskGroupConstants.PROP_BRANCH_PROPERTY);
            Map<String, Object> taskTemplate = (Map<String, Object>) properties.get(TaskGroupConstants.PROP_TASK_TEMPLATE);
            
            // Get branch values
            List<String> branchValues;
            if (properties.containsKey(TaskGroupConstants.PROP_BRANCH_VALUES)) {
                branchValues = (List<String>) properties.get(TaskGroupConstants.PROP_BRANCH_VALUES);
            } else {
                // Branch values not provided, try to get from input
                Map<String, Object> inputMap = taskGroup.getInputMap();
                if (inputMap != null && inputMap.containsKey(branchProperty + "List")) {
                    branchValues = (List<String>) inputMap.get(branchProperty + "List");
                } else {
                    // No branch values found
                    throw new RuntimeException("Horizontal task group missing branch values: " + taskGroup.getId());
                }
            }
            
            // Create tasks for each branch value
            List<Integer> taskIds = new ArrayList<>();
            for (String branchValue : branchValues) {
                // Get task properties from template
                String taskType = (String) taskTemplate.get(TaskGroupConstants.PROP_TASK_TYPE);
                String taskName = (String) taskTemplate.get(TaskGroupConstants.PROP_TASK_NAME);
                
                // Create input map with branch value
                Map<String, Object> inputMap = new HashMap<>();
                inputMap.put(branchProperty, branchValue);
                
                // Get task handler
                TaskHandler handler = taskHandlerRegistry.getHandler(taskType);
                
                if (handler == null) {
                    throw new RuntimeException("Task handler not found for type: " + taskType);
                }
                
                // Create and execute task
                String assignment = branchValue; // Use branch value as assignment
                
                // Create task
                TaskInstance task = new TaskInstance();
                task.setWorkflowInstanceId(taskGroup.getWorkflowInstanceId());
                task.setTaskGroupInstanceId(taskGroup.getId());
                task.setName(taskName);
                task.setType(taskType);
                task.setStatus(TaskConstants.STATUS_PENDING);
                task.setAssignment(assignment);
                task.setInputMap(inputMap);
                task.setCreatedBy(taskGroup.getCreatedBy());
                task.setCreatedAt(new Timestamp(System.currentTimeMillis()));
                
                // Save task
                taskInstanceDAO.createTaskInstance(task);
                
                // Execute task
                handler.execute(task);
                
                // Add task ID to list
                taskIds.add(task.getId());
            }
            
            // Update task group with task IDs
            List<Integer> existingTasks = (List<Integer>) properties.get(TaskGroupConstants.PROP_TASKS);
            existingTasks.addAll(taskIds);
            properties.put(TaskGroupConstants.PROP_TASKS, existingTasks);
            taskGroup.setPropertiesMap(properties);
            
            // Save task group
            taskGroupInstanceDAO.updateTaskGroupInstance(taskGroup);
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to execute horizontal task group: {} for workflow: {}", 
                        taskGroup.getId(), taskGroup.getWorkflowInstanceId(), e);
            throw e;
        }
    }
    
    @Override
    public void process(TaskGroupInstance taskGroup) {
        LOGGER.info("Processing horizontal task group: {} for workflow: {}", 
                   taskGroup.getId(), taskGroup.getWorkflowInstanceId());
        
        try {
            // Check if task group is already initialized
            if (TaskGroupConstants.STATUS_PENDING.equals(taskGroup.getStatus())) {
                // Initialize task group
                initialize(taskGroup);
            }
            
            // Execute task group if it's in running state
            if (TaskGroupConstants.STATUS_RUNNING.equals(taskGroup.getStatus())) {
                // Check if all tasks are complete
                boolean isComplete = evaluateCompletionCriteria(taskGroup);
                
                if (isComplete) {
                    // Update task group status to completed
                    taskGroup.setStatus(TaskGroupConstants.STATUS_COMPLETED);
                    taskGroup.setCompletedAt(new Timestamp(System.currentTimeMillis()));
                    taskGroupInstanceDAO.updateTaskGroupInstance(taskGroup);
                }
            }
        } catch (RuntimeException e) {
            LOGGER.error("Failed to process horizontal task group: {} for workflow: {}", 
                        taskGroup.getId(), taskGroup.getWorkflowInstanceId(), e);
            throw e;
        }
    }
    
    @Override
    public boolean evaluateCompletionCriteria(TaskGroupInstance taskGroup) {
        LOGGER.info("Evaluating completion criteria for horizontal task group: {} for workflow: {}", 
                   taskGroup.getId(), taskGroup.getWorkflowInstanceId());
        
        try {
            Map<String, Object> properties = taskGroup.getPropertiesMap();
            
            // Check if task group has tasks
            if (!properties.containsKey(TaskGroupConstants.PROP_TASKS)) {
                // No tasks created yet, not complete
                return false;
            }
            
            // Get tasks array
            List<Integer> tasksArray = (List<Integer>) properties.get(TaskGroupConstants.PROP_TASKS);
            
            // If no tasks, not complete
            if (tasksArray.isEmpty()) {
                return false;
            }
            
            // Get completion criteria
            String completionCriteria = TaskGroupConstants.COMPLETION_ALL; // Default to ALL
            if (properties.containsKey(TaskGroupConstants.PROP_COMPLETION_CRITERIA)) {
                completionCriteria = (String) properties.get(TaskGroupConstants.PROP_COMPLETION_CRITERIA);
                
                // Validate completion criteria
                if (!TaskGroupConstants.COMPLETION_ALL.equals(completionCriteria) && 
                    !TaskGroupConstants.COMPLETION_ANY.equals(completionCriteria)) {
                    throw new RuntimeException("Unknown completion criteria: " + completionCriteria);
                }
            }
            
            // Get min completion count
            int minCompletion = 1; // Default to 1
            if (properties.containsKey(TaskGroupConstants.PROP_MIN_COMPLETION)) {
                minCompletion = (int) properties.get(TaskGroupConstants.PROP_MIN_COMPLETION);
            }
            
            // Check task completion based on criteria
            if (TaskGroupConstants.COMPLETION_ALL.equals(completionCriteria)) {
                // All tasks must be complete
                int completedCount = 0;
                for (Integer taskId : tasksArray) {
                    TaskInstance task = taskInstanceDAO.getTaskInstance(taskId);
                    if (task != null && (
                        TaskConstants.STATUS_COMPLETED.equals(task.getStatus()) ||
                        TaskConstants.STATUS_FAILED.equals(task.getStatus()) ||
                        TaskConstants.STATUS_TERMINATED.equals(task.getStatus()))) {
                        completedCount++;
                    }
                }
                
                return completedCount >= tasksArray.size();
                
            } else if (TaskGroupConstants.COMPLETION_ANY.equals(completionCriteria)) {
                // At least minCompletion tasks must be complete
                int completedCount = 0;
                for (Integer taskId : tasksArray) {
                    TaskInstance task = taskInstanceDAO.getTaskInstance(taskId);
                    if (task != null && (
                        TaskConstants.STATUS_COMPLETED.equals(task.getStatus()) ||
                        TaskConstants.STATUS_FAILED.equals(task.getStatus()) ||
                        TaskConstants.STATUS_TERMINATED.equals(task.getStatus()))) {
                        completedCount++;
                        if (completedCount >= minCompletion) {
                            return true;
                        }
                    }
                }
                
                return false;
            } else {
                // This should never happen due to validation above, but keeping for safety
                throw new RuntimeException("Unknown completion criteria: " + completionCriteria);
            }
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to evaluate completion criteria for horizontal task group: {} for workflow: {}", 
                        taskGroup.getId(), taskGroup.getWorkflowInstanceId(), e);
            throw e;
        }
    }
    
    @Override
    public boolean evaluateCompletionCriteria(Integer workflowInstanceId, String taskGroupId, JsonNode state) {
        LOGGER.info("Evaluating completion criteria for horizontal task group: {} for workflow: {}", 
                   taskGroupId, workflowInstanceId);
        
        try {
            // Find task group instance
            TaskGroupInstance taskGroup = taskGroupInstanceDAO.getTaskGroupInstanceByWorkflowAndTaskGroupId(
                workflowInstanceId, taskGroupId);
            
            if (taskGroup == null) {
                // Task group not found, not complete
                return false;
            }
            
            // Evaluate completion criteria
            return evaluateCompletionCriteria(taskGroup);
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to evaluate completion criteria for horizontal task group: {} for workflow: {}", 
                        taskGroupId, workflowInstanceId, e);
            throw e;
        }
    }
    
    @Override
    public TaskGroupInstance createAndInitialize(Integer workflowInstanceId, String name, Map<String, Object> inputMap, Integer parentGroupId, String createdBy) {
        LOGGER.info("Creating and initializing horizontal task group: {} for workflow: {}", 
                   name, workflowInstanceId);
        
        try {
            // Create task group instance
            TaskGroupInstance taskGroup = new TaskGroupInstance();
            taskGroup.setWorkflowInstanceId(workflowInstanceId);
            taskGroup.setName(name);
            taskGroup.setType(getType());
            taskGroup.setStatus(TaskGroupConstants.STATUS_PENDING);
            taskGroup.setParentGroupId(parentGroupId);
            taskGroup.setCreatedBy(createdBy);
            taskGroup.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            taskGroup.setInputMap(inputMap);
            
            // Save task group
            taskGroupInstanceDAO.createTaskGroupInstance(taskGroup);
            
            // Initialize task group
            initialize(taskGroup);
            
            return taskGroup;
            
        } catch (RuntimeException e) {
            LOGGER.error("Failed to create and initialize horizontal task group: {} for workflow: {}", 
                        name, workflowInstanceId, e);
            throw e;
        }
    }
    
    @Override
    public List<TaskInstance> getTasks(Integer taskGroupId) {
        return taskInstanceDAO.getTaskInstancesByTaskGroupId(taskGroupId);
    }
    
    @Override
    public List<TaskGroupInstance> getChildGroups(Integer taskGroupId) {
        return taskGroupInstanceDAO.getChildTaskGroupInstances(taskGroupId);
    }
}
