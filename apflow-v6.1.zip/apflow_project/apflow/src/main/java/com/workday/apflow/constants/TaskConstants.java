package com.workday.apflow.constants;

/**
 * Constants for task related operations.
 */
public class TaskConstants {
    
    // Task Status
    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_RUNNING = "RUNNING";
    public static final String STATUS_IN_PROGRESS = "IN_PROGRESS";
    public static final String STATUS_COMPLETED = "COMPLETED";
    public static final String STATUS_FAILED = "FAILED";
    public static final String STATUS_TERMINATED = "TERMINATED";
    
    // Task Types
    public static final String TYPE_TODO = "TODO";
    public static final String TYPE_APPROVAL = "APPROVAL";
    public static final String TYPE_NOTIFICATION = "NOTIFICATION";
    
    // Property Keys
    public static final String PROP_ASSIGNMENT = "assignment";
    public static final String PROP_TASK_GROUP_ID = "taskGroupId";
    public static final String PROP_RETRY_COUNT = "retryCount";
    public static final String PROP_MAX_RETRIES = "maxRetries";
    public static final String PROP_DUE_DATE = "dueDate";
    public static final String PROP_PRIORITY = "priority";
    
    private TaskConstants() {
        // Private constructor to prevent instantiation
    }
}
