package com.workday.apflow.monitoring;

import com.workday.apflow.dto.response.MetricsResponse;
import com.workday.apflow.dto.response.SlaStatusResponse;
import com.workday.apflow.constants.MonitoringConstants;
import java.util.HashMap;
import java.util.Map;

/**
 * Service for monitoring SLA (Service Level Agreement) compliance.
 * Provides methods for checking and alerting on SLA status.
 */
public class SlaMonitor {
    
    private final MetricsCollector metricsCollector;
    
    /**
     * Constructor
     * @param metricsCollector The metrics collector
     */
    public SlaMonitor(MetricsCollector metricsCollector) {
        this.metricsCollector = metricsCollector;
    }
    
    /**
     * Check SLA status for a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return SLA status
     */
    public SlaStatus checkSlaStatus(Integer workflowInstanceId) {
        SlaStatusResponse slaResponse = metricsCollector.getSlaStatus(workflowInstanceId);
        
        if (slaResponse == null) {
            return SlaStatus.UNKNOWN;
        }
        
        String status = slaResponse.getStatus();
        
        if (MonitoringConstants.SLA_STATUS_ON_TRACK.equals(status)) {
            return SlaStatus.ON_TRACK;
        } else if (MonitoringConstants.SLA_STATUS_AT_RISK.equals(status)) {
            return SlaStatus.AT_RISK;
        } else if (MonitoringConstants.SLA_STATUS_BREACHED.equals(status)) {
            return SlaStatus.BREACHED;
        } else {
            return SlaStatus.UNKNOWN;
        }
    }
    
    /**
     * Get SLA metrics for a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return Map of SLA metrics
     */
    public Map<String, Object> getSlaMetrics(Integer workflowInstanceId) {
        MetricsResponse metricsResponse = metricsCollector.getWorkflowMetrics(workflowInstanceId);
        
        if (metricsResponse == null) {
            return new HashMap<>();
        }
        
        return metricsResponse.getMetrics();
    }
    
    /**
     * Alert on SLA breach
     * @param workflowInstanceId The workflow instance ID
     * @param reason The reason for the breach
     */
    public void alertOnSlaBreach(Integer workflowInstanceId, String reason) {
        // In a real implementation, this would send alerts via email, SMS, etc.
        // For now, just log the alert
        System.out.println("SLA BREACH ALERT: Workflow " + workflowInstanceId + " - " + reason);
    }
}
