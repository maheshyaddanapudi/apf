package com.workday.apflow.constants;

/**
 * Constants for DTO classes.
 */
public class DtoConstants {
    
    // Sequence item types
    public static final String TYPE_OPERATOR = "OPERATOR";
    public static final String TYPE_TASK = "TASK";
    
    // Common fields
    public static final String FIELD_ID = "id";
    public static final String FIELD_TYPE = "type";
    public static final String FIELD_NAME = "name";
    
    // Workflow instance fields
    public static final String FIELD_SEQUENCE = "sequence";
    public static final String FIELD_CURRENT_POSITION = "currentPosition";
    public static final String FIELD_OPERATORS = "operators";
    public static final String FIELD_STANDALONE_TASKS = "standaloneTasks";
    
    // Operator fields
    public static final String FIELD_OPERATOR_TYPE = "operatorType";
    public static final String FIELD_INITIALIZED = "initialized";
    public static final String FIELD_PROPERTIES = "properties";
    public static final String FIELD_TASKS = "tasks";
    
    // Task fields
    public static final String FIELD_TASK_TYPE = "taskType";
    public static final String FIELD_TASK_ID = "taskId";
    public static final String FIELD_TASK_INSTANCE_ID = "taskInstanceId";
    public static final String FIELD_ASSIGNMENT = "assignment";
    public static final String FIELD_OPERATOR_ID = "operatorId";
    public static final String FIELD_INPUT_JSON = "inputJson";
    
    private DtoConstants() {
        // Private constructor to prevent instantiation
    }
}
