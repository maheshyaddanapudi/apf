-- New schema for SME Workflow Engine with Task Group support
-- This schema supports task group-based workflow execution while maintaining instance_json

-- Create workflow_instance table
CREATE TABLE workflow_instance (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL,
    created_by VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    termination_reason TEXT,
    input_json JSON,
    output_json JSON,
    instance_json JSON NOT NULL
);

-- Create task_group_instance table
CREATE TABLE task_group_instance (
    id SERIAL PRIMARY KEY,
    workflow_instance_id INTEGER NOT NULL,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    parent_group_id INTEGER,
    created_by VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    input_json JSON,
    output_json JSON,
    properties_json JSON,
    CONSTRAINT fk_workflow_instance FOREIGN KEY (workflow_instance_id) REFERENCES workflow_instance(id) ON DELETE CASCADE,
    CONSTRAINT fk_parent_group FOREIGN KEY (parent_group_id) REFERENCES task_group_instance(id) ON DELETE CASCADE
);

-- Create task_instance table
CREATE TABLE task_instance (
    id SERIAL PRIMARY KEY,
    workflow_instance_id INTEGER NOT NULL,
    task_group_instance_id INTEGER,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL,
    assignment VARCHAR(255),
    created_by VARCHAR(255) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    failure_reason TEXT,
    retry_count INTEGER DEFAULT 0,
    input_json JSON,
    output_json JSON,
    properties_json JSON,
    CONSTRAINT fk_workflow_instance_task FOREIGN KEY (workflow_instance_id) REFERENCES workflow_instance(id) ON DELETE CASCADE,
    CONSTRAINT fk_task_group_instance FOREIGN KEY (task_group_instance_id) REFERENCES task_group_instance(id) ON DELETE SET NULL
);

-- Create workflow_execution_queue table
CREATE TABLE workflow_execution_queue (
    id SERIAL PRIMARY KEY,
    workflow_instance_id INTEGER NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP,
    CONSTRAINT fk_workflow_instance_queue FOREIGN KEY (workflow_instance_id) REFERENCES workflow_instance(id) ON DELETE CASCADE
);

-- Create workflow_history table
CREATE TABLE workflow_history (
    id SERIAL PRIMARY KEY,
    workflow_instance_id INTEGER NOT NULL,
    task_instance_id INTEGER,
    task_group_instance_id INTEGER,
    event_type VARCHAR(50) NOT NULL,
    event_details JSON,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(255) NOT NULL,
    CONSTRAINT fk_workflow_instance_history FOREIGN KEY (workflow_instance_id) REFERENCES workflow_instance(id) ON DELETE CASCADE,
    CONSTRAINT fk_task_instance_history FOREIGN KEY (task_instance_id) REFERENCES task_instance(id) ON DELETE SET NULL,
    CONSTRAINT fk_task_group_instance_history FOREIGN KEY (task_group_instance_id) REFERENCES task_group_instance(id) ON DELETE SET NULL
);

-- Create indexes
CREATE INDEX idx_workflow_instance_status ON workflow_instance(status);
CREATE INDEX idx_task_group_instance_workflow_id ON task_group_instance(workflow_instance_id);
CREATE INDEX idx_task_group_instance_parent_id ON task_group_instance(parent_group_id);
CREATE INDEX idx_task_group_instance_status ON task_group_instance(status);
CREATE INDEX idx_task_instance_workflow_id ON task_instance(workflow_instance_id);
CREATE INDEX idx_task_instance_task_group_id ON task_instance(task_group_instance_id);
CREATE INDEX idx_task_instance_status ON task_instance(status);
CREATE INDEX idx_task_instance_assignment ON task_instance(assignment);
CREATE INDEX idx_workflow_execution_queue_status ON workflow_execution_queue(status);
CREATE INDEX idx_workflow_history_workflow_id ON workflow_history(workflow_instance_id);
CREATE INDEX idx_workflow_history_task_id ON workflow_history(task_instance_id);
CREATE INDEX idx_workflow_history_task_group_id ON workflow_history(task_group_instance_id);

-- Create JSONB indexes for efficient JSON queries
CREATE INDEX idx_workflow_instance_instance_json ON workflow_instance USING GIN (instance_json);
CREATE INDEX idx_workflow_instance_input_json ON workflow_instance USING GIN (input_json);
CREATE INDEX idx_workflow_instance_output_json ON workflow_instance USING GIN (output_json);
CREATE INDEX idx_task_group_instance_input_json ON task_group_instance USING GIN (input_json);
CREATE INDEX idx_task_group_instance_output_json ON task_group_instance USING GIN (output_json);
CREATE INDEX idx_task_group_instance_properties_json ON task_group_instance USING GIN (properties_json);
CREATE INDEX idx_task_instance_input_json ON task_instance USING GIN (input_json);
CREATE INDEX idx_task_instance_output_json ON task_instance USING GIN (output_json);
CREATE INDEX idx_task_instance_properties_json ON task_instance USING GIN (properties_json);
CREATE INDEX idx_workflow_history_event_details ON workflow_history USING GIN (event_details);
