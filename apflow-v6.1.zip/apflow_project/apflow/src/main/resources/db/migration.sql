-- Migration script to update database schema
-- Removes definition tables and adds instance_json to workflow_instance

-- Step 1: Add instance_json column to workflow_instance table
ALTER TABLE workflow_instance ADD COLUMN instance_json JSON NOT NULL DEFAULT '{}';

-- Step 2: Drop foreign key constraints from tables that reference definition tables
ALTER TABLE task_instance DROP CONSTRAINT IF EXISTS fk_task_definition;
ALTER TABLE workflow_instance DROP CONSTRAINT IF EXISTS fk_workflow_definition;

-- Step 3: Drop definition tables
DROP TABLE IF EXISTS task_group_instances CASCADE;
DROP TABLE IF EXISTS task_group_definitions CASCADE;
DROP TABLE IF EXISTS task_definitions CASCADE;
DROP TABLE IF EXISTS workflow_definitions CASCADE;

-- Step 4: Remove definition_id columns from instance tables
ALTER TABLE workflow_instance DROP COLUMN IF EXISTS workflow_definition_id;
ALTER TABLE task_instance DROP COLUMN IF EXISTS task_definition_id;

-- Step 5: Create new indexes for JSON fields
CREATE INDEX IF NOT EXISTS idx_workflow_instance_instance_json ON workflow_instance USING GIN (instance_json);
