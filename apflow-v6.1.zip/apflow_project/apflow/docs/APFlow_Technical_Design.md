# APFlow: Unified Technical Design Document

## 1. Introduction

APFlow is a robust Java library designed for workflow orchestration and state management in enterprise applications. This document provides a comprehensive technical overview of the APFlow system architecture, components, execution flow, and extension points.

## 2. System Architecture

APFlow follows a layered architecture with clear separation of concerns, designed to be integrated into any Java application without Spring Boot dependencies.

![System Architecture](../sme_project/sme_code/docs/diagrams/system_architecture.svg)

### 2.1 Architectural Layers

1. **API Layer**
   - Provides interfaces for interacting with the engine
   - Includes APIs for workflow instances, task management, history, administration, and monitoring

2. **Service Layer**
   - Implements business logic for workflow execution
   - Handles workflow instance operations, task completion, and workflow migration

3. **Execution Layer**
   - Manages workflow state and execution flow
   - Includes the state manager, execution sweeper, and queuing interceptor

4. **Handler Layer**
   - Contains task and task group handlers for different types of tasks
   - Provides extension points for custom task and task group implementations

5. **Data Access Layer**
   - Provides database access through DAO interfaces
   - Abstracts database operations for workflow and task persistence

## 3. Core Components

### 3.1 Workflow State Manager

The `WorkflowStateManager` is the central component responsible for:
- Processing workflow instances based on their current state
- Coordinating with task groups and task handlers
- Managing workflow state transitions
- Ensuring proper workflow progression

The state manager uses a DTO-based approach to represent workflow instances, with all sequence details maintained in the instance JSON structure.

### 3.2 Task Handler Framework

![Task Lifecycle](../sme_project/sme_code/docs/diagrams/task-lifecycle-diagram.svg)

The task handler framework consists of:
- `TaskHandler` interface: Defines methods for creating, executing, and completing tasks
- `TaskHandlerRegistry`: Maintains a registry of task handlers and provides them when needed
- Concrete task handler implementations (e.g., `ToDoTaskHandler`)

Task handlers use Map<String, Object> for input and output data instead of string literals, providing better type safety and maintainability.

### 3.3 Task Group Framework

The task group framework includes:
- `TaskGroupHandler` interface: Defines methods for initializing, executing, and evaluating task groups
- `TaskGroupHandlerRegistry`: Maintains a registry of task group handlers and provides them when needed
- Concrete task group implementations:
  - `HorizontalTaskGroupHandler`: Executes tasks in parallel
  - `VerticalTaskGroupHandler`: Executes tasks in sequence

#### 3.3.1 Horizontal Task Group

The Horizontal Task Group enables parallel execution of tasks of the same type across multiple items:

- **Use Case**: Processing a list of items with the same operation (e.g., approval requests for multiple documents)
- **Implementation**: The `HorizontalTaskGroupHandler` creates and manages task instances for each item in the input list
- **Execution Pattern**: All tasks are initialized at once and can be executed in parallel
- **Completion Logic**: The group is considered complete when all child tasks are completed

#### 3.3.2 Vertical Task Group

The Vertical Task Group enables sequential execution of different task types:

- **Use Case**: Multi-step processes where tasks must be executed in a specific order (e.g., review → approve → publish)
- **Implementation**: The `VerticalTaskGroupHandler` manages the sequence of tasks and their dependencies
- **Execution Pattern**: Tasks are executed one after another based on the defined sequence
- **Completion Logic**: The group is considered complete when the last task in the sequence is completed

### 3.4 Execution Sweeper

The `WorkflowExecutionSweeper` processes pending queue entries and triggers workflow execution. It works in conjunction with:
- `ExecutionQueuingInterceptor`: Intercepts task completions and workflow resume events
- `WorkflowExecutionQueueDAO`: Manages the queue of workflow instances waiting to be processed

### 3.5 DTO-Based JSON Handling

The engine uses DTOs for JSON handling instead of string literals:
- `WorkflowInstanceDTO`: Represents a workflow instance
- `TaskGroupDTO`: Represents a task group state
- `SequenceItemDTO`: Base class for sequence items
- `TaskGroupSequenceItemDTO`: Represents a task group in a sequence
- `TaskSequenceItemDTO`: Represents a task in a sequence

## 4. Database Schema

![Database ERD](../sme_project/sme_code/docs/diagrams/database_erd.svg)

The database schema includes the following tables:

### 4.1 Workflow Instance Table

The `workflow_instance` table stores:
- Workflow metadata (ID, name, creator)
- Instance JSON containing the complete workflow definition and state
- Status and timestamps (created, updated, completed)

### 4.2 Task Group Instance Table

The `task_group_instance` table stores:
- Task group metadata (ID, name, type)
- Execution state (status, timestamps)
- Parent-child relationships for nested task groups
- Input/output data and custom properties

### 4.3 Task Instance Table

The `task_instance` table stores:
- Task metadata (ID, name, type)
- Execution state (status, timestamps)
- Assignment information
- Input/output data
- Optional reference to parent task group

### 4.4 Workflow Execution Queue Table

The `workflow_execution_queue` table manages:
- Workflow instances waiting to be processed
- Priority and timestamp information
- Execution status

### 4.5 Workflow History Table

The `workflow_history` table tracks:
- Workflow, task group, and task events
- State transitions
- User actions
- Timestamps for audit and debugging

## 5. Workflow Lifecycle

![Workflow Lifecycle](../sme_project/sme_code/docs/diagrams/workflow-lifecycle-diagram.svg)

### 5.1 Workflow Creation

1. Create a `WorkflowInstanceRequest` with workflow metadata
2. Define the sequence of tasks and task groups
3. Set input data for tasks and task groups
4. Call `createWorkflowInstance` on the `WorkflowInstanceAPI`

### 5.2 Workflow Execution

#### 5.2.1 Two-Layer Execution Approach

APFlow implements a two-layer approach for workflow execution:

1. **Primary Path (Direct Execution)**:
   - Task completion request → Task handler → Interceptor → Direct call to State Manager
   - This is the optimized fast path for normal execution flow
   - Most workflow state transitions happen through this path

2. **Fallback Path (Sweeper-based Execution)**:
   - Only used when the State Manager fails to process the workflow
   - Failed executions are queued for retry through the Sweeper
   - Provides resilience and recovery for transient failures

#### 5.2.2 Sweeper Initialization Behavior

- **On startup**: Processes all pending, in-progress, and failed queue entries
- **Subsequent sweeps**: Only processes failed entries
- This approach optimizes system resources while ensuring reliability

#### 5.2.3 Execution Flow

1. The `WorkflowStateManager` processes the workflow instance:
   - Parses the instance JSON to determine the current state
   - Identifies the next task or task group to execute
   - Delegates execution to the appropriate handler

2. For task groups:
   - The `TaskGroupHandler` initializes the task group
   - Creates and executes child tasks according to the group's pattern
   - Tracks completion status of the group

3. For individual tasks:
   - The `TaskHandler` creates and executes the task
   - Updates task status and output data
   - When task is completed, the handler calls the interceptor
   - The interceptor directly calls the State Manager to progress the workflow
   - Only if the State Manager processing fails, the execution is queued for retry by the Sweeper

### 5.3 Workflow Completion

1. When all tasks and task groups in the sequence are complete, the workflow is marked as completed
2. Final output data is collected from tasks
3. Workflow history is updated with completion event

### 5.4 Workflow Monitoring

1. Use `WorkflowMonitoringAPI` to track workflow progress
2. Monitor SLA compliance and performance metrics
3. Access audit events for debugging and compliance

## 6. JSON Structure

The instance JSON maintains the sequence of tasks and task groups, along with their execution state:

```json
{
  "sequence": [
    {
      "type": "TASK",
      "id": "task1"
    },
    {
      "type": "TASK_GROUP",
      "id": "group1"
    }
  ],
  "currentPosition": 1,
  "taskGroups": {
    "group1": {
      "type": "HORIZONTAL",
      "initialized": true,
      "state": {
        "tasksCreated": ["task2", "task3"],
        "tasksCompleted": ["task2"]
      },
      "inputJson": {
        "items": ["item1", "item2"]
      }
    }
  },
  "standaloneTasks": {
    "task1": { 
      "status": "COMPLETED",
      "output": {
        "result": "approved"
      }
    }
  }
}
```

## 7. API Interfaces

![Class Diagram](../sme_project/sme_code/docs/diagrams/class_diagram.svg)

APFlow exposes the following primary API interfaces:

### 7.1 WorkflowInstanceAPI

Provides methods for creating, retrieving, and managing workflow instances:
- Creating and starting workflow instances
- Retrieving workflow instances by ID, status, or creator
- Pausing, resuming, and canceling workflow instances
- Updating workflow instances
- Migrating workflow instances to new versions

### 7.2 TaskManagementAPI

Provides methods for managing task instances:
- Creating and retrieving task instances
- Completing, canceling, and skipping tasks
- Reassigning tasks to different users
- Retrying failed tasks
- Updating task properties

### 7.3 WorkflowHistoryAPI

Provides methods for retrieving historical information:
- Getting workflow history by workflow or task ID
- Retrieving history by date range, user, or status
- Exporting workflow history in different formats
- Accessing audit events

### 7.4 WorkflowAdminAPI

Provides methods for system-wide administration:
- Pausing and resuming all workflows
- Retrying failed tasks and workflows
- Archiving and purging workflows
- Managing system configuration
- Monitoring system health
- Running diagnostics

### 7.5 WorkflowMonitoringAPI

Provides methods for monitoring performance and SLA compliance:
- Getting workflow and task metrics
- Checking SLA status
- Retrieving SLA violations
- Accessing audit events
- Defining SLAs
- Getting performance dashboard data

## 8. Extension Points

APFlow provides several extension points for customization:

### 8.1 Custom Task Handlers

1. Implement the `TaskHandler` interface:
   - Define the task type
   - Implement creation, execution, and completion logic
   - Handle task-specific business rules

2. Register the handler with the `TaskHandlerRegistry`

### 8.2 Custom Task Group Handlers

1. Implement the `TaskGroupHandler` interface:
   - Define the task group type
   - Implement initialization, execution, and completion logic
   - Handle group-specific execution patterns

2. Register the handler with the `TaskGroupHandlerRegistry`

### 8.3 Custom DAO Implementations

1. Implement the DAO interfaces:
   - `WorkflowInstanceDAO`
   - `TaskInstanceDAO`
   - `TaskGroupInstanceDAO`
   - `WorkflowExecutionQueueDAO`
   - `WorkflowHistoryDAO`

2. Configure the engine to use the custom implementations

## 9. Performance Considerations

### 9.1 Parallel Execution

Horizontal task groups enable efficient parallel processing:
- Multiple tasks can be executed simultaneously
- System resources are utilized more effectively
- Overall workflow execution time is reduced for suitable workloads

### 9.2 Optimized State Management

Task group-based state management reduces overhead:
- Group-level state changes reduce the number of database operations
- Batch processing of related tasks improves efficiency
- Reduced contention on workflow instance records

### 9.3 Execution Queuing

The execution queuing system manages system load:
- Prioritizes workflow execution
- Prevents resource exhaustion
- Enables controlled scaling

### 9.4 Database Optimization

- JSON indexes for efficient querying of instance JSON
- Appropriate indexing on frequently queried columns
- Archiving of completed workflows to maintain performance

## 10. Integration Patterns

### 10.1 Library Integration

APFlow can be integrated as a library dependency:
- Add the library to your project dependencies
- Initialize the engine components
- Use the API interfaces to interact with the engine

### 10.2 Service Integration

APFlow can be exposed as a service:
- Create service interfaces that wrap the API interfaces
- Expose the services through your application's service layer
- Use dependency injection to provide the services to clients

### 10.3 Event-Driven Integration

APFlow can be integrated with event-driven architectures:
- Configure the engine to publish events on workflow and task state changes
- Subscribe to events for asynchronous processing
- Use event handlers to trigger external systems

## 11. Migration Capabilities

APFlow includes workflow migration capabilities:

### 11.1 Workflow Version Migration

- Migrate workflow instances to newer workflow definitions
- Preserve the current state of the workflow
- Adjust runtime execution based on the new definition
- Completed tasks are preserved during migration

### 11.2 Migration Process

1. Create a new workflow definition version
2. Use the `migrateWorkflowInstance` method to migrate a specific workflow
3. Or use the `migrateAllWorkflowInstances` method to migrate all workflows of a specific version
4. The engine handles state mapping between versions

## 12. Conclusion

APFlow provides a robust, flexible, and extensible framework for workflow orchestration and state management. Its decoupled architecture, task group-based approach, and comprehensive API interfaces make it suitable for a wide range of enterprise applications.

Key strengths include:
- Decoupled architecture with clear separation of concerns
- DTO-based JSON handling for better type safety
- Flexible task group framework for complex workflows
- Extensible task handler framework
- Robust state management
- Comprehensive monitoring and administration capabilities
- Library-only implementation for easy integration
