# APFlow API Documentation

## Overview

APFlow is a comprehensive workflow engine API library that provides a robust framework for creating, managing, and monitoring workflow processes. The library offers a set of well-defined interfaces for workflow instance management, task management, workflow history tracking, administrative operations, and performance monitoring.

This document provides a concise reference of the core APIs available in APFlow, designed for architects and senior developers implementing workflow solutions.

## Core APIs

APFlow exposes the following primary API interfaces:

1. **WorkflowInstanceAPI** - For creating and managing workflow instances
2. **TaskManagementAPI** - For handling individual task operations
3. **WorkflowHistoryAPI** - For accessing historical workflow data
4. **WorkflowAdminAPI** - For system-wide administrative operations
5. **WorkflowMonitoringAPI** - For monitoring performance and SLA compliance

## WorkflowInstanceAPI

The WorkflowInstanceAPI provides methods for creating, retrieving, and managing workflow instances.

### Key Methods

| Method | Description | Parameters | Return Type |
|--------|-------------|------------|-------------|
| createWorkflowInstance | Creates a new workflow instance | WorkflowInstanceRequest | WorkflowInstanceResponse |
| startWorkflowInstance | Starts a workflow instance | Integer workflowInstanceId | WorkflowInstanceResponse |
| getWorkflowInstance | Retrieves a workflow instance | Integer workflowInstanceId | WorkflowInstanceResponse |
| getWorkflowInstancesByStatus | Retrieves workflows by status | String status | List\<WorkflowInstanceResponse\> |
| cancelWorkflowInstance | Cancels a workflow instance | Integer workflowInstanceId | WorkflowInstanceResponse |
| pauseWorkflowInstance | Pauses a running workflow | Integer workflowInstanceId | WorkflowInstanceResponse |
| resumeWorkflowInstance | Resumes a paused workflow | Integer workflowInstanceId | WorkflowInstanceResponse |
| updateWorkflowInstance | Updates a workflow instance | Integer workflowInstanceId, WorkflowInstanceRequest request | WorkflowInstanceResponse |
| getWorkflowInstancesByCreator | Gets workflows by creator | String creatorId | List\<WorkflowInstanceResponse\> |
| getWorkflowInstancesByDateRange | Gets workflows in date range | Date startDate, Date endDate | List\<WorkflowInstanceResponse\> |
| getWorkflowInstanceMetrics | Gets workflow metrics | Integer workflowInstanceId | Map\<String, Object\> |
| migrateWorkflowInstance | Migrates workflow to new version | Integer workflowInstanceId, Integer targetVersionId | WorkflowInstanceResponse |

### Technical Notes

- Workflow instances follow a lifecycle: CREATED → RUNNING → COMPLETED/FAILED/CANCELLED
- Workflows can be paused and resumed for maintenance or updates
- Migration allows updating a workflow to a newer definition while preserving state
- Metrics provide performance data for workflow execution

## TaskManagementAPI

The TaskManagementAPI provides methods for managing task instances within workflows.

### Key Methods

| Method | Description | Parameters | Return Type |
|--------|-------------|------------|-------------|
| createTaskInstance | Creates a new task instance | TaskInstanceRequest | TaskInstanceResponse |
| getTaskInstance | Retrieves a task instance | Integer taskInstanceId | TaskInstanceResponse |
| getTaskInstancesByWorkflowInstance | Gets tasks for a workflow | Integer workflowInstanceId | List\<TaskInstanceResponse\> |
| getTaskInstancesByStatus | Gets tasks by status | String status | List\<TaskInstanceResponse\> |
| getTaskInstancesByAssignment | Gets tasks by assignment | String assignment | List\<TaskInstanceResponse\> |
| completeTask | Completes a task with output | Integer taskInstanceId, Map\<String, Object\> outputMap | TaskInstanceResponse |
| cancelTask | Cancels a task | Integer taskInstanceId | TaskInstanceResponse |
| reassignTask | Reassigns a task | Integer taskInstanceId, String newAssignment | TaskInstanceResponse |
| skipTask | Skips a task | Integer taskInstanceId | TaskInstanceResponse |
| retryTask | Retries a failed task | Integer taskInstanceId | TaskInstanceResponse |
| retryTaskWithNewInput | Retries with new input | Integer taskInstanceId, Map\<String, Object\> inputMap | TaskInstanceResponse |
| getTasksByDueDate | Gets tasks by due date | Date dueDate | List\<TaskInstanceResponse\> |
| getOverdueTasks | Gets all overdue tasks | None | List\<TaskInstanceResponse\> |
| updateTaskProperties | Updates task properties | Integer taskInstanceId, Map\<String, Object\> properties | TaskInstanceResponse |

### Technical Notes

- Tasks can be human tasks (requiring user action) or system tasks (automated)
- Task status transitions: PENDING → IN_PROGRESS → COMPLETED/FAILED/CANCELLED/SKIPPED
- Task output becomes available to downstream tasks in the workflow
- Retry policies can be configured for automatic retry of failed tasks

## WorkflowHistoryAPI

The WorkflowHistoryAPI provides methods for retrieving historical information about workflows and tasks.

### Key Methods

| Method | Description | Parameters | Return Type |
|--------|-------------|------------|-------------|
| getWorkflowHistory | Gets workflow history | Integer workflowInstanceId | List\<WorkflowHistoryResponse\> |
| getTaskHistory | Gets task history | Integer taskInstanceId | List\<WorkflowHistoryResponse\> |
| getWorkflowHistoryByDateRange | Gets history in date range | Date startDate, Date endDate | List\<WorkflowHistoryResponse\> |
| getWorkflowHistoryByUser | Gets history by user | String userId | List\<WorkflowHistoryResponse\> |
| getWorkflowHistoryByStatus | Gets history by status | String status | List\<WorkflowHistoryResponse\> |
| exportWorkflowHistory | Exports history data | Integer workflowInstanceId, String format | byte[] |
| getWorkflowAuditEvents | Gets workflow audit events | Integer workflowInstanceId | List\<WorkflowHistoryResponse\> |
| getWorkflowHistoryWithMetrics | Gets history with metrics | Integer workflowInstanceId | List\<WorkflowHistoryResponse\> |

### Technical Notes

- History records are immutable and provide an audit trail of all workflow actions
- Export formats include CSV, JSON, and XML for integration with reporting tools
- Audit events capture user actions, system events, and state transitions
- History data is useful for compliance, debugging, and performance analysis

## WorkflowAdminAPI

The WorkflowAdminAPI provides methods for system-wide administration of workflows and tasks.

### Key Methods

| Method | Description | Parameters | Return Type |
|--------|-------------|------------|-------------|
| pauseAllWorkflows | Pauses all running workflows | String reason | int |
| resumeAllWorkflows | Resumes all paused workflows | None | int |
| retryAllFailedTasks | Retries all failed tasks | None | int |
| retryAllFailedWorkflows | Retries all failed workflows | None | int |
| archiveCompletedWorkflows | Archives old workflows | Date olderThan | int |
| purgeArchivedWorkflows | Purges archived workflows | Date olderThan | int |
| getSystemConfiguration | Gets system configuration | None | Map\<String, Object\> |
| updateSystemConfiguration | Updates system config | Map\<String, Object\> configuration | Map\<String, Object\> |
| getSystemHealthStatus | Gets system health status | None | Map\<String, Object\> |
| getWorkflowExecutionStatistics | Gets execution statistics | Date startDate, Date endDate | Map\<String, Object\> |

| runSystemDiagnostics | Runs system diagnostics | None | Map\<String, Object\> |
| migrateAllWorkflowInstances | Migrates all workflows | Integer sourceVersionId, Integer targetVersionId | List\<WorkflowInstanceResponse\> |

### Technical Notes

- Administrative operations affect multiple workflows and should be used with caution
- Archiving moves completed workflows to secondary storage for better performance
- System configuration controls thread pools, timeouts, and other runtime parameters
- Health status provides information about system components and resource usage

## WorkflowMonitoringAPI

The WorkflowMonitoringAPI provides methods for monitoring workflow performance, metrics, and SLA compliance.

### Key Methods

| Method | Description | Parameters | Return Type |
|--------|-------------|------------|-------------|
| getWorkflowMetrics | Gets workflow metrics | Integer workflowInstanceId | MetricsResponse |
| getTaskMetrics | Gets task metrics | Integer taskInstanceId | MetricsResponse |
| getSystemMetrics | Gets system-wide metrics | None | MetricsResponse |
| getWorkflowSlaStatus | Gets workflow SLA status | Integer workflowInstanceId | SlaStatusResponse |
| getTaskSlaStatus | Gets task SLA status | Integer taskInstanceId | SlaStatusResponse |
| getSlaViolationsByDateRange | Gets SLA violations | Date startDate, Date endDate | List\<SlaStatusResponse\> |
| getAuditEventsByWorkflowInstance | Gets workflow audit events | Integer workflowInstanceId | List\<AuditEvent\> |
| getAuditEventsByTaskInstance | Gets task audit events | Integer taskInstanceId | List\<AuditEvent\> |
| getAuditEventsByDateRange | Gets audit events by date | Date startDate, Date endDate | List\<AuditEvent\> |
| getAuditEventsByUser | Gets audit events by user | String userId | List\<AuditEvent\> |
| getAuditEventsByType | Gets audit events by type | String eventType | List\<AuditEvent\> |
| defineSla | Defines a new SLA | String name, long thresholdMs, String description | Map\<String, Object\> |
| getWorkflowSlaReport | Gets SLA compliance report | Integer workflowInstanceId | Map\<String, Object\> |
| getPerformanceDashboardData | Gets dashboard data | None | Map\<String, Object\> |

### Technical Notes

- Metrics provide real-time performance data for workflows and tasks
- SLA (Service Level Agreement) monitoring helps ensure timely workflow completion
- Audit events provide a detailed record of all system activities
- Dashboard data aggregates metrics for high-level system monitoring

## Common DTOs

APFlow uses the following key Data Transfer Objects (DTOs) for API requests and responses:

### Request Objects

- **WorkflowInstanceRequest** - Contains data for creating or updating workflow instances
- **TaskInstanceRequest** - Contains data for creating or updating task instances

### Response Objects

- **WorkflowInstanceResponse** - Contains workflow instance details
- **TaskInstanceResponse** - Contains task instance details
- **WorkflowHistoryResponse** - Contains workflow history records
- **MetricsResponse** - Contains performance metrics
- **SlaStatusResponse** - Contains SLA compliance information

## Error Handling

APFlow APIs use the following exception types:

- **WorkflowException** - Base exception for workflow-related errors
- **TaskException** - For task-specific errors
- **IllegalArgumentException** - For invalid input parameters
- **IllegalStateException** - For operations that cannot be performed in the current state
- **SecurityException** - For unauthorized access attempts

Error handling best practices:

1. Always catch and handle WorkflowException and TaskException
2. Check workflow and task state before performing operations
3. Implement retry logic for transient failures
4. Log detailed error information for troubleshooting

## Integration Patterns

Common integration patterns with APFlow:

1. **Embedded Integration** - Include APFlow as a library dependency
2. **Service Integration** - Interact with APFlow through service interfaces
3. **Event-Driven Integration** - Subscribe to workflow events for asynchronous processing
4. **Batch Processing** - Use bulk operations for high-volume workflow creation

## Performance Considerations

For optimal performance:

1. Use batch operations when processing multiple workflows or tasks
2. Implement appropriate caching strategies for frequently accessed data
3. Archive completed workflows regularly to maintain database performance
4. Monitor system metrics to identify and address bottlenecks
5. Configure appropriate thread pool sizes based on workload characteristics
