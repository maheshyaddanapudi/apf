package com.workday.apflow.dto.workflow;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DTO for workflow instance.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class WorkflowInstanceDTO {
    
    private String id;
    private String name;
    private String description;
    private String status;
    private Integer currentPosition = 0;
    private Map<String, Object> metadata = new HashMap<>();
    private Map<String, Object> inputData = new HashMap<>();
    private Map<String, Object> outputData = new HashMap<>();
    private List<SequenceItemDTO> sequence = new ArrayList<>();
    private Map<String, TaskGroupDTO> taskGroups = new HashMap<>();
    private Map<String, TaskDTO> standaloneTasks = new HashMap<>();
    
    /**
     * Default constructor
     */
    public WorkflowInstanceDTO() {
    }
    
    /**
     * Constructor with id and name
     * @param id The workflow instance ID
     * @param name The workflow instance name
     */
    public WorkflowInstanceDTO(String id, String name) {
        this.id = id;
        this.name = name;
    }
    
    // Getters and setters
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public Integer getCurrentPosition() {
        return currentPosition;
    }
    
    public void setCurrentPosition(Integer currentPosition) {
        this.currentPosition = currentPosition;
    }
    
    public Map<String, Object> getMetadata() {
        return metadata;
    }
    
    public void setMetadata(Map<String, Object> metadata) {
        this.metadata = metadata;
    }
    
    public Map<String, Object> getInputData() {
        return inputData;
    }
    
    public void setInputData(Map<String, Object> inputData) {
        this.inputData = inputData;
    }
    
    public Map<String, Object> getOutputData() {
        return outputData;
    }
    
    public void setOutputData(Map<String, Object> outputData) {
        this.outputData = outputData;
    }
    
    public List<SequenceItemDTO> getSequence() {
        return sequence;
    }
    
    public void setSequence(List<SequenceItemDTO> sequence) {
        this.sequence = sequence;
    }
    
    public Map<String, TaskGroupDTO> getTaskGroups() {
        return taskGroups;
    }
    
    public void setTaskGroups(Map<String, TaskGroupDTO> taskGroups) {
        this.taskGroups = taskGroups;
    }
    
    public Map<String, TaskDTO> getStandaloneTasks() {
        return standaloneTasks;
    }
    
    public void setStandaloneTasks(Map<String, TaskDTO> standaloneTasks) {
        this.standaloneTasks = standaloneTasks;
    }
}
