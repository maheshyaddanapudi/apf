package com.workday.apflow.dto.response;

/**
 * Response class for SLA (Service Level Agreement) status data.
 * Contains information about workflow SLA compliance and timing.
 */
public class SlaStatusResponse {
    
    private Integer workflowInstanceId;
    private String status;
    private Long targetCompletionTime;
    private Long estimatedCompletionTime;
    private Long elapsedTime;
    
    /**
     * Default constructor
     */
    public SlaStatusResponse() {
    }
    
    /**
     * Constructor with workflow instance ID
     * @param workflowInstanceId The workflow instance ID
     */
    public SlaStatusResponse(Integer workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
    }
    
    /**
     * Get workflow instance ID
     * @return The workflow instance ID
     */
    public Integer getWorkflowInstanceId() {
        return workflowInstanceId;
    }
    
    /**
     * Set workflow instance ID
     * @param workflowInstanceId The workflow instance ID
     */
    public void setWorkflowInstanceId(Integer workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
    }
    
    /**
     * Get status
     * @return SLA status (e.g., "ON_TRACK", "AT_RISK", "BREACHED")
     */
    public String getStatus() {
        return status;
    }
    
    /**
     * Set status
     * @param status SLA status
     */
    public void setStatus(String status) {
        this.status = status;
    }
    
    /**
     * Get target completion time
     * @return Target completion time in milliseconds since epoch
     */
    public Long getTargetCompletionTime() {
        return targetCompletionTime;
    }
    
    /**
     * Set target completion time
     * @param targetCompletionTime Target completion time in milliseconds since epoch
     */
    public void setTargetCompletionTime(Long targetCompletionTime) {
        this.targetCompletionTime = targetCompletionTime;
    }
    
    /**
     * Get estimated completion time
     * @return Estimated completion time in milliseconds since epoch
     */
    public Long getEstimatedCompletionTime() {
        return estimatedCompletionTime;
    }
    
    /**
     * Set estimated completion time
     * @param estimatedCompletionTime Estimated completion time in milliseconds since epoch
     */
    public void setEstimatedCompletionTime(Long estimatedCompletionTime) {
        this.estimatedCompletionTime = estimatedCompletionTime;
    }
    
    /**
     * Get elapsed time
     * @return Elapsed time in milliseconds
     */
    public Long getElapsedTime() {
        return elapsedTime;
    }
    
    /**
     * Set elapsed time
     * @param elapsedTime Elapsed time in milliseconds
     */
    public void setElapsedTime(Long elapsedTime) {
        this.elapsedTime = elapsedTime;
    }
}
