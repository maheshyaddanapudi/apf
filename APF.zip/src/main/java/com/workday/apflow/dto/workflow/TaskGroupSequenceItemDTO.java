package com.workday.apflow.dto.workflow;

import com.fasterxml.jackson.annotation.JsonTypeName;
import com.workday.apflow.constants.WorkflowConstants;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * DTO for task group items in the workflow sequence.
 */
@JsonTypeName(WorkflowConstants.TYPE_TASK_GROUP)
public class TaskGroupSequenceItemDTO extends SequenceItemDTO {
    
    private String taskGroupType;
    private Integer taskGroupInstanceId;
    private Map<String, Object> inputJson;
    
    /**
     * Default constructor
     */
    public TaskGroupSequenceItemDTO() {
        setType(WorkflowConstants.TYPE_TASK_GROUP);
    }
    
    /**
     * Get the task group type
     * @return The task group type
     */
    public String getTaskGroupType() {
        return taskGroupType;
    }
    
    /**
     * Set the task group type
     * @param taskGroupType The task group type to set
     */
    public void setTaskGroupType(String taskGroupType) {
        this.taskGroupType = taskGroupType;
    }
    
    /**
     * Get the task group instance ID
     * @return The task group instance ID
     */
    public Integer getTaskGroupInstanceId() {
        return taskGroupInstanceId;
    }
    
    /**
     * Set the task group instance ID
     * @param taskGroupInstanceId The task group instance ID to set
     */
    public void setTaskGroupInstanceId(Integer taskGroupInstanceId) {
        this.taskGroupInstanceId = taskGroupInstanceId;
    }
    
    /**
     * Get the input JSON
     * @return The input JSON as a Map
     */
    public Map<String, Object> getInputJson() {
        return inputJson;
    }
    
    /**
     * Set the input JSON
     * @param inputJson The input JSON as a Map
     */
    public void setInputJson(Map<String, Object> inputJson) {
        this.inputJson = inputJson;
    }
    
    /**
     * Add an input parameter
     * @param key The parameter key
     * @param value The parameter value
     */
    public void addInputParameter(String key, Object value) {
        if (inputJson == null) {
            inputJson = new HashMap<>();
        }
        inputJson.put(key, value);
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        TaskGroupSequenceItemDTO that = (TaskGroupSequenceItemDTO) o;
        return Objects.equals(taskGroupType, that.taskGroupType) &&
               Objects.equals(taskGroupInstanceId, that.taskGroupInstanceId) &&
               Objects.equals(inputJson, that.inputJson);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), taskGroupType, taskGroupInstanceId, inputJson);
    }
    
    @Override
    public String toString() {
        return "TaskGroupSequenceItemDTO{" +
               "id='" + getId() + '\'' +
               ", name='" + getName() + '\'' +
               ", type='" + getType() + '\'' +
               ", taskGroupType='" + taskGroupType + '\'' +
               ", taskGroupInstanceId=" + taskGroupInstanceId +
               ", inputJson=" + inputJson +
               '}';
    }
}
