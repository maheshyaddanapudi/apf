package com.workday.apflow.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Date;

/**
 * Response DTO for workflow history record.
 */
public class WorkflowHistoryRecordResponse {
    @JsonProperty("id")
    private Integer id;
    
    @JsonProperty("workflow_instance_id")
    private Integer workflowInstanceId;
    
    @JsonProperty("task_instance_id")
    private Integer taskInstanceId;
    
    @JsonProperty("event_type")
    private String eventType;
    
    @JsonProperty("event_details")
    private String eventDetails;
    
    @JsonProperty("timestamp")
    private Date timestamp;
    
    @JsonProperty("user_id")
    private String userId;
    
    // Constructors
    public WorkflowHistoryRecordResponse() {
    }
    
    // Getters and setters
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getWorkflowInstanceId() {
        return workflowInstanceId;
    }
    
    public void setWorkflowInstanceId(Integer workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
    }
    
    public Integer getTaskInstanceId() {
        return taskInstanceId;
    }
    
    public void setTaskInstanceId(Integer taskInstanceId) {
        this.taskInstanceId = taskInstanceId;
    }
    
    public String getEventType() {
        return eventType;
    }
    
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }
    
    public String getEventDetails() {
        return eventDetails;
    }
    
    public void setEventDetails(String eventDetails) {
        this.eventDetails = eventDetails;
    }
    
    public Date getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }
    
    public String getUserId() {
        return userId;
    }
    
    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    // Builder pattern
    public static class Builder {
        private WorkflowHistoryRecordResponse response;
        
        public Builder() {
            response = new WorkflowHistoryRecordResponse();
        }
        
        public Builder withId(Integer id) {
            response.setId(id);
            return this;
        }
        
        public Builder withWorkflowInstanceId(Integer workflowInstanceId) {
            response.setWorkflowInstanceId(workflowInstanceId);
            return this;
        }
        
        public Builder withTaskInstanceId(Integer taskInstanceId) {
            response.setTaskInstanceId(taskInstanceId);
            return this;
        }
        
        public Builder withEventType(String eventType) {
            response.setEventType(eventType);
            return this;
        }
        
        public Builder withEventDetails(String eventDetails) {
            response.setEventDetails(eventDetails);
            return this;
        }
        
        public Builder withTimestamp(Date timestamp) {
            response.setTimestamp(timestamp);
            return this;
        }
        
        public Builder withUserId(String userId) {
            response.setUserId(userId);
            return this;
        }
        
        public WorkflowHistoryRecordResponse build() {
            return response;
        }
    }
}
