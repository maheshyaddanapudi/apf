package com.workday.apflow.dto.workflow;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.workday.apflow.constants.WorkflowConstants;

import java.util.Objects;

/**
 * Base class for sequence items in a workflow.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonTypeInfo(
    use = JsonTypeInfo.Id.NAME,
    property = WorkflowConstants.FIELD_TYPE
)
@JsonSubTypes({
    @JsonSubTypes.Type(value = TaskSequenceItemDTO.class, name = WorkflowConstants.TYPE_TASK),
    @JsonSubTypes.Type(value = TaskGroupSequenceItemDTO.class, name = WorkflowConstants.TYPE_TASK_GROUP)
})
public abstract class SequenceItemDTO {
    
    private String id;
    private String name;
    private String type;
    
    /**
     * Default constructor
     */
    public SequenceItemDTO() {
    }
    
    /**
     * Constructor with id and name
     * @param id The sequence item ID
     * @param name The sequence item name
     */
    public SequenceItemDTO(String id, String name) {
        this.id = id;
        this.name = name;
    }
    
    // Getters and setters
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SequenceItemDTO that = (SequenceItemDTO) o;
        return Objects.equals(id, that.id) &&
               Objects.equals(name, that.name) &&
               Objects.equals(type, that.type);
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(id, name, type);
    }
}
