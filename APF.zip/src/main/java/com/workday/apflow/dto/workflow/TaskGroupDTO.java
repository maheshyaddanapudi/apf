package com.workday.apflow.dto.workflow;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Map;

/**
 * DTO for task group.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class TaskGroupDTO {
    
    private String id;
    private String type;
    private String name;
    private Map<String, Object> properties;
    private Map<String, Object> input;
    private Map<String, Object> output;
    private boolean initialized;
    
    /**
     * Default constructor
     */
    public TaskGroupDTO() {
    }
    
    /**
     * Constructor with id, type, and name
     * @param id The task group ID
     * @param type The task group type
     * @param name The task group name
     */
    public TaskGroupDTO(String id, String type, String name) {
        this.id = id;
        this.type = type;
        this.name = name;
    }
    
    // Getters and setters
    
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public Map<String, Object> getProperties() {
        return properties;
    }
    
    public void setProperties(Map<String, Object> properties) {
        this.properties = properties;
    }
    
    public Map<String, Object> getInput() {
        return input;
    }
    
    public void setInput(Map<String, Object> input) {
        this.input = input;
    }
    
    public Map<String, Object> getOutput() {
        return output;
    }
    
    public void setOutput(Map<String, Object> output) {
        this.output = output;
    }
    
    /**
     * Check if the task group is initialized
     * @return True if initialized, false otherwise
     */
    public boolean isInitialized() {
        return initialized;
    }
    
    /**
     * Set the initialized state of the task group
     * @param initialized The initialized state
     */
    public void setInitialized(boolean initialized) {
        this.initialized = initialized;
    }
}
