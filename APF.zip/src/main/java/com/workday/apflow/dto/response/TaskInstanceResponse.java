package com.workday.apflow.dto.response;

import com.workday.apflow.model.TaskInstance;

import java.util.Date;
import java.util.Map;

/**
 * Response DTO for task instance.
 */
public class TaskInstanceResponse {
    
    private Integer id;
    private Integer workflowInstanceId;
    private Integer taskGroupInstanceId;
    private String name;
    private String type;
    private String status;
    private String assignment;
    private Map<String, Object> input;
    private Map<String, Object> output;
    private Map<String, Object> properties;
    private Date createdAt;
    private Date startedAt;
    private Date completedAt;
    private Integer retryCount;
    private Date dueDate;
    private String description;
    private Integer priority;
    private String createdBy;
    
    /**
     * Default constructor
     */
    public TaskInstanceResponse() {
    }
    
    /**
     * Constructor from TaskInstance
     * @param instance The task instance
     */
    public TaskInstanceResponse(TaskInstance instance) {
        this.id = instance.getId();
        this.workflowInstanceId = instance.getWorkflowInstanceId();
        this.taskGroupInstanceId = instance.getTaskGroupInstanceId();
        this.name = instance.getName();
        this.type = instance.getType();
        this.status = instance.getStatus();
        this.assignment = instance.getAssignment();
        this.input = instance.getInputMap();
        this.output = instance.getOutputMap();
        this.properties = instance.getPropertiesMap();
        this.createdAt = instance.getCreatedAt();
        this.startedAt = instance.getStartedAt();
        this.completedAt = instance.getCompletedAt();
        this.retryCount = instance.getRetryCount();
        this.dueDate = instance.getDueDate();
        this.description = instance.getDescription();
        this.priority = instance.getPriority();
        this.createdBy = instance.getCreatedBy();
    }
    
    // Getters and setters
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getWorkflowInstanceId() {
        return workflowInstanceId;
    }
    
    public void setWorkflowInstanceId(Integer workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
    }
    
    public Integer getTaskGroupInstanceId() {
        return taskGroupInstanceId;
    }
    
    public void setTaskGroupInstanceId(Integer taskGroupInstanceId) {
        this.taskGroupInstanceId = taskGroupInstanceId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getAssignment() {
        return assignment;
    }
    
    public void setAssignment(String assignment) {
        this.assignment = assignment;
    }
    
    public Map<String, Object> getInput() {
        return input;
    }
    
    public void setInput(Map<String, Object> input) {
        this.input = input;
    }
    
    public Map<String, Object> getOutput() {
        return output;
    }
    
    public void setOutput(Map<String, Object> output) {
        this.output = output;
    }
    
    public Map<String, Object> getProperties() {
        return properties;
    }
    
    public void setProperties(Map<String, Object> properties) {
        this.properties = properties;
    }
    
    public Date getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }
    
    public Date getStartedAt() {
        return startedAt;
    }
    
    public void setStartedAt(Date startedAt) {
        this.startedAt = startedAt;
    }
    
    public Date getCompletedAt() {
        return completedAt;
    }
    
    public void setCompletedAt(Date completedAt) {
        this.completedAt = completedAt;
    }
    
    public Integer getRetryCount() {
        return retryCount;
    }
    
    public void setRetryCount(Integer retryCount) {
        this.retryCount = retryCount;
    }
    
    public Date getDueDate() {
        return dueDate;
    }
    
    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public Integer getPriority() {
        return priority;
    }
    
    public void setPriority(Integer priority) {
        this.priority = priority;
    }
    
    public String getCreatedBy() {
        return createdBy;
    }
    
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
}
