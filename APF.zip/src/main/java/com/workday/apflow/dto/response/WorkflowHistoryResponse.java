package com.workday.apflow.dto.response;

import com.workday.apflow.model.WorkflowHistory;
import java.sql.Timestamp;

/**
 * Response DTO for workflow history.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class WorkflowHistoryResponse {
    
    private Integer id;
    private Integer workflowInstanceId;
    private Integer taskInstanceId;
    private String eventType;
    private String eventDetails;
    private Timestamp createdAt;
    private String createdBy;
    private String status;
    private String user;
    private String details;
    
    /**
     * Default constructor
     */
    public WorkflowHistoryResponse() {
    }
    
    /**
     * Constructor from WorkflowHistory model
     * @param history The workflow history model
     */
    public WorkflowHistoryResponse(WorkflowHistory history) {
        this.id = history.getId();
        this.workflowInstanceId = history.getWorkflowInstanceId();
        this.taskInstanceId = history.getTaskInstanceId();
        this.eventType = history.getEventType();
        this.eventDetails = history.getEventDetails();
        this.createdAt = history.getCreatedAt();
        this.createdBy = history.getCreatedBy();
        this.status = history.getStatus();
        this.user = history.getCreatedBy();
        this.details = history.getEventDetails();
    }
    
    /**
     * Create a response from a workflow history model
     * @param history The workflow history model
     * @return The response DTO
     */
    public static WorkflowHistoryResponse fromModel(WorkflowHistory history) {
        return new WorkflowHistoryResponse(history);
    }
    
    // Getters and setters
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public Integer getWorkflowInstanceId() {
        return workflowInstanceId;
    }
    
    public void setWorkflowInstanceId(Integer workflowInstanceId) {
        this.workflowInstanceId = workflowInstanceId;
    }
    
    public Integer getTaskInstanceId() {
        return taskInstanceId;
    }
    
    public void setTaskInstanceId(Integer taskInstanceId) {
        this.taskInstanceId = taskInstanceId;
    }
    
    public String getEventType() {
        return eventType;
    }
    
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }
    
    public String getEventDetails() {
        return eventDetails;
    }
    
    public void setEventDetails(String eventDetails) {
        this.eventDetails = eventDetails;
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public String getCreatedBy() {
        return createdBy;
    }
    
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getUser() {
        return user;
    }
    
    public void setUser(String user) {
        this.user = user;
    }
    
    public String getDetails() {
        return details;
    }
    
    public void setDetails(String details) {
        this.details = details;
    }
    
    public String getTimestamp() {
        return createdAt != null ? createdAt.toString() : null;
    }
}
