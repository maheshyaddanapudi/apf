package com.workday.apflow.execution;

import com.workday.apflow.constants.QueueConstants;
import com.workday.apflow.dao.WorkflowExecutionQueueDAO;
import com.workday.apflow.model.WorkflowExecutionQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Sweeper for workflow execution queue.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class WorkflowExecutionSweeper {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowExecutionSweeper.class);
    private final WorkflowExecutionQueueDAO queueDAO;
    private final WorkflowStateManager stateManager;
    private boolean isFirstSweep = true;
    
    /**
     * Constructor
     * @param queueDAO The workflow execution queue DAO
     * @param stateManager The workflow state manager
     */
    public WorkflowExecutionSweeper(WorkflowExecutionQueueDAO queueDAO, WorkflowStateManager stateManager) {
        this.queueDAO = queueDAO;
        this.stateManager = stateManager;
    }
    
    /**
     * Process queue entries based on sweep status
     * @param batchSize The batch size
     */
    public void processQueueEntries(int batchSize) {
        try {
            if (isFirstSweep) {
                LOGGER.debug("First sweep: Processing pending, in-progress, and failed queue entries");
                processMixedStatusQueueEntries(batchSize);
                isFirstSweep = false;
            } else {
                LOGGER.debug("Subsequent sweep: Processing only failed queue entries");
                processFailedQueueEntries(batchSize);
            }
        } catch (Exception e) {
            LOGGER.error("Failed to process queue entries", e);
        }
    }
    
    /**
     * Process pending, in-progress, and failed queue entries
     * @param batchSize The batch size
     */
    private void processMixedStatusQueueEntries(int batchSize) {
        // Get pending, in-progress, and failed queue entries
        List<WorkflowExecutionQueue> entries = queueDAO.getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize
        );
        
        // Process each entry
        processEntries(entries);
    }
    
    /**
     * Process failed queue entries
     * @param batchSize The batch size
     */
    private void processFailedQueueEntries(int batchSize) {
        // Get failed queue entries
        List<WorkflowExecutionQueue> entries = queueDAO.getQueueEntriesByStatus(
            QueueConstants.STATUS_FAILED,
            batchSize
        );
        
        // Process each entry
        processEntries(entries);
    }
    
    /**
     * Process a list of queue entries
     * @param entries The queue entries to process
     */
    private void processEntries(List<WorkflowExecutionQueue> entries) {
        for (WorkflowExecutionQueue entry : entries) {
            try {
                // Process workflow instance with the queue entry
                stateManager.processWorkflowInstance(entry.getWorkflowInstanceId(), entry);
            } catch (Exception e) {
                LOGGER.error("Failed to process queue entry: {}", entry.getId(), e);
            }
        }
    }
    
    /**
     * Process pending queue entries (legacy method for backward compatibility)
     * @param batchSize The batch size
     */
    public void processPendingQueueEntries(int batchSize) {
        processQueueEntries(batchSize);
    }
}
