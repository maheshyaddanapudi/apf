package com.workday.apflow.execution;

import com.workday.apflow.model.WorkflowInstance;
import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.model.WorkflowExecutionQueue;
import com.workday.apflow.dao.WorkflowExecutionQueueDAO;
import com.workday.apflow.constants.WorkflowConstants;
import com.workday.apflow.constants.QueueConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;

/**
 * Extension of ExecutionQueuingInterceptor to handle workflow resume events.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class ExecutionQueuingInterceptor {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(ExecutionQueuingInterceptor.class);
    private final WorkflowExecutionQueueDAO queueDAO;
    
    /**
     * Constructor
     * @param queueDAO The workflow execution queue DAO
     */
    public ExecutionQueuingInterceptor(WorkflowExecutionQueueDAO queueDAO) {
        this.queueDAO = queueDAO;
    }
    
    /**
     * Intercept task completion and queue workflow for execution
     * @param task The completed task
     * @return The queue entry (new or updated)
     */
    public WorkflowExecutionQueue interceptTaskCompletion(TaskInstance task) {
        LOGGER.info("Intercepting task completion for task: {}", task.getId());
        
        // Check if a queue entry already exists with status PENDING for this workflow instance
        WorkflowExecutionQueue existingEntry = queueDAO.getQueueEntryByWorkflowInstanceIdAndStatus(
            task.getWorkflowInstanceId(), QueueConstants.STATUS_PENDING);
        
        WorkflowExecutionQueue queueEntry;
        
        if (existingEntry != null) {
            // Update existing entry
            LOGGER.info("Updating existing queue entry for workflow instance: {}", task.getWorkflowInstanceId());
            existingEntry.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
            queueEntry = queueDAO.updateQueueEntry(existingEntry);
            queueEntry.setNewlyCreated(false);
        } else {
            // Create new queue entry
            LOGGER.info("Creating new queue entry for workflow instance: {}", task.getWorkflowInstanceId());
            queueEntry = new WorkflowExecutionQueue();
            queueEntry.setWorkflowInstanceId(task.getWorkflowInstanceId());
            queueEntry.setStatus(QueueConstants.STATUS_PENDING);
            queueEntry.setType(QueueConstants.TYPE_WORKFLOW_EXECUTION);
            queueEntry.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            
            // Save queue entry
            queueEntry = queueDAO.createQueueEntry(queueEntry);
            queueEntry.setNewlyCreated(true);
        }
        
        LOGGER.info("Queued workflow instance for execution: {}", task.getWorkflowInstanceId());
        return queueEntry;
    }
    
    /**
     * Intercept workflow resume and queue workflow for execution
     * @param workflow The resumed workflow
     * @return The queue entry (new or updated)
     */
    public WorkflowExecutionQueue interceptWorkflowResume(WorkflowInstance workflow) {
        LOGGER.info("Intercepting workflow resume for workflow: {}", workflow.getId());
        
        // Check if a queue entry already exists with status PENDING for this workflow instance
        WorkflowExecutionQueue existingEntry = queueDAO.getQueueEntryByWorkflowInstanceIdAndStatus(
            workflow.getId(), QueueConstants.STATUS_PENDING);
        
        WorkflowExecutionQueue queueEntry;
        
        if (existingEntry != null) {
            // Update existing entry
            LOGGER.info("Updating existing queue entry for workflow instance: {}", workflow.getId());
            existingEntry.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
            queueEntry = queueDAO.updateQueueEntry(existingEntry);
            queueEntry.setNewlyCreated(false);
        } else {
            // Create new queue entry
            LOGGER.info("Creating new queue entry for workflow instance: {}", workflow.getId());
            queueEntry = new WorkflowExecutionQueue();
            queueEntry.setWorkflowInstanceId(workflow.getId());
            queueEntry.setStatus(QueueConstants.STATUS_PENDING);
            queueEntry.setType(QueueConstants.TYPE_WORKFLOW_RESUME);
            queueEntry.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            
            // Save queue entry
            queueEntry = queueDAO.createQueueEntry(queueEntry);
            queueEntry.setNewlyCreated(true);
        }
        
        LOGGER.info("Queued workflow instance for execution: {}", workflow.getId());
        return queueEntry;
    }
    
    /**
     * Intercept task retry and queue task for execution
     * @param task The task to retry
     * @return The queue entry (new or updated)
     */
    public WorkflowExecutionQueue interceptTaskRetry(TaskInstance task) {
        LOGGER.info("Intercepting task retry for task: {}", task.getId());
        
        // Check if a queue entry already exists with status PENDING for this workflow instance
        WorkflowExecutionQueue existingEntry = queueDAO.getQueueEntryByWorkflowInstanceIdAndStatus(
            task.getWorkflowInstanceId(), QueueConstants.STATUS_PENDING);
        
        WorkflowExecutionQueue queueEntry;
        
        if (existingEntry != null) {
            // Update existing entry
            LOGGER.info("Updating existing queue entry for workflow instance: {}", task.getWorkflowInstanceId());
            existingEntry.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
            existingEntry.setTaskInstanceId(task.getId()); // Set task ID for retry
            existingEntry.setType(QueueConstants.TYPE_TASK_RETRY);
            queueEntry = queueDAO.updateQueueEntry(existingEntry);
            queueEntry.setNewlyCreated(false);
        } else {
            // Create new queue entry
            LOGGER.info("Creating new queue entry for workflow instance: {}", task.getWorkflowInstanceId());
            queueEntry = new WorkflowExecutionQueue();
            queueEntry.setWorkflowInstanceId(task.getWorkflowInstanceId());
            queueEntry.setTaskInstanceId(task.getId());
            queueEntry.setStatus(QueueConstants.STATUS_PENDING);
            queueEntry.setType(QueueConstants.TYPE_TASK_RETRY);
            queueEntry.setCreatedAt(new Timestamp(System.currentTimeMillis()));
            
            // Save queue entry
            queueEntry = queueDAO.createQueueEntry(queueEntry);
            queueEntry.setNewlyCreated(true);
        }
        
        LOGGER.info("Queued task instance for retry: {}", task.getId());
        return queueEntry;
    }
}
