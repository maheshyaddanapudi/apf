package com.workday.apflow.error;

import com.workday.apflow.constants.ErrorHandlingConstants;

/**
 * Retry policy for failed tasks.
 * Defines the retry behavior including maximum retries, delay, and backoff strategy.
 */
public class RetryPolicy {
    private int maxRetries;
    private int retryDelaySeconds;
    private String retryStrategy;
    private float backoffMultiplier;
    private long initialDelayMillis;
    
    /**
     * Default constructor with default values
     */
    public RetryPolicy() {
        this.maxRetries = ErrorHandlingConstants.DEFAULT_MAX_RETRIES;
        this.retryDelaySeconds = ErrorHandlingConstants.DEFAULT_RETRY_DELAY_SECONDS;
        this.retryStrategy = ErrorHandlingConstants.RETRY_POLICY_FIXED;
        this.backoffMultiplier = ErrorHandlingConstants.DEFAULT_BACKOFF_MULTIPLIER;
        this.initialDelayMillis = 0;
    }
    
    /**
     * Constructor with custom values
     * @param maxRetries Maximum number of retry attempts
     * @param retryDelaySeconds Delay between retries in seconds
     * @param retryStrategy Retry strategy (NONE, FIXED, EXPONENTIAL)
     * @param backoffMultiplier Multiplier for exponential backoff
     */
    public RetryPolicy(int maxRetries, int retryDelaySeconds, String retryStrategy, float backoffMultiplier) {
        this.maxRetries = maxRetries;
        this.retryDelaySeconds = retryDelaySeconds;
        this.retryStrategy = retryStrategy;
        this.backoffMultiplier = backoffMultiplier;
        this.initialDelayMillis = 0;
    }
    
    /**
     * Get the maximum number of retries
     * @return Maximum retries
     */
    public int getMaxRetries() {
        return maxRetries;
    }
    
    /**
     * Set the maximum number of retries
     * @param maxRetries Maximum retries
     */
    public void setMaxRetries(int maxRetries) {
        this.maxRetries = maxRetries;
    }
    
    /**
     * Get the delay between retries in seconds
     * @return Retry delay in seconds
     */
    public int getRetryDelaySeconds() {
        return retryDelaySeconds;
    }
    
    /**
     * Set the delay between retries in seconds
     * @param retryDelaySeconds Retry delay in seconds
     */
    public void setRetryDelaySeconds(int retryDelaySeconds) {
        this.retryDelaySeconds = retryDelaySeconds;
    }
    
    /**
     * Get the retry strategy
     * @return Retry strategy (NONE, FIXED, EXPONENTIAL)
     */
    public String getRetryStrategy() {
        return retryStrategy;
    }
    
    /**
     * Set the retry strategy
     * @param retryStrategy Retry strategy (NONE, FIXED, EXPONENTIAL)
     */
    public void setRetryStrategy(String retryStrategy) {
        this.retryStrategy = retryStrategy;
    }
    
    /**
     * Get the backoff multiplier for exponential backoff
     * @return Backoff multiplier
     */
    public float getBackoffMultiplier() {
        return backoffMultiplier;
    }
    
    /**
     * Set the backoff multiplier for exponential backoff
     * @param backoffMultiplier Backoff multiplier
     */
    public void setBackoffMultiplier(float backoffMultiplier) {
        this.backoffMultiplier = backoffMultiplier;
    }
    
    /**
     * Set the backoff multiplier for exponential backoff
     * @param backoffMultiplier Backoff multiplier as double (will be converted to float)
     */
    public void setBackoffMultiplier(double backoffMultiplier) {
        this.backoffMultiplier = (float) backoffMultiplier;
    }
    
    /**
     * Get the initial delay in milliseconds
     * @return Initial delay in milliseconds
     */
    public long getInitialDelayMillis() {
        return initialDelayMillis;
    }
    
    /**
     * Set the initial delay in milliseconds
     * @param initialDelayMillis Initial delay in milliseconds
     */
    public void setInitialDelayMillis(long initialDelayMillis) {
        this.initialDelayMillis = initialDelayMillis;
    }
    
    /**
     * Calculate the delay for a specific retry attempt
     * @param attempt Current retry attempt (1-based)
     * @return Delay in milliseconds
     */
    public long calculateDelayMillis(int attempt) {
        if (ErrorHandlingConstants.RETRY_POLICY_NONE.equals(retryStrategy)) {
            return initialDelayMillis;
        } else if (ErrorHandlingConstants.RETRY_POLICY_FIXED.equals(retryStrategy)) {
            return initialDelayMillis + (retryDelaySeconds * 1000L);
        } else if (ErrorHandlingConstants.RETRY_POLICY_EXPONENTIAL.equals(retryStrategy)) {
            double multiplier = Math.pow(backoffMultiplier, attempt - 1);
            return initialDelayMillis + (long) (retryDelaySeconds * 1000L * multiplier);
        } else {
            // Default to fixed delay
            return initialDelayMillis + (retryDelaySeconds * 1000L);
        }
    }
}
