package com.workday.apflow.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Registry for task group handlers.
 * This class maintains a registry of task group handlers by type.
 */
public class TaskGroupHandlerRegistry {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskGroupHandlerRegistry.class);
    private final Map<String, TaskGroupHandler> handlers = new HashMap<>();
    
    /**
     * Register a task group handler
     * @param handler The task group handler to register
     */
    public void registerHandler(TaskGroupHandler handler) {
        LOGGER.info("Registering task group handler for type: {}", handler.getType());
        handlers.put(handler.getType(), handler);
    }
    
    /**
     * Get a task group handler by type
     * @param type The task group type
     * @return The task group handler, or null if not found
     */
    public TaskGroupHandler getHandler(String type) {
        return handlers.get(type);
    }
    
    /**
     * Check if a handler exists for the given type
     * @param type The task group type
     * @return True if a handler exists, false otherwise
     */
    public boolean hasHandler(String type) {
        return handlers.containsKey(type);
    }
    
    /**
     * Get all registered handlers
     * @return Map of task group type to handler
     */
    public Map<String, TaskGroupHandler> getAllHandlers() {
        return new HashMap<>(handlers);
    }
}
