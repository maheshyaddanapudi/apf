package com.workday.apflow.model;

import com.workday.apflow.dto.workflow.WorkflowInstanceDTO;
import com.workday.apflow.util.DtoConverter;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

/**
 * Model class for workflow instance.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class WorkflowInstance {
    
    private Integer id;
    private String name;
    private String status;
    private String inputJson;
    private String outputJson;
    private String instanceJson;
    private Timestamp createdAt;
    private Timestamp startedAt;
    private Timestamp completedAt;
    private String createdBy;
    private Integer version;
    private String propertiesJson;
    
    // Transient fields for DTO objects
    private transient WorkflowInstanceDTO instanceDto;
    private transient Map<String, Object> inputMap;
    private transient Map<String, Object> outputMap;
    private transient Map<String, Object> propertiesMap;
    
    /**
     * Default constructor
     */
    public WorkflowInstance() {
    }
    
    // Getters and setters
    
    public Integer getId() {
        return id;
    }
    
    public void setId(Integer id) {
        this.id = id;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public String getInputJson() {
        return inputJson;
    }
    
    public void setInputJson(String inputJson) {
        this.inputJson = inputJson;
        this.inputMap = null; // Reset cached map
    }
    
    public String getOutputJson() {
        return outputJson;
    }
    
    public void setOutputJson(String outputJson) {
        this.outputJson = outputJson;
        this.outputMap = null; // Reset cached map
    }
    
    public String getInstanceJson() {
        return instanceJson;
    }
    
    public void setInstanceJson(String instanceJson) {
        this.instanceJson = instanceJson;
        this.instanceDto = null; // Reset cached DTO
    }
    
    public Timestamp getCreatedAt() {
        return createdAt;
    }
    
    public void setCreatedAt(Timestamp createdAt) {
        this.createdAt = createdAt;
    }
    
    public Timestamp getStartedAt() {
        return startedAt;
    }
    
    public void setStartedAt(Timestamp startedAt) {
        this.startedAt = startedAt;
    }
    
    public Timestamp getCompletedAt() {
        return completedAt;
    }
    
    public void setCompletedAt(Timestamp completedAt) {
        this.completedAt = completedAt;
    }
    
    public String getCreatedBy() {
        return createdBy;
    }
    
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    
    /**
     * Get the version of the workflow instance
     * @return The version
     */
    public Integer getVersion() {
        return version;
    }
    
    /**
     * Set the version of the workflow instance
     * @param version The version to set
     */
    public void setVersion(Integer version) {
        this.version = version;
    }
    
    /**
     * Get the properties JSON
     * @return The properties JSON
     */
    public String getPropertiesJson() {
        return propertiesJson;
    }
    
    /**
     * Set the properties JSON
     * @param propertiesJson The properties JSON to set
     */
    public void setPropertiesJson(String propertiesJson) {
        this.propertiesJson = propertiesJson;
        this.propertiesMap = null; // Reset cached map
    }
    
    /**
     * Get the instance DTO.
     * This method lazily converts the instanceJson string to a DTO object.
     * 
     * @return The instance DTO
     */
    public WorkflowInstanceDTO getInstanceDto() {
        if (instanceDto == null && instanceJson != null) {
            instanceDto = DtoConverter.toWorkflowInstanceDto(instanceJson);
        }
        return instanceDto;
    }
    
    /**
     * Set the instance DTO.
     * This method also updates the instanceJson string.
     * 
     * @param instanceDto The instance DTO to set
     */
    public void setInstanceDto(WorkflowInstanceDTO instanceDto) {
        this.instanceDto = instanceDto;
        if (instanceDto != null) {
            this.instanceJson = DtoConverter.toJson(instanceDto);
        } else {
            this.instanceJson = null;
        }
    }
    
    /**
     * Get the input as a Map.
     * This method lazily converts the inputJson string to a Map.
     * 
     * @return The input Map
     */
    public Map<String, Object> getInputMap() {
        if (inputMap == null && inputJson != null) {
            inputMap = DtoConverter.toMap(inputJson);
        }
        return inputMap;
    }
    
    /**
     * Set the input Map.
     * This method also updates the inputJson string.
     * 
     * @param inputMap The input Map to set
     */
    public void setInputMap(Map<String, Object> inputMap) {
        this.inputMap = inputMap;
        if (inputMap != null) {
            this.inputJson = DtoConverter.toJson(inputMap);
        } else {
            this.inputJson = null;
        }
    }
    
    /**
     * Get the output as a Map.
     * This method lazily converts the outputJson string to a Map.
     * 
     * @return The output Map
     */
    public Map<String, Object> getOutputMap() {
        if (outputMap == null && outputJson != null) {
            outputMap = DtoConverter.toMap(outputJson);
        }
        return outputMap;
    }
    
    /**
     * Set the output Map.
     * This method also updates the outputJson string.
     * 
     * @param outputMap The output Map to set
     */
    public void setOutputMap(Map<String, Object> outputMap) {
        this.outputMap = outputMap;
        if (outputMap != null) {
            this.outputJson = DtoConverter.toJson(outputMap);
        } else {
            this.outputJson = null;
        }
    }
    
    /**
     * Get the properties as a Map.
     * This method lazily converts the propertiesJson string to a Map.
     * 
     * @return The properties Map
     */
    public Map<String, Object> getPropertiesMap() {
        if (propertiesMap == null) {
            if (propertiesJson != null) {
                propertiesMap = DtoConverter.toMap(propertiesJson);
            } else {
                propertiesMap = new HashMap<>();
            }
        }
        return propertiesMap;
    }
    
    /**
     * Set the properties Map.
     * This method also updates the propertiesJson string.
     * 
     * @param propertiesMap The properties Map to set
     */
    public void setPropertiesMap(Map<String, Object> propertiesMap) {
        this.propertiesMap = propertiesMap;
        if (propertiesMap != null) {
            this.propertiesJson = DtoConverter.toJson(propertiesMap);
        } else {
            this.propertiesJson = null;
        }
    }
}
