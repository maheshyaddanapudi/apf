package com.workday.apflow.api;

import com.workday.apflow.dto.request.TaskInstanceRequest;
import com.workday.apflow.dto.response.TaskInstanceResponse;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * API for task management operations.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public interface TaskManagementAPI {
    
    /**
     * Create a task instance
     * @param request The task instance request
     * @return The created task instance response
     */
    TaskInstanceResponse createTaskInstance(TaskInstanceRequest request);
    
    /**
     * Create multiple task instances
     * @param requests List of task instance requests
     * @return List of created task instance responses
     */
    List<TaskInstanceResponse> createTaskInstances(List<TaskInstanceRequest> requests);
    
    /**
     * Get a task instance
     * @param taskInstanceId The task instance ID
     * @return The task instance response
     */
    TaskInstanceResponse getTaskInstance(Integer taskInstanceId);
    
    /**
     * Get task instances by workflow instance ID
     * @param workflowInstanceId The workflow instance ID
     * @return List of task instance responses
     */
    List<TaskInstanceResponse> getTaskInstancesByWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Get task instances by status
     * @param status The task status
     * @return List of task instance responses
     */
    List<TaskInstanceResponse> getTaskInstancesByStatus(String status);
    
    /**
     * Get task instances by assignment
     * @param assignment The task assignment
     * @return List of task instance responses
     */
    List<TaskInstanceResponse> getTaskInstancesByAssignment(String assignment);
    
    /**
     * Complete a task instance
     * @param taskInstanceId The task instance ID
     * @param outputMap The output data as a Map
     * @return The completed task instance response
     */
    TaskInstanceResponse completeTask(Integer taskInstanceId, Map<String, Object> outputMap);
    
    /**
     * Cancel a task instance
     * @param taskInstanceId The task instance ID
     * @return The cancelled task instance response
     */
    TaskInstanceResponse cancelTask(Integer taskInstanceId);
    
    /**
     * Reassign a task to a new assignee
     * @param taskInstanceId The task instance ID
     * @param newAssignment The new assignment
     * @return The reassigned task instance response
     */
    TaskInstanceResponse reassignTask(Integer taskInstanceId, String newAssignment);
    
    /**
     * Skip a task instance
     * @param taskInstanceId The task instance ID
     * @return The skipped task instance response
     */
    TaskInstanceResponse skipTask(Integer taskInstanceId);
    
    /**
     * Retry a failed task instance
     * @param taskInstanceId The task instance ID
     * @return The retried task instance response
     */
    TaskInstanceResponse retryTask(Integer taskInstanceId);
    
    /**
     * Retry a failed task instance with new input
     * @param taskInstanceId The task instance ID
     * @param inputMap The new input data
     * @return The retried task instance response
     */
    TaskInstanceResponse retryTaskWithNewInput(Integer taskInstanceId, Map<String, Object> inputMap);
    
    /**
     * Get task instances by due date
     * @param dueDate The due date
     * @return List of task instance responses
     */
    List<TaskInstanceResponse> getTasksByDueDate(Date dueDate);
    
    /**
     * Get overdue tasks
     * @return List of overdue task instance responses
     */
    List<TaskInstanceResponse> getOverdueTasks();
    
    /**
     * Get task metrics
     * @param taskInstanceId The task instance ID
     * @return Map of task metrics
     */
    Map<String, Object> getTaskMetrics(Integer taskInstanceId);
    
    /**
     * Update task properties
     * @param taskInstanceId The task instance ID
     * @param properties The properties to update
     * @return The updated task instance response
     */
    TaskInstanceResponse updateTaskProperties(Integer taskInstanceId, Map<String, Object> properties);
}
