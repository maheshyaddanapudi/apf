package com.workday.apflow.api;

import com.workday.apflow.dto.request.TaskInstanceRequest;
import com.workday.apflow.dto.response.TaskInstanceResponse;
import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.service.TaskInstanceService;
import com.workday.apflow.service.TaskCompletionService;
import com.workday.apflow.service.TaskRetryService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Implementation of the TaskManagementAPI.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class TaskManagementAPIImpl implements TaskManagementAPI {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskManagementAPIImpl.class);
    private final TaskInstanceService taskInstanceService;
    private final TaskCompletionService taskCompletionService;
    private final TaskRetryService taskRetryService;
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    /**
     * Constructor
     * @param taskInstanceService The task instance service
     * @param taskCompletionService The task completion service
     * @param taskRetryService The task retry service
     */
    public TaskManagementAPIImpl(TaskInstanceService taskInstanceService, 
                                TaskCompletionService taskCompletionService,
                                TaskRetryService taskRetryService) {
        this.taskInstanceService = taskInstanceService;
        this.taskCompletionService = taskCompletionService;
        this.taskRetryService = taskRetryService;
    }
    
    @Override
    public TaskInstanceResponse createTaskInstance(TaskInstanceRequest request) {
        LOGGER.info("Creating task instance: {}", request.getName());
        
        try {
            // Create task instance
            TaskInstance instance = taskInstanceService.createTaskInstance(request);
            
            // Return response
            return new TaskInstanceResponse(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to create task instance", e);
            throw new RuntimeException("Failed to create task instance", e);
        }
    }
    
    @Override
    public List<TaskInstanceResponse> createTaskInstances(List<TaskInstanceRequest> requests) {
        LOGGER.info("Creating {} task instances", requests.size());
        
        try {
            // Create task instances
            List<TaskInstance> instances = taskInstanceService.createTaskInstances(requests);
            
            // Convert to responses
            return instances.stream()
                .map(TaskInstanceResponse::new)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to create task instances", e);
            throw new RuntimeException("Failed to create task instances", e);
        }
    }
    
    @Override
    public TaskInstanceResponse getTaskInstance(Integer taskInstanceId) {
        LOGGER.info("Getting task instance: {}", taskInstanceId);
        
        try {
            // Get task instance
            TaskInstance instance = taskInstanceService.getTaskInstance(taskInstanceId);
            
            if (instance == null) {
                return null; // Return null instead of throwing exception
            }
            
            // Return response
            return new TaskInstanceResponse(instance);
            
        } catch (Exception e) {
            if (e.getMessage() != null && e.getMessage().equals("Task instance not found")) {
                return null; // Return null instead of throwing exception
            }
            LOGGER.error("Failed to get task instance: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to get task instance", e);
        }
    }
    
    @Override
    public List<TaskInstanceResponse> getTaskInstancesByWorkflowInstance(Integer workflowInstanceId) {
        LOGGER.info("Getting task instances by workflow instance: {}", workflowInstanceId);
        
        try {
            // Get task instances by workflow instance
            List<TaskInstance> instances = taskInstanceService.getTaskInstancesByWorkflowInstance(workflowInstanceId);
            
            // Convert to responses
            return instances.stream()
                .map(TaskInstanceResponse::new)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get task instances by workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to get task instances by workflow instance", e);
        }
    }
    
    @Override
    public List<TaskInstanceResponse> getTaskInstancesByStatus(String status) {
        LOGGER.info("Getting task instances by status: {}", status);
        
        try {
            // Get task instances by status
            List<TaskInstance> instances = taskInstanceService.getTaskInstancesByStatus(status);
            
            // Convert to responses
            return instances.stream()
                .map(TaskInstanceResponse::new)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get task instances by status: {}", status, e);
            throw new RuntimeException("Failed to get task instances by status", e);
        }
    }
    
    @Override
    public List<TaskInstanceResponse> getTaskInstancesByAssignment(String assignment) {
        LOGGER.info("Getting task instances by assignment: {}", assignment);
        
        try {
            // Get task instances by assignment
            List<TaskInstance> instances = taskInstanceService.getTaskInstancesByAssignment(assignment);
            
            // Convert to responses
            return instances.stream()
                .map(TaskInstanceResponse::new)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get task instances by assignment: {}", assignment, e);
            throw new RuntimeException("Failed to get task instances by assignment", e);
        }
    }
    
    @Override
    public TaskInstanceResponse completeTask(Integer taskInstanceId, Map<String, Object> outputMap) {
        LOGGER.info("Completing task instance: {}", taskInstanceId);
        
        try {
            // Complete task
            TaskInstance instance = taskCompletionService.completeTask(taskInstanceId, outputMap);
            
            // Return response
            return new TaskInstanceResponse(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to complete task instance: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to complete task instance", e);
        }
    }
    
    @Override
    public TaskInstanceResponse cancelTask(Integer taskInstanceId) {
        LOGGER.info("Cancelling task instance: {}", taskInstanceId);
        
        try {
            // Cancel task using the TaskInstanceService
            TaskInstance instance = taskInstanceService.cancelTaskInstance(taskInstanceId);
            
            // Return response
            return new TaskInstanceResponse(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to cancel task instance: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to cancel task instance", e);
        }
    }
    
    @Override
    public TaskInstanceResponse reassignTask(Integer taskInstanceId, String newAssignment) {
        LOGGER.info("Reassigning task instance: {} to {}", taskInstanceId, newAssignment);
        
        try {
            // Get task instance
            TaskInstance instance = taskInstanceService.getTaskInstance(taskInstanceId);
            
            if (instance == null) {
                return null; // Return null instead of throwing exception
            }
            
            // Update assignment
            instance.setAssignment(newAssignment);
            
            // Update task instance
            TaskInstance updatedInstance = taskInstanceService.updateTaskInstance(instance);
            
            // Return response
            return new TaskInstanceResponse(updatedInstance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to reassign task instance: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to reassign task instance", e);
        }
    }
    
    @Override
    public TaskInstanceResponse skipTask(Integer taskInstanceId) {
        LOGGER.info("Skipping task instance: {}", taskInstanceId);
        
        try {
            // Get task instance
            TaskInstance instance = taskInstanceService.getTaskInstance(taskInstanceId);
            
            if (instance == null) {
                return null; // Return null instead of throwing exception
            }
            
            // Update status
            instance.setStatus("SKIPPED");
            
            // Update task instance
            TaskInstance updatedInstance = taskInstanceService.updateTaskInstance(instance);
            
            // Return response
            return new TaskInstanceResponse(updatedInstance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to skip task instance: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to skip task instance", e);
        }
    }
    
    @Override
    public TaskInstanceResponse retryTask(Integer taskInstanceId) {
        LOGGER.info("Retrying task instance: {}", taskInstanceId);
        
        try {
            // Retry task
            TaskInstance instance = taskRetryService.retryTask(taskInstanceId);
            
            // Return response
            return new TaskInstanceResponse(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to retry task instance: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to retry task instance", e);
        }
    }
    
    @Override
    public TaskInstanceResponse retryTaskWithNewInput(Integer taskInstanceId, Map<String, Object> inputMap) {
        LOGGER.info("Retrying task instance with new input: {}", taskInstanceId);
        
        try {
            // Retry task with new input
            TaskInstance instance = taskRetryService.retryTaskWithNewInput(taskInstanceId, inputMap);
            
            // Return response
            return new TaskInstanceResponse(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to retry task instance with new input: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to retry task instance with new input", e);
        }
    }
    
    @Override
    public List<TaskInstanceResponse> getTasksByDueDate(Date dueDate) {
        LOGGER.info("Getting tasks by due date: {}", dueDate);
        
        try {
            // Get tasks by due date
            List<TaskInstance> instances = taskInstanceService.getTasksByDueDate(dueDate);
            
            // Convert to responses
            return instances.stream()
                .map(TaskInstanceResponse::new)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get tasks by due date: {}", dueDate, e);
            throw new RuntimeException("Failed to get tasks by due date", e);
        }
    }
    
    @Override
    public List<TaskInstanceResponse> getOverdueTasks() {
        LOGGER.info("Getting overdue tasks");
        
        try {
            // Get overdue tasks
            List<TaskInstance> instances = taskInstanceService.getOverdueTasks();
            
            // Convert to responses
            return instances.stream()
                .map(TaskInstanceResponse::new)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get overdue tasks", e);
            throw new RuntimeException("Failed to get overdue tasks", e);
        }
    }
    
    @Override
    public Map<String, Object> getTaskMetrics(Integer taskInstanceId) {
        LOGGER.info("Getting task metrics: {}", taskInstanceId);
        
        try {
            // Get task instance
            TaskInstance instance = taskInstanceService.getTaskInstance(taskInstanceId);
            
            if (instance == null) {
                return null; // Return null instead of throwing exception
            }
            
            // Calculate metrics
            Map<String, Object> metrics = new HashMap<>();
            
            // Add basic metrics
            metrics.put("id", instance.getId());
            metrics.put("name", instance.getName());
            metrics.put("status", instance.getStatus());
            metrics.put("createdAt", instance.getCreatedAt());
            metrics.put("startedAt", instance.getStartedAt());
            metrics.put("completedAt", instance.getCompletedAt());
            
            // Calculate duration if applicable
            if (instance.getStartedAt() != null) {
                long durationMs;
                if (instance.getCompletedAt() != null) {
                    durationMs = instance.getCompletedAt().getTime() - instance.getStartedAt().getTime();
                } else {
                    durationMs = System.currentTimeMillis() - instance.getStartedAt().getTime();
                }
                metrics.put("durationMs", durationMs);
            }
            
            return metrics;
            
        } catch (Exception e) {
            LOGGER.error("Failed to get task metrics: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to get task metrics", e);
        }
    }
    
    @Override
    public TaskInstanceResponse updateTaskProperties(Integer taskInstanceId, Map<String, Object> properties) {
        LOGGER.info("Updating task properties: {}", taskInstanceId);
        
        try {
            // Get task instance
            TaskInstance instance = taskInstanceService.getTaskInstance(taskInstanceId);
            
            if (instance == null) {
                return null; // Return null instead of throwing exception
            }
            
            // Update properties
            Map<String, Object> currentProperties = instance.getPropertiesMap();
            if (currentProperties == null) {
                currentProperties = new HashMap<>();
            }
            currentProperties.putAll(properties);
            instance.setPropertiesMap(currentProperties);
            
            // Update task instance
            TaskInstance updatedInstance = taskInstanceService.updateTaskInstance(instance);
            
            // Return response
            return new TaskInstanceResponse(updatedInstance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to update task properties: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to update task properties", e);
        }
    }
}
