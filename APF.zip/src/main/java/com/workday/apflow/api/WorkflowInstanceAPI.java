package com.workday.apflow.api;

import com.workday.apflow.dto.request.WorkflowInstanceRequest;
import com.workday.apflow.dto.response.WorkflowInstanceResponse;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * API for workflow instance operations.
 * This interface provides methods for creating, retrieving, and managing workflow instances.
 */
public interface WorkflowInstanceAPI {
    
    /**
     * Create a workflow instance
     * @param request The workflow instance request
     * @return The created workflow instance response
     */
    WorkflowInstanceResponse createWorkflowInstance(WorkflowInstanceRequest request);
    
    /**
     * Start a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return The started workflow instance response
     */
    WorkflowInstanceResponse startWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Get a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return The workflow instance response
     */
    WorkflowInstanceResponse getWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Get all workflow instances
     * @return List of all workflow instance responses
     */
    List<WorkflowInstanceResponse> getAllWorkflowInstances();
    
    /**
     * Get workflow instances by status
     * @param status The workflow status
     * @return List of workflow instance responses with the specified status
     */
    List<WorkflowInstanceResponse> getWorkflowInstancesByStatus(String status);
    
    /**
     * Cancel a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return The cancelled workflow instance response
     */
    WorkflowInstanceResponse cancelWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Pause a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return The paused workflow instance response
     */
    WorkflowInstanceResponse pauseWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Resume a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return The resumed workflow instance response
     */
    WorkflowInstanceResponse resumeWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Update a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @param request The updated workflow instance request
     * @return The updated workflow instance response
     */
    WorkflowInstanceResponse updateWorkflowInstance(Integer workflowInstanceId, WorkflowInstanceRequest request);
    
    /**
     * Get workflow instances by creator
     * @param creatorId The creator ID
     * @return List of workflow instance responses created by the specified creator
     */
    List<WorkflowInstanceResponse> getWorkflowInstancesByCreator(String creatorId);
    
    /**
     * Get workflow instances by date range
     * @param startDate The start date
     * @param endDate The end date
     * @return List of workflow instance responses created within the specified date range
     */
    List<WorkflowInstanceResponse> getWorkflowInstancesByDateRange(Date startDate, Date endDate);
    
    /**
     * Get workflow instance metrics
     * @param workflowInstanceId The workflow instance ID
     * @return Map of workflow instance metrics
     */
    Map<String, Object> getWorkflowInstanceMetrics(Integer workflowInstanceId);
    
    /**
     * Migrate a workflow instance to a new version
     * @param workflowInstanceId The workflow instance ID
     * @param targetVersionId The target version ID
     * @return The migrated workflow instance response
     */
    WorkflowInstanceResponse migrateWorkflowInstance(Integer workflowInstanceId, Integer targetVersionId);
}
