package com.workday.apflow.api;

import com.workday.apflow.dto.response.WorkflowHistoryResponse;
import java.util.Date;
import java.util.List;

/**
 * API for workflow history operations.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public interface WorkflowHistoryAPI {
    
    /**
     * Get workflow history by workflow instance ID
     * @param workflowInstanceId The workflow instance ID
     * @return List of workflow history responses
     */
    List<WorkflowHistoryResponse> getWorkflowHistory(Integer workflowInstanceId);
    
    /**
     * Get workflow history by task instance ID
     * @param taskInstanceId The task instance ID
     * @return List of workflow history responses
     */
    List<WorkflowHistoryResponse> getTaskHistory(Integer taskInstanceId);
    
    /**
     * Get workflow history by date range
     * @param startDate The start date
     * @param endDate The end date
     * @return List of workflow history responses
     */
    List<WorkflowHistoryResponse> getWorkflowHistoryByDateRange(Date startDate, Date endDate);
    
    /**
     * Get workflow history by user
     * @param userId The user ID
     * @return List of workflow history responses
     */
    List<WorkflowHistoryResponse> getWorkflowHistoryByUser(String userId);
    
    /**
     * Get workflow history by status
     * @param status The workflow status
     * @return List of workflow history responses
     */
    List<WorkflowHistoryResponse> getWorkflowHistoryByStatus(String status);
    
    /**
     * Export workflow history
     * @param workflowInstanceId The workflow instance ID
     * @param format The export format (e.g., "CSV", "JSON", "XML")
     * @return The exported workflow history as a byte array
     */
    byte[] exportWorkflowHistory(Integer workflowInstanceId, String format);
    
    /**
     * Get audit events for a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return List of workflow history responses containing audit events
     */
    List<WorkflowHistoryResponse> getWorkflowAuditEvents(Integer workflowInstanceId);
    
    /**
     * Get workflow history with detailed metrics
     * @param workflowInstanceId The workflow instance ID
     * @return List of workflow history responses with detailed metrics
     */
    List<WorkflowHistoryResponse> getWorkflowHistoryWithMetrics(Integer workflowInstanceId);
}
