package com.workday.apflow.api;

import com.workday.apflow.dto.request.WorkflowInstanceRequest;
import com.workday.apflow.dto.response.WorkflowInstanceResponse;
import com.workday.apflow.model.WorkflowInstance;
import com.workday.apflow.service.WorkflowInstanceService;
import com.workday.apflow.service.WorkflowControlService;
import com.workday.apflow.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Implementation of the WorkflowInstanceAPI.
 * This class provides concrete implementations for workflow instance operations.
 */
public class WorkflowInstanceAPIImpl implements WorkflowInstanceAPI {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowInstanceAPIImpl.class);
    private final WorkflowInstanceService workflowInstanceService;
    private final WorkflowControlService workflowControlService;
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    /**
     * Constructor
     * @param workflowInstanceService The workflow instance service
     * @param workflowControlService The workflow control service
     */
    public WorkflowInstanceAPIImpl(WorkflowInstanceService workflowInstanceService, WorkflowControlService workflowControlService) {
        this.workflowInstanceService = workflowInstanceService;
        this.workflowControlService = workflowControlService;
    }
    
    @Override
    public WorkflowInstanceResponse createWorkflowInstance(WorkflowInstanceRequest request) {
        LOGGER.info("Creating workflow instance: {}", request.getName());
        
        try {
            // Create workflow instance using the request DTO directly
            WorkflowInstance instance = workflowInstanceService.createWorkflowInstance(request);
            
            // Return response
            return WorkflowInstanceResponse.fromModel(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to create workflow instance", e);
            throw new RuntimeException("Failed to create workflow instance", e);
        }
    }
    
    @Override
    public WorkflowInstanceResponse startWorkflowInstance(Integer workflowInstanceId) {
        LOGGER.info("Starting workflow instance: {}", workflowInstanceId);
        
        try {
            // Start workflow instance
            WorkflowInstance instance = workflowInstanceService.startWorkflowInstance(workflowInstanceId);
            
            // Return response
            return WorkflowInstanceResponse.fromModel(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to start workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to start workflow instance", e);
        }
    }
    
    @Override
    public WorkflowInstanceResponse getWorkflowInstance(Integer workflowInstanceId) {
        LOGGER.info("Getting workflow instance: {}", workflowInstanceId);
        
        try {
            // Get workflow instance
            WorkflowInstance instance = workflowInstanceService.getWorkflowInstance(workflowInstanceId);
            
            if (instance == null) {
                return null; // Return null instead of throwing exception
            }
            
            // Return response
            return WorkflowInstanceResponse.fromModel(instance);
            
        } catch (RuntimeException e) {
            // If the exception message contains "not found", return null
            if (e.getMessage() != null && e.getMessage().contains("not found")) {
                return null; // Return null instead of rethrowing exception
            }
            // Otherwise, wrap it with a standard error message
            LOGGER.error("Failed to get workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to get workflow instance", e);
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to get workflow instance", e);
        }
    }
    
    @Override
    public List<WorkflowInstanceResponse> getAllWorkflowInstances() {
        LOGGER.info("Getting all workflow instances");
        
        try {
            // Get all workflow instances
            List<WorkflowInstance> instances = workflowInstanceService.getAllWorkflowInstances();
            
            // Convert to responses
            return instances.stream()
                .map(WorkflowInstanceResponse::fromModel)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get all workflow instances", e);
            throw new RuntimeException("Failed to get all workflow instances", e);
        }
    }
    
    @Override
    public List<WorkflowInstanceResponse> getWorkflowInstancesByStatus(String status) {
        LOGGER.info("Getting workflow instances by status: {}", status);
        
        try {
            // Get workflow instances by status
            List<WorkflowInstance> instances = workflowInstanceService.getWorkflowInstancesByStatus(status);
            
            // Convert to responses
            return instances.stream()
                .map(WorkflowInstanceResponse::fromModel)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow instances by status: {}", status, e);
            throw new RuntimeException("Failed to get workflow instances by status", e);
        }
    }
    
    @Override
    public WorkflowInstanceResponse cancelWorkflowInstance(Integer workflowInstanceId) {
        LOGGER.info("Cancelling workflow instance: {}", workflowInstanceId);
        
        try {
            // Cancel workflow instance
            WorkflowInstance instance = workflowInstanceService.cancelWorkflowInstance(workflowInstanceId);
            
            // Return response
            return WorkflowInstanceResponse.fromModel(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to cancel workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to cancel workflow instance", e);
        }
    }
    
    @Override
    public WorkflowInstanceResponse pauseWorkflowInstance(Integer workflowInstanceId) {
        LOGGER.info("Pausing workflow instance: {}", workflowInstanceId);
        
        try {
            // Pause workflow instance
            WorkflowInstance instance = workflowControlService.pauseWorkflow(workflowInstanceId);
            
            // Return response
            return WorkflowInstanceResponse.fromModel(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to pause workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to pause workflow instance", e);
        }
    }
    
    @Override
    public WorkflowInstanceResponse resumeWorkflowInstance(Integer workflowInstanceId) {
        LOGGER.info("Resuming workflow instance: {}", workflowInstanceId);
        
        try {
            // Resume workflow instance
            WorkflowInstance instance = workflowControlService.resumeWorkflow(workflowInstanceId);
            
            // Return response
            return WorkflowInstanceResponse.fromModel(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to resume workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to resume workflow instance", e);
        }
    }
    
    @Override
    public WorkflowInstanceResponse updateWorkflowInstance(Integer workflowInstanceId, WorkflowInstanceRequest request) {
        LOGGER.info("Updating workflow instance: {}", workflowInstanceId);
        
        try {
            // Get existing workflow instance
            WorkflowInstance instance = workflowInstanceService.getWorkflowInstance(workflowInstanceId);
            
            if (instance == null) {
                return null; // Return null instead of throwing exception
            }
            
            // Update workflow instance
            instance = workflowControlService.updateWorkflow(workflowInstanceId, request);
            
            // Return response
            return WorkflowInstanceResponse.fromModel(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to update workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to update workflow instance", e);
        }
    }
    
    @Override
    public List<WorkflowInstanceResponse> getWorkflowInstancesByCreator(String creatorId) {
        LOGGER.info("Getting workflow instances by creator: {}", creatorId);
        
        try {
            // Get workflow instances by creator
            List<WorkflowInstance> instances = workflowInstanceService.getWorkflowInstancesByCreator(creatorId);
            
            // Convert to responses
            return instances.stream()
                .map(WorkflowInstanceResponse::fromModel)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow instances by creator: {}", creatorId, e);
            throw new RuntimeException("Failed to get workflow instances by creator", e);
        }
    }
    
    @Override
    public List<WorkflowInstanceResponse> getWorkflowInstancesByDateRange(Date startDate, Date endDate) {
        LOGGER.info("Getting workflow instances by date range: {} to {}", startDate, endDate);
        
        try {
            // Get workflow instances by date range
            List<WorkflowInstance> instances = workflowInstanceService.getWorkflowInstancesByDateRange(startDate, endDate);
            
            // Convert to responses
            return instances.stream()
                .map(WorkflowInstanceResponse::fromModel)
                .collect(Collectors.toList());
            
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow instances by date range", e);
            throw new RuntimeException("Failed to get workflow instances by date range", e);
        }
    }
    
    @Override
    public Map<String, Object> getWorkflowInstanceMetrics(Integer workflowInstanceId) {
        LOGGER.info("Getting workflow instance metrics: {}", workflowInstanceId);
        
        try {
            // Get workflow instance
            WorkflowInstance instance = workflowInstanceService.getWorkflowInstance(workflowInstanceId);
            
            if (instance == null) {
                return null; // Return null instead of throwing exception
            }
            
            // Calculate metrics
            Map<String, Object> metrics = new HashMap<>();
            
            // Add basic metrics
            metrics.put("id", instance.getId());
            metrics.put("name", instance.getName());
            metrics.put("status", instance.getStatus());
            metrics.put("createdAt", instance.getCreatedAt());
            metrics.put("startedAt", instance.getStartedAt());
            metrics.put("completedAt", instance.getCompletedAt());
            
            // Calculate duration if applicable
            if (instance.getStartedAt() != null) {
                long durationMs;
                if (instance.getCompletedAt() != null) {
                    durationMs = instance.getCompletedAt().getTime() - instance.getStartedAt().getTime();
                } else {
                    durationMs = System.currentTimeMillis() - instance.getStartedAt().getTime();
                }
                metrics.put("durationMs", durationMs);
            }
            
            return metrics;
            
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow instance metrics: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to get workflow instance metrics", e);
        }
    }
    
    @Override
    public WorkflowInstanceResponse migrateWorkflowInstance(Integer workflowInstanceId, Integer targetVersionId) {
        LOGGER.info("Migrating workflow instance: {} to version: {}", workflowInstanceId, targetVersionId);
        
        try {
            // Migrate workflow instance
            WorkflowInstance instance = workflowControlService.migrateWorkflow(workflowInstanceId, targetVersionId);
            
            // Return response
            return WorkflowInstanceResponse.fromModel(instance);
            
        } catch (Exception e) {
            LOGGER.error("Failed to migrate workflow instance: {}", workflowInstanceId, e);
            throw new RuntimeException("Failed to migrate workflow instance", e);
        }
    }
}
