package com.workday.apflow.monitoring;

/**
 * Enum representing the SLA status of a workflow.
 * Used to indicate whether a workflow is meeting its service level agreement targets.
 */
public enum SlaStatus {
    /**
     * Workflow is on track to meet SLA targets
     */
    ON_TRACK,
    
    /**
     * Workflow is at risk of missing SLA targets
     */
    AT_RISK,
    
    /**
     * Workflow has breached SLA targets
     */
    BREACHED,
    
    /**
     * SLA status is unknown or cannot be determined
     */
    UNKNOWN
}
