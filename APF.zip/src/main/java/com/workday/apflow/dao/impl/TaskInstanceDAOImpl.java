package com.workday.apflow.dao.impl;

import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.util.ClassProperties;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;

/**
 * PostgreSQL implementation of the TaskInstanceDAO interface.
 */
public class TaskInstanceDAOImpl implements TaskInstanceDAO {
    private static final Logger LOGGER = Logger.getLogger(TaskInstanceDAOImpl.class.getName());
    private final DataSource dataSource;

    /**
     * Constructor with DataSource injection.
     * 
     * @param dataSource The DataSource to use for database connections
     */
    public TaskInstanceDAOImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public TaskInstance createTaskInstance(TaskInstance task) {
        String sql = ClassProperties.getProperty("createTaskInstance", "TaskInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, task.getWorkflowInstanceId());
            if (task.getTaskGroupInstanceId() != null) {
                stmt.setInt(2, task.getTaskGroupInstanceId());
            } else {
                stmt.setNull(2, Types.INTEGER);
            }
            stmt.setString(3, task.getName());
            stmt.setString(4, task.getType());
            stmt.setString(5, task.getStatus());
            stmt.setString(6, task.getAssignment());
            stmt.setString(7, task.getCreatedBy());
            stmt.setTimestamp(8, task.getCreatedAt() != null ? 
                    task.getCreatedAt() : 
                    new Timestamp(System.currentTimeMillis()));
            stmt.setString(9, task.getInputJson());
            stmt.setString(10, task.getPropertiesJson());
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTaskInstance(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error creating task instance", e);
        }
        
        return null;
    }

    @Override
    public TaskInstance getTaskInstance(Integer id) {
        String sql = ClassProperties.getProperty("getTaskInstance", "TaskInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTaskInstance(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task instance with ID: " + id, e);
        }
        
        return null;
    }

    @Override
    public TaskInstance updateTaskInstance(TaskInstance task) {
        String sql = ClassProperties.getProperty("updateTaskInstance", "TaskInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, task.getStatus());
            stmt.setString(2, task.getAssignment());
            
            if (task.getStartedAt() != null) {
                stmt.setTimestamp(3, task.getStartedAt());
            } else {
                stmt.setNull(3, Types.TIMESTAMP);
            }
            
            if (task.getCompletedAt() != null) {
                stmt.setTimestamp(4, task.getCompletedAt());
            } else {
                stmt.setNull(4, Types.TIMESTAMP);
            }
            
            // Use description field instead of failureReason
            stmt.setString(5, task.getDescription());
            stmt.setInt(6, task.getRetryCount() != null ? task.getRetryCount() : 0);
            stmt.setString(7, task.getOutputJson());
            stmt.setString(8, task.getPropertiesJson());
            stmt.setInt(9, task.getId());
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTaskInstance(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error updating task instance with ID: " + task.getId(), e);
        }
        
        return null;
    }

    @Override
    public boolean deleteTaskInstance(Integer id) {
        String sql = ClassProperties.getProperty("deleteTaskInstance", "TaskInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting task instance with ID: " + id, e);
        }
        
        return false;
    }

    @Override
    public List<TaskInstance> getTaskInstancesByWorkflowId(Integer workflowInstanceId) {
        String sql = ClassProperties.getProperty("getTaskInstancesByWorkflowId", "TaskInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, workflowInstanceId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<TaskInstance> taskInstances = new ArrayList<>();
                while (rs.next()) {
                    taskInstances.add(mapResultSetToTaskInstance(rs));
                }
                return taskInstances;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task instances for workflow ID: " + workflowInstanceId, e);
        }
        
        return List.of();
    }

    @Override
    public List<TaskInstance> getTaskInstancesByWorkflowInstance(Integer workflowInstanceId) {
        return getTaskInstancesByWorkflowId(workflowInstanceId);
    }

    @Override
    public List<TaskInstance> getTaskInstancesByTaskGroupId(Integer taskGroupInstanceId) {
        String sql = ClassProperties.getProperty("getTaskInstancesByTaskGroupId", "TaskInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, taskGroupInstanceId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<TaskInstance> taskInstances = new ArrayList<>();
                while (rs.next()) {
                    taskInstances.add(mapResultSetToTaskInstance(rs));
                }
                return taskInstances;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task instances for task group ID: " + taskGroupInstanceId, e);
        }
        
        return List.of();
    }

    @Override
    public List<TaskInstance> getStandaloneTaskInstances(Integer workflowInstanceId) {
        String sql = ClassProperties.getProperty("getStandaloneTaskInstances", "TaskInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, workflowInstanceId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<TaskInstance> taskInstances = new ArrayList<>();
                while (rs.next()) {
                    taskInstances.add(mapResultSetToTaskInstance(rs));
                }
                return taskInstances;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting standalone task instances for workflow ID: " + workflowInstanceId, e);
        }
        
        return List.of();
    }

    @Override
    public List<TaskInstance> getTaskInstancesByStatus(String status) {
        String sql = ClassProperties.getProperty("getTaskInstancesByStatus", "TaskInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<TaskInstance> taskInstances = new ArrayList<>();
                while (rs.next()) {
                    taskInstances.add(mapResultSetToTaskInstance(rs));
                }
                return taskInstances;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task instances with status: " + status, e);
        }
        
        return List.of();
    }

    @Override
    public List<TaskInstance> getTaskInstancesByType(String type) {
        String sql = ClassProperties.getProperty("getTaskInstancesByType", "TaskInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, type);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<TaskInstance> taskInstances = new ArrayList<>();
                while (rs.next()) {
                    taskInstances.add(mapResultSetToTaskInstance(rs));
                }
                return taskInstances;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task instances with type: " + type, e);
        }
        
        return List.of();
    }

    @Override
    public List<TaskInstance> getTaskInstancesByAssignment(String assignment) {
        String sql = ClassProperties.getProperty("getTaskInstancesByAssignment", "TaskInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, assignment);
            
            try (ResultSet rs = stmt.executeQuery()) {
                List<TaskInstance> taskInstances = new ArrayList<>();
                while (rs.next()) {
                    taskInstances.add(mapResultSetToTaskInstance(rs));
                }
                return taskInstances;
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task instances with assignment: " + assignment, e);
        }
        
        return List.of();
    }

    @Override
    public TaskInstance getTaskInstanceByWorkflowAndTaskId(Integer workflowInstanceId, String taskId) {
        String sql = ClassProperties.getProperty("getTaskInstanceByWorkflowAndTaskId", "TaskInstanceDAOImpl");
        
        try (Connection conn = dataSource.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, workflowInstanceId);
            stmt.setString(2, taskId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTaskInstance(rs);
                }
            }
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting task instance for workflow ID: " + workflowInstanceId + " and task ID: " + taskId, e);
        }
        
        return null;
    }
    
    /**
     * Map a ResultSet row to a TaskInstance object.
     * 
     * @param rs The ResultSet containing task instance data
     * @return A populated TaskInstance object
     * @throws SQLException If an error occurs accessing the ResultSet
     */
    private TaskInstance mapResultSetToTaskInstance(ResultSet rs) throws SQLException {
        TaskInstance task = new TaskInstance();
        
        task.setId(rs.getInt("id"));
        task.setWorkflowInstanceId(rs.getInt("workflow_instance_id"));
        
        int taskGroupId = rs.getInt("task_group_instance_id");
        if (!rs.wasNull()) {
            task.setTaskGroupInstanceId(taskGroupId);
        }
        
        task.setName(rs.getString("name"));
        task.setType(rs.getString("type"));
        task.setStatus(rs.getString("status"));
        task.setAssignment(rs.getString("assignment"));
        task.setCreatedBy(rs.getString("created_by"));
        
        Timestamp createdAt = rs.getTimestamp("created_at");
        if (createdAt != null) {
            task.setCreatedAt(createdAt);
        }
        
        Timestamp startedAt = rs.getTimestamp("started_at");
        if (startedAt != null) {
            task.setStartedAt(startedAt);
        }
        
        Timestamp completedAt = rs.getTimestamp("completed_at");
        if (completedAt != null) {
            task.setCompletedAt(completedAt);
        }
        
        // Use description field instead of failureReason
        task.setDescription(rs.getString("failure_reason"));
        task.setRetryCount(rs.getInt("retry_count"));
        
        String inputJson = rs.getString("input_json");
        if (inputJson != null) {
            task.setInputJson(inputJson);
        }
        
        String outputJson = rs.getString("output_json");
        if (outputJson != null) {
            task.setOutputJson(outputJson);
        }
        
        String propertiesJson = rs.getString("properties_json");
        if (propertiesJson != null) {
            task.setPropertiesJson(propertiesJson);
        }
        
        return task;
    }
}
