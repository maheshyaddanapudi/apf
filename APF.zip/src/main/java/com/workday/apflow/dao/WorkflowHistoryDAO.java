package com.workday.apflow.dao;

import com.workday.apflow.model.WorkflowHistory;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 * DAO for workflow history operations.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public interface WorkflowHistoryDAO {
    
    /**
     * Get history by workflow instance ID
     * @param workflowInstanceId The workflow instance ID
     * @return List of workflow history entries for the workflow instance
     */
    List<WorkflowHistory> getHistoryByWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Get history for workflow (alias for getHistoryByWorkflowInstance)
     * @param workflowInstanceId The workflow instance ID
     * @return List of workflow history entries for the workflow instance
     */
    default List<WorkflowHistory> getHistoryForWorkflow(Integer workflowInstanceId) {
        return getHistoryByWorkflowInstance(workflowInstanceId);
    }
    
    /**
     * Get history by task instance ID
     * @param taskInstanceId The task instance ID
     * @return List of workflow history entries for the task instance
     */
    List<WorkflowHistory> getHistoryByTaskInstance(Integer taskInstanceId);
    
    /**
     * Get history by date range
     * @param startDate The start date
     * @param endDate The end date
     * @return List of workflow history entries within the specified date range
     */
    List<WorkflowHistory> getHistoryByDateRange(Date startDate, Date endDate);
    
    /**
     * Get history by user
     * @param userId The user ID
     * @return List of workflow history entries created by the specified user
     */
    List<WorkflowHistory> getHistoryByUser(String userId);
    
    /**
     * Get history by status
     * @param status The status
     * @return List of workflow history entries with the specified status
     */
    List<WorkflowHistory> getHistoryByStatus(String status);
    
    /**
     * Create a history record
     * @param history The workflow history record to create
     * @return The ID of the created history record
     */
    Integer createHistoryRecord(WorkflowHistory history);
    
    /**
     * Archive old history records
     * @param olderThan Records older than this date will be archived
     * @return Number of records archived
     */
    Integer archiveOldHistory(LocalDateTime olderThan);
}
