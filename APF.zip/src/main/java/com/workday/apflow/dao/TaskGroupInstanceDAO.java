package com.workday.apflow.dao;

import com.workday.apflow.model.TaskGroupInstance;

import java.util.List;

/**
 * DAO interface for task group instance operations.
 */
public interface TaskGroupInstanceDAO {
    
    /**
     * Create a new task group instance
     * @param taskGroup The task group instance to create
     * @return The created task group instance with ID populated
     */
    TaskGroupInstance createTaskGroupInstance(TaskGroupInstance taskGroup);
    
    /**
     * Get a task group instance by ID
     * @param id The task group instance ID
     * @return The task group instance, or null if not found
     */
    TaskGroupInstance getTaskGroupInstance(Integer id);
    
    /**
     * Get a task group instance by workflow instance ID and task group ID
     * @param workflowInstanceId The workflow instance ID
     * @param taskGroupId The task group ID
     * @return The task group instance, or null if not found
     */
    TaskGroupInstance getTaskGroupInstanceByWorkflowAndTaskGroupId(Integer workflowInstanceId, String taskGroupId);
    
    /**
     * Update an existing task group instance
     * @param taskGroup The task group instance to update
     * @return The updated task group instance
     */
    TaskGroupInstance updateTaskGroupInstance(TaskGroupInstance taskGroup);
    
    /**
     * Delete a task group instance
     * @param id The task group instance ID
     * @return True if deleted, false otherwise
     */
    boolean deleteTaskGroupInstance(Integer id);
    
    /**
     * Get all task group instances for a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return List of task group instances
     */
    List<TaskGroupInstance> getTaskGroupInstancesByWorkflowId(Integer workflowInstanceId);
    
    /**
     * Get all child task group instances for a parent task group
     * @param parentGroupId The parent task group ID
     * @return List of child task group instances
     */
    List<TaskGroupInstance> getChildTaskGroupInstances(Integer parentGroupId);
    
    /**
     * Get all top-level task group instances for a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return List of top-level task group instances (no parent)
     */
    List<TaskGroupInstance> getTopLevelTaskGroupInstances(Integer workflowInstanceId);
    
    /**
     * Get task group instances by status
     * @param status The status to filter by
     * @return List of task group instances with the given status
     */
    List<TaskGroupInstance> getTaskGroupInstancesByStatus(String status);
    
    /**
     * Get task group instances by type
     * @param type The type to filter by
     * @return List of task group instances with the given type
     */
    List<TaskGroupInstance> getTaskGroupInstancesByType(String type);
}
