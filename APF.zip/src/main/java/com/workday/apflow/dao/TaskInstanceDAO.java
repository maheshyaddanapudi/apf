package com.workday.apflow.dao;

import com.workday.apflow.model.TaskInstance;

import java.util.List;

/**
 * DAO interface for task instance operations.
 */
public interface TaskInstanceDAO {
    
    /**
     * Create a new task instance
     * @param task The task instance to create
     * @return The created task instance with ID populated
     */
    TaskInstance createTaskInstance(TaskInstance task);
    
    /**
     * Get a task instance by ID
     * @param id The task instance ID
     * @return The task instance, or null if not found
     */
    TaskInstance getTaskInstance(Integer id);
    
    /**
     * Update an existing task instance
     * @param task The task instance to update
     * @return The updated task instance
     */
    TaskInstance updateTaskInstance(TaskInstance task);
    
    /**
     * Delete a task instance
     * @param id The task instance ID
     * @return True if deleted, false otherwise
     */
    boolean deleteTaskInstance(Integer id);
    
    /**
     * Get all task instances for a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return List of task instances
     */
    List<TaskInstance> getTaskInstancesByWorkflowId(Integer workflowInstanceId);
    
    /**
     * Get all task instances for a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return List of task instances
     */
    List<TaskInstance> getTaskInstancesByWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Get all task instances for a task group
     * @param taskGroupInstanceId The task group instance ID
     * @return List of task instances
     */
    List<TaskInstance> getTaskInstancesByTaskGroupId(Integer taskGroupInstanceId);
    
    /**
     * Get all standalone task instances for a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return List of standalone task instances (not part of any task group)
     */
    List<TaskInstance> getStandaloneTaskInstances(Integer workflowInstanceId);
    
    /**
     * Get task instances by status
     * @param status The status to filter by
     * @return List of task instances with the given status
     */
    List<TaskInstance> getTaskInstancesByStatus(String status);
    
    /**
     * Get task instances by type
     * @param type The type to filter by
     * @return List of task instances with the given type
     */
    List<TaskInstance> getTaskInstancesByType(String type);
    
    /**
     * Get task instances by assignment
     * @param assignment The assignment to filter by
     * @return List of task instances with the given assignment
     */
    List<TaskInstance> getTaskInstancesByAssignment(String assignment);
    
    /**
     * Get a task instance by workflow instance ID and task ID
     * @param workflowInstanceId The workflow instance ID
     * @param taskId The task ID
     * @return The task instance, or null if not found
     */
    TaskInstance getTaskInstanceByWorkflowAndTaskId(Integer workflowInstanceId, String taskId);
}
