package com.workday.apflow.enums;

/**
 * Represents the possible types of tasks.
 * According to the requirements, only TODO task type should be implemented.
 */
public enum TaskType {
    /**
     * To-Do task for simple human actions
     */
    TODO
}
