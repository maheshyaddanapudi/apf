package com.workday.apflow.constants;

/**
 * Constants for monitoring and metrics functionality.
 * Contains constants for SLA status, metrics names, and monitoring thresholds.
 */
public class MonitoringConstants {
    
    // SLA Status Constants
    public static final String SLA_STATUS_ON_TRACK = "ON_TRACK";
    public static final String SLA_STATUS_AT_RISK = "AT_RISK";
    public static final String SLA_STATUS_BREACHED = "BREACHED";
    public static final String SLA_STATUS_UNKNOWN = "UNKNOWN";
    
    // Metrics Names
    public static final String METRIC_EXECUTION_TIME = "executionTime";
    public static final String METRIC_TASK_COUNT = "taskCount";
    public static final String METRIC_COMPLETED_TASK_COUNT = "completedTaskCount";
    public static final String METRIC_AVERAGE_TASK_TIME = "averageTaskTime";
    public static final String METRIC_ERROR_COUNT = "errorCount";
    public static final String METRIC_QUEUE_DEPTH = "queueDepth";
    public static final String METRIC_RESOURCE_UTILIZATION = "resourceUtilization";
    
    // Thresholds
    public static final long THRESHOLD_AT_RISK_PERCENT = 80; // 80% of SLA time used
    public static final long THRESHOLD_BREACHED_PERCENT = 100; // 100% of SLA time used
    
    // Audit Event Types
    public static final String AUDIT_WORKFLOW_CREATED = "WORKFLOW_CREATED";
    public static final String AUDIT_WORKFLOW_STARTED = "WORKFLOW_STARTED";
    public static final String AUDIT_WORKFLOW_COMPLETED = "WORKFLOW_COMPLETED";
    public static final String AUDIT_WORKFLOW_FAILED = "WORKFLOW_FAILED";
    public static final String AUDIT_WORKFLOW_PAUSED = "WORKFLOW_PAUSED";
    public static final String AUDIT_WORKFLOW_RESUMED = "WORKFLOW_RESUMED";
    public static final String AUDIT_WORKFLOW_UPDATED = "WORKFLOW_UPDATED";
    public static final String AUDIT_TASK_CREATED = "TASK_CREATED";
    public static final String AUDIT_TASK_COMPLETED = "TASK_COMPLETED";
    public static final String AUDIT_TASK_FAILED = "TASK_FAILED";
    public static final String AUDIT_TASK_REASSIGNED = "TASK_REASSIGNED";
    
    // Performance Metrics Collection Intervals (in milliseconds)
    public static final long METRICS_COLLECTION_INTERVAL = 60000; // 1 minute
    public static final long SLA_CHECK_INTERVAL = 300000; // 5 minutes
    
    private MonitoringConstants() {
        // Private constructor to prevent instantiation
    }
}
