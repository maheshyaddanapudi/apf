package com.workday.apflow.constants;

/**
 * Constants for workflow execution queue operations.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class QueueConstants {
    
    // Queue status constants
    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_PROCESSING = "PROCESSING";
    public static final String STATUS_COMPLETED = "COMPLETED";
    public static final String STATUS_FAILED = "FAILED";
    public static final String STATUS_FATAL = "FATAL"; // New status for entries that have failed multiple times
    
    // Queue type constants
    public static final String TYPE_WORKFLOW_EXECUTION = "WORKFLOW_EXECUTION";
    public static final String TYPE_TASK_EXECUTION = "TASK_EXECUTION";
    public static final String TYPE_WORKFLOW_RESUME = "WORKFLOW_RESUME";
    public static final String TYPE_TASK_RETRY = "TASK_RETRY";
    
    // Queue priority constants
    public static final int PRIORITY_HIGH = 1;
    public static final int PRIORITY_NORMAL = 5;
    public static final int PRIORITY_LOW = 10;
    
    // Default batch size
    public static final int DEFAULT_BATCH_SIZE = 10;
}
