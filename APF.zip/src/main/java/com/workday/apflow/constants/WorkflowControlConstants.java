package com.workday.apflow.constants;

/**
 * Constants for workflow control operations.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class WorkflowControlConstants {
    
    // Workflow control actions
    public static final String ACTION_PAUSE = "PAUSE";
    public static final String ACTION_RESUME = "RESUME";
    public static final String ACTION_UPDATE = "UPDATE";
    public static final String ACTION_MIGRATE = "MIGRATE";
    
    // Workflow control reasons
    public static final String REASON_USER_REQUESTED = "USER_REQUESTED";
    public static final String REASON_SYSTEM_MAINTENANCE = "SYSTEM_MAINTENANCE";
    public static final String REASON_ERROR_RECOVERY = "ERROR_RECOVERY";
    public static final String REASON_VERSION_UPDATE = "VERSION_UPDATE";
    
    // Workflow control properties
    public static final String PROP_PAUSED_AT = "pausedAt";
    public static final String PROP_PAUSED_BY = "pausedBy";
    public static final String PROP_PAUSE_REASON = "pauseReason";
    public static final String PROP_RESUMED_AT = "resumedAt";
    public static final String PROP_RESUMED_BY = "resumedBy";
    public static final String PROP_LAST_MODIFIED_AT = "lastModifiedAt";
    public static final String PROP_LAST_MODIFIED_BY = "lastModifiedBy";
    public static final String PROP_MODIFICATION_REASON = "modificationReason";
}
