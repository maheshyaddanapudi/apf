package com.workday.apflow.constants;

/**
 * Constants for task group related operations.
 */
public class TaskGroupConstants {
    
    // Task Group Types
    public static final String TYPE_HORIZONTAL = "HORIZONTAL";
    public static final String TYPE_VERTICAL = "VERTICAL";
    
    // Task Group Status
    public static final String STATUS_PENDING = "PENDING";
    public static final String STATUS_RUNNING = "RUNNING";
    public static final String STATUS_COMPLETED = "COMPLETED";
    public static final String STATUS_FAILED = "FAILED";
    public static final String STATUS_TERMINATED = "TERMINATED";
    public static final String STATUS_IN_PROGRESS = "IN_PROGRESS";
    
    // Completion Criteria
    public static final String COMPLETION_ALL = "ALL";
    public static final String COMPLETION_ANY = "ANY";
    
    // Property Keys
    public static final String PROP_BRANCH_PROPERTY = "branchProperty";
    public static final String PROP_BRANCH_VALUES = "branchValues";
    public static final String PROP_TASK_TEMPLATE = "taskTemplate";
    public static final String PROP_TASK_TYPE = "taskType";
    public static final String PROP_TASK_NAME = "taskName";
    public static final String PROP_ASSIGNMENT = "assignment";
    public static final String PROP_TASKS = "tasks";
    public static final String PROP_CHILD_GROUPS = "childGroups";
    public static final String PROP_CURRENT_INDEX = "currentIndex";
    public static final String PROP_TASK_DEFINITIONS = "taskDefinitions";
    public static final String PROP_COMPLETION_CRITERIA = "completionCriteria";
    public static final String PROP_INPUT = "input";
    public static final String PROP_MIN_COMPLETION = "minCompletion";
    
    private TaskGroupConstants() {
        // Private constructor to prevent instantiation
    }
}
