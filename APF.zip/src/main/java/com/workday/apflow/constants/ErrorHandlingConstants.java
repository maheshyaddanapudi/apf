package com.workday.apflow.constants;

/**
 * Constants for error handling operations.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class ErrorHandlingConstants {
    
    // Error codes
    public static final String ERROR_CODE_TASK_CREATION_FAILED = "TASK_CREATION_FAILED";
    public static final String ERROR_CODE_TASK_EXECUTION_FAILED = "TASK_EXECUTION_FAILED";
    public static final String ERROR_CODE_TASK_COMPLETION_FAILED = "TASK_COMPLETION_FAILED";
    public static final String ERROR_CODE_WORKFLOW_CREATION_FAILED = "WORKFLOW_CREATION_FAILED";
    public static final String ERROR_CODE_WORKFLOW_EXECUTION_FAILED = "WORKFLOW_EXECUTION_FAILED";
    public static final String ERROR_CODE_OPERATOR_INITIALIZATION_FAILED = "OPERATOR_INITIALIZATION_FAILED";
    public static final String ERROR_CODE_OPERATOR_EXECUTION_FAILED = "OPERATOR_EXECUTION_FAILED";
    
    // Error types
    public static final String ERROR_TYPE_VALIDATION = "VALIDATION";
    public static final String ERROR_TYPE_SYSTEM = "SYSTEM";
    public static final String ERROR_TYPE_BUSINESS = "BUSINESS";
    public static final String ERROR_TYPE_CONNECTIVITY = "CONNECTIVITY";
    
    // Retry settings
    public static final String RETRY_POLICY_NONE = "NONE";
    public static final String RETRY_POLICY_FIXED = "FIXED";
    public static final String RETRY_POLICY_EXPONENTIAL = "EXPONENTIAL";
    
    public static final int DEFAULT_MAX_RETRIES = 3;
    public static final int DEFAULT_RETRY_DELAY_SECONDS = 60;
    public static final float DEFAULT_BACKOFF_MULTIPLIER = 2.0f;
}
