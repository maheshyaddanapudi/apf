package com.workday.apflow.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.workday.apflow.dto.workflow.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Utility class for converting between DTOs and JSON.
 */
public class DtoConverter {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(DtoConverter.class);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    
    /**
     * Convert a JSON string to a Map
     * @param json The JSON string
     * @return The Map representation
     */
    public static Map<String, Object> toMap(String json) {
        try {
            if (json == null || json.isEmpty()) {
                return new HashMap<>();
            }
            
            return OBJECT_MAPPER.readValue(json, Map.class);
        } catch (Exception e) {
            LOGGER.error("Error converting JSON to Map", e);
            return new HashMap<>();
        }
    }
    
    /**
     * Convert a Map to a JSON string
     * @param map The Map to convert
     * @return The JSON string
     */
    public static String toJson(Map<String, Object> map) {
        try {
            if (map == null) {
                return "{}";
            }
            
            return OBJECT_MAPPER.writeValueAsString(map);
        } catch (Exception e) {
            LOGGER.error("Error converting Map to JSON", e);
            return "{}";
        }
    }
    
    /**
     * Convert a WorkflowInstanceDTO to a JSON string
     * @param dto The WorkflowInstanceDTO to convert
     * @return The JSON string
     */
    public static String toJson(WorkflowInstanceDTO dto) {
        try {
            if (dto == null) {
                return "{}";
            }
            
            // Create a clean copy to avoid modifying the original
            WorkflowInstanceDTO cleanDto = new WorkflowInstanceDTO();
            cleanDto.setId(dto.getId());
            cleanDto.setName(dto.getName());
            cleanDto.setDescription(dto.getDescription());
            cleanDto.setStatus(dto.getStatus());
            cleanDto.setCurrentPosition(dto.getCurrentPosition());
            cleanDto.setSequence(dto.getSequence());
            cleanDto.setTaskGroups(dto.getTaskGroups());
            cleanDto.setStandaloneTasks(dto.getStandaloneTasks());
            cleanDto.setMetadata(dto.getMetadata());
            cleanDto.setInputData(dto.getInputData());
            cleanDto.setOutputData(dto.getOutputData());
            
            return OBJECT_MAPPER.writeValueAsString(cleanDto);
        } catch (Exception e) {
            LOGGER.error("Error converting WorkflowInstanceDTO to JSON", e);
            return "{}";
        }
    }
    
    /**
     * Convert a JSON string to a WorkflowInstanceDTO
     * @param json The JSON string
     * @return The WorkflowInstanceDTO
     */
    public static WorkflowInstanceDTO toWorkflowInstanceDto(String json) {
        try {
            if (json == null || json.isEmpty()) {
                return new WorkflowInstanceDTO();
            }
            
            WorkflowInstanceDTO dto = OBJECT_MAPPER.readValue(json, WorkflowInstanceDTO.class);
            
            // Ensure all collections are initialized
            if (dto.getSequence() == null) {
                dto.setSequence(new ArrayList<>());
            }
            
            if (dto.getTaskGroups() == null) {
                dto.setTaskGroups(new HashMap<>());
            }
            
            if (dto.getStandaloneTasks() == null) {
                dto.setStandaloneTasks(new HashMap<>());
            }
            
            if (dto.getMetadata() == null) {
                dto.setMetadata(new HashMap<>());
            }
            
            if (dto.getInputData() == null) {
                dto.setInputData(new HashMap<>());
            }
            
            if (dto.getOutputData() == null) {
                dto.setOutputData(new HashMap<>());
            }
            
            return dto;
        } catch (Exception e) {
            LOGGER.error("Error converting JSON to WorkflowInstanceDTO", e);
            return new WorkflowInstanceDTO();
        }
    }
    
    /**
     * Convert a JsonNode to a WorkflowInstanceDTO
     * @param node The JsonNode
     * @return The WorkflowInstanceDTO
     */
    public static WorkflowInstanceDTO toWorkflowInstanceDto(JsonNode node) {
        try {
            if (node == null) {
                return new WorkflowInstanceDTO();
            }
            
            WorkflowInstanceDTO dto = OBJECT_MAPPER.convertValue(node, WorkflowInstanceDTO.class);
            
            // Ensure all collections are initialized
            if (dto.getSequence() == null) {
                dto.setSequence(new ArrayList<>());
            }
            
            if (dto.getTaskGroups() == null) {
                dto.setTaskGroups(new HashMap<>());
            }
            
            if (dto.getStandaloneTasks() == null) {
                dto.setStandaloneTasks(new HashMap<>());
            }
            
            if (dto.getMetadata() == null) {
                dto.setMetadata(new HashMap<>());
            }
            
            if (dto.getInputData() == null) {
                dto.setInputData(new HashMap<>());
            }
            
            if (dto.getOutputData() == null) {
                dto.setOutputData(new HashMap<>());
            }
            
            return dto;
        } catch (Exception e) {
            LOGGER.error("Error converting JsonNode to WorkflowInstanceDTO", e);
            return new WorkflowInstanceDTO();
        }
    }
    
    /**
     * Convert a WorkflowInstanceDTO to a JsonNode
     * @param dto The WorkflowInstanceDTO to convert
     * @return The JsonNode
     */
    public static JsonNode toJsonNode(WorkflowInstanceDTO dto) {
        try {
            if (dto == null) {
                return OBJECT_MAPPER.createObjectNode();
            }
            
            // Create a clean copy to avoid modifying the original
            WorkflowInstanceDTO cleanDto = new WorkflowInstanceDTO();
            cleanDto.setId(dto.getId());
            cleanDto.setName(dto.getName());
            cleanDto.setDescription(dto.getDescription());
            cleanDto.setStatus(dto.getStatus());
            cleanDto.setCurrentPosition(dto.getCurrentPosition());
            cleanDto.setSequence(dto.getSequence());
            cleanDto.setTaskGroups(dto.getTaskGroups());
            cleanDto.setStandaloneTasks(dto.getStandaloneTasks());
            cleanDto.setMetadata(dto.getMetadata());
            cleanDto.setInputData(dto.getInputData());
            cleanDto.setOutputData(dto.getOutputData());
            
            return OBJECT_MAPPER.valueToTree(cleanDto);
        } catch (Exception e) {
            LOGGER.error("Error converting WorkflowInstanceDTO to JsonNode", e);
            return OBJECT_MAPPER.createObjectNode();
        }
    }
    
    /**
     * Convert a TaskGroupDTO to a JsonNode
     * @param dto The TaskGroupDTO to convert
     * @return The JsonNode
     */
    public static JsonNode toJsonNode(TaskGroupDTO dto) {
        try {
            if (dto == null) {
                return OBJECT_MAPPER.createObjectNode();
            }
            
            return OBJECT_MAPPER.valueToTree(dto);
        } catch (Exception e) {
            LOGGER.error("Error converting TaskGroupDTO to JsonNode", e);
            return OBJECT_MAPPER.createObjectNode();
        }
    }
    
    /**
     * Convert an Object to a JsonNode
     * @param obj The Object to convert
     * @return The JsonNode
     */
    public static JsonNode toJsonNode(Object obj) {
        try {
            if (obj == null) {
                return OBJECT_MAPPER.createObjectNode();
            }
            
            return OBJECT_MAPPER.valueToTree(obj);
        } catch (Exception e) {
            LOGGER.error("Error converting Object to JsonNode", e);
            return OBJECT_MAPPER.createObjectNode();
        }
    }
}
