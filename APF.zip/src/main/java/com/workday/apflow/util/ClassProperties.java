package com.workday.apflow.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Utility class for loading and retrieving properties from class-specific properties files.
 * This class provides a mechanism to load SQL queries from properties files named after the class.
 */
public class ClassProperties {
    private static final Logger LOGGER = Logger.getLogger(ClassProperties.class.getName());
    private static final Map<String, Properties> PROPERTIES_CACHE = new HashMap<>();
    
    /**
     * Get a property value from a class-specific properties file.
     * 
     * @param propertyName The name of the property to retrieve
     * @param className The class name to determine the properties file
     * @return The property value, or null if not found
     */
    public static String getProperty(String propertyName, String className) {
        Properties properties = getPropertiesForClass(className);
        return properties != null ? properties.getProperty(propertyName) : null;
    }
    
    /**
     * Get a property value from a class-specific properties file.
     * 
     * @param propertyName The name of the property to retrieve
     * @param clazz The class to determine the properties file
     * @return The property value, or null if not found
     */
    public static String getProperty(String propertyName, Class<?> clazz) {
        return getProperty(propertyName, clazz.getSimpleName());
    }
    
    /**
     * Load properties for a specific class.
     * 
     * @param className The class name to determine the properties file
     * @return The Properties object, or null if the file could not be loaded
     */
    private static synchronized Properties getPropertiesForClass(String className) {
        if (PROPERTIES_CACHE.containsKey(className)) {
            return PROPERTIES_CACHE.get(className);
        }
        
        Properties properties = new Properties();
        String propertiesFileName = className + ".properties";
        
        try (InputStream inputStream = ClassProperties.class.getClassLoader().getResourceAsStream(propertiesFileName)) {
            if (inputStream != null) {
                properties.load(inputStream);
                PROPERTIES_CACHE.put(className, properties);
                return properties;
            } else {
                LOGGER.log(Level.WARNING, "Properties file not found: {0}", propertiesFileName);
                return null;
            }
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error loading properties file: " + propertiesFileName, e);
            return null;
        }
    }
    
    /**
     * Clear the properties cache.
     * Useful for testing or when properties files are updated at runtime.
     */
    public static synchronized void clearCache() {
        PROPERTIES_CACHE.clear();
    }
}
