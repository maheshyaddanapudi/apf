package com.workday.apflow.service;

import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.model.WorkflowExecutionQueue;
import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.execution.ExecutionQueuingInterceptor;
import com.workday.apflow.execution.WorkflowStateManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.Map;

/**
 * Service for task completion operations.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public class TaskCompletionService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskCompletionService.class);
    private final TaskInstanceDAO taskInstanceDAO;
    private final ExecutionQueuingInterceptor executionQueuingInterceptor;
    private final WorkflowStateManager workflowStateManager;
    
    /**
     * Constructor
     * @param taskInstanceDAO The task instance DAO
     * @param executionQueuingInterceptor The execution queuing interceptor
     * @param workflowStateManager The workflow state manager
     */
    public TaskCompletionService(TaskInstanceDAO taskInstanceDAO, 
                              ExecutionQueuingInterceptor executionQueuingInterceptor,
                              WorkflowStateManager workflowStateManager) {
        this.taskInstanceDAO = taskInstanceDAO;
        this.executionQueuingInterceptor = executionQueuingInterceptor;
        this.workflowStateManager = workflowStateManager;
    }
    
    /**
     * Complete a task
     * @param taskInstanceId The task instance ID
     * @param outputMap The output data as a Map
     * @return The completed task
     */
    public TaskInstance completeTask(Integer taskInstanceId, Map<String, Object> outputMap) {
        LOGGER.info("Completing task instance: {}", taskInstanceId);
        
        // Get task instance
        TaskInstance task = taskInstanceDAO.getTaskInstance(taskInstanceId);
        
        if (task == null) {
            throw new RuntimeException("Task instance not found: " + taskInstanceId);
        }
        
        try {
            // Update task with output and status
            task.setOutputMap(outputMap);
            task.setStatus("COMPLETED");
            task.setCompletedAt(new Timestamp(System.currentTimeMillis()));
            
            // Save task instance
            TaskInstance updatedTask = taskInstanceDAO.updateTaskInstance(task);
            
            // Queue workflow for state management
            WorkflowExecutionQueue queueEntry = executionQueuingInterceptor.interceptTaskCompletion(updatedTask);
            
            // If a new queue entry was created and we have a state manager, process it directly
            if (queueEntry != null && queueEntry.isNewlyCreated() && workflowStateManager != null) {
                LOGGER.info("Directly invoking state manager for newly created queue entry: {}", queueEntry.getId());
                workflowStateManager.processWorkflowInstance(updatedTask.getWorkflowInstanceId(), queueEntry);
            }
            
            return updatedTask;
            
        } catch (Exception e) {
            LOGGER.error("Failed to complete task: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to complete task", e);
        }
    }
    
    /**
     * Cancel a task
     * @param taskInstanceId The task instance ID
     * @return The cancelled task
     */
    public TaskInstance cancelTask(Integer taskInstanceId) {
        LOGGER.info("Cancelling task instance: {}", taskInstanceId);
        
        // Get task instance
        TaskInstance task = taskInstanceDAO.getTaskInstance(taskInstanceId);
        
        if (task == null) {
            throw new RuntimeException("Task instance not found: " + taskInstanceId);
        }
        
        try {
            // Update task status
            task.setStatus("CANCELLED");
            task.setCompletedAt(new Timestamp(System.currentTimeMillis()));
            
            // Save task instance
            TaskInstance updatedTask = taskInstanceDAO.updateTaskInstance(task);
            
            // Queue workflow for state management
            WorkflowExecutionQueue queueEntry = executionQueuingInterceptor.interceptTaskCompletion(updatedTask);
            
            // If a new queue entry was created and we have a state manager, process it directly
            if (queueEntry != null && queueEntry.isNewlyCreated() && workflowStateManager != null) {
                LOGGER.info("Directly invoking state manager for newly created queue entry: {}", queueEntry.getId());
                workflowStateManager.processWorkflowInstance(updatedTask.getWorkflowInstanceId(), queueEntry);
            }
            
            return updatedTask;
            
        } catch (Exception e) {
            LOGGER.error("Failed to cancel task: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to cancel task", e);
        }
    }
    
    /**
     * Skip a task
     * @param taskInstanceId The task instance ID
     * @return The skipped task
     */
    public TaskInstance skipTask(Integer taskInstanceId) {
        LOGGER.info("Skipping task instance: {}", taskInstanceId);
        
        // Get task instance
        TaskInstance task = taskInstanceDAO.getTaskInstance(taskInstanceId);
        
        if (task == null) {
            throw new RuntimeException("Task instance not found: " + taskInstanceId);
        }
        
        try {
            // Update task status
            task.setStatus("SKIPPED");
            task.setCompletedAt(new Timestamp(System.currentTimeMillis()));
            
            // Save task instance
            TaskInstance updatedTask = taskInstanceDAO.updateTaskInstance(task);
            
            // Queue workflow for state management
            WorkflowExecutionQueue queueEntry = executionQueuingInterceptor.interceptTaskCompletion(updatedTask);
            
            // If a new queue entry was created and we have a state manager, process it directly
            if (queueEntry != null && queueEntry.isNewlyCreated() && workflowStateManager != null) {
                LOGGER.info("Directly invoking state manager for newly created queue entry: {}", queueEntry.getId());
                workflowStateManager.processWorkflowInstance(updatedTask.getWorkflowInstanceId(), queueEntry);
            }
            
            return updatedTask;
            
        } catch (Exception e) {
            LOGGER.error("Failed to skip task: {}", taskInstanceId, e);
            throw new RuntimeException("Failed to skip task", e);
        }
    }
}
