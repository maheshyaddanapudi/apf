package com.workday.apflow.service;

import com.workday.apflow.constants.WorkflowConstants;
import com.workday.apflow.constants.WorkflowControlConstants;
import com.workday.apflow.dao.WorkflowInstanceDAO;
import com.workday.apflow.dto.request.WorkflowInstanceRequest;
import com.workday.apflow.dto.workflow.WorkflowInstanceDTO;
import com.workday.apflow.error.WorkflowException;
import com.workday.apflow.constants.ErrorHandlingConstants;
import com.workday.apflow.execution.ExecutionQueuingInterceptor;
import com.workday.apflow.model.WorkflowInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.Map;
import java.util.HashMap;

/**
 * Service for workflow control operations.
 * Provides methods for pausing, resuming, and updating workflow instances.
 */
public class WorkflowControlService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowControlService.class);
    
    private final WorkflowInstanceDAO workflowInstanceDAO;
    private final ExecutionQueuingInterceptor interceptor;
    
    /**
     * Constructor
     * @param workflowInstanceDAO The workflow instance DAO
     * @param interceptor The execution queuing interceptor
     */
    public WorkflowControlService(WorkflowInstanceDAO workflowInstanceDAO, ExecutionQueuingInterceptor interceptor) {
        this.workflowInstanceDAO = workflowInstanceDAO;
        this.interceptor = interceptor;
    }
    
    /**
     * Pause a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return The paused workflow instance
     */
    public WorkflowInstance pauseWorkflow(Integer workflowInstanceId) {
        return pauseWorkflow(workflowInstanceId, "system", "API request");
    }
    
    /**
     * Pause a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @param userId The user ID requesting the pause
     * @param reason The reason for pausing
     * @return The paused workflow instance
     */
    public WorkflowInstance pauseWorkflow(Integer workflowInstanceId, String userId, String reason) {
        LOGGER.info("Pausing workflow: {}, requested by: {}, reason: {}", workflowInstanceId, userId, reason);
        
        // Get workflow instance
        WorkflowInstance workflow = workflowInstanceDAO.getWorkflowInstance(workflowInstanceId);
        
        if (workflow == null) {
            throw new IllegalArgumentException("Workflow instance not found: " + workflowInstanceId);
        }
        
        // Check if workflow is in a state that can be paused
        if (!WorkflowConstants.STATUS_RUNNING.equals(workflow.getStatus())) {
            throw new WorkflowException(
                "Workflow is not in running state: " + workflowInstanceId,
                ErrorHandlingConstants.ERROR_CODE_WORKFLOW_EXECUTION_FAILED,
                ErrorHandlingConstants.ERROR_TYPE_VALIDATION,
                "false",
                workflowInstanceId
            );
        }
        
        // Update workflow status
        workflow.setStatus(WorkflowConstants.STATUS_PAUSED);
        
        // Update properties
        Map<String, Object> properties = workflow.getPropertiesMap();
        if (properties == null) {
            properties = new HashMap<>();
        }
        
        properties.put(WorkflowControlConstants.PROP_PAUSED_AT, new Timestamp(System.currentTimeMillis()));
        properties.put(WorkflowControlConstants.PROP_PAUSED_BY, userId);
        properties.put(WorkflowControlConstants.PROP_PAUSE_REASON, reason);
        
        workflow.setPropertiesMap(properties);
        
        // Save workflow
        workflowInstanceDAO.updateWorkflowInstance(workflow);
        
        return workflow;
    }
    
    /**
     * Resume a paused workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return The resumed workflow instance
     */
    public WorkflowInstance resumeWorkflow(Integer workflowInstanceId) {
        return resumeWorkflow(workflowInstanceId, "system");
    }
    
    /**
     * Resume a paused workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @param userId The user ID requesting the resume
     * @return The resumed workflow instance
     */
    public WorkflowInstance resumeWorkflow(Integer workflowInstanceId, String userId) {
        LOGGER.info("Resuming workflow: {}, requested by: {}", workflowInstanceId, userId);
        
        // Get workflow instance
        WorkflowInstance workflow = workflowInstanceDAO.getWorkflowInstance(workflowInstanceId);
        
        if (workflow == null) {
            throw new IllegalArgumentException("Workflow instance not found: " + workflowInstanceId);
        }
        
        // Check if workflow is in a state that can be resumed
        if (!WorkflowConstants.STATUS_PAUSED.equals(workflow.getStatus())) {
            throw new WorkflowException(
                "Workflow is not in paused state: " + workflowInstanceId,
                ErrorHandlingConstants.ERROR_CODE_WORKFLOW_EXECUTION_FAILED,
                ErrorHandlingConstants.ERROR_TYPE_VALIDATION,
                "false",
                workflowInstanceId
            );
        }
        
        // Update workflow status
        workflow.setStatus(WorkflowConstants.STATUS_RUNNING);
        
        // Update properties
        Map<String, Object> properties = workflow.getPropertiesMap();
        if (properties == null) {
            properties = new HashMap<>();
        }
        
        properties.put(WorkflowControlConstants.PROP_RESUMED_AT, new Timestamp(System.currentTimeMillis()));
        properties.put(WorkflowControlConstants.PROP_RESUMED_BY, userId);
        
        workflow.setPropertiesMap(properties);
        
        // Save workflow
        workflowInstanceDAO.updateWorkflowInstance(workflow);
        
        // Queue for execution
        interceptor.interceptWorkflowResume(workflow);
        
        return workflow;
    }
    
    /**
     * Update a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @param request The updated workflow instance request
     * @return The updated workflow instance
     */
    public WorkflowInstance updateWorkflow(Integer workflowInstanceId, WorkflowInstanceRequest request) {
        return updateWorkflow(workflowInstanceId, convertToDTO(request), "system", "API request");
    }
    
    /**
     * Update a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @param updatedInstanceDto The updated workflow instance DTO
     * @param userId The user ID making the update
     * @param reason The reason for the update
     * @return The updated workflow instance
     */
    public WorkflowInstance updateWorkflow(Integer workflowInstanceId, WorkflowInstanceDTO updatedInstanceDto, 
                                          String userId, String reason) {
        LOGGER.info("Updating workflow: {}, requested by: {}, reason: {}", workflowInstanceId, userId, reason);
        
        // Get workflow instance
        WorkflowInstance workflow = workflowInstanceDAO.getWorkflowInstance(workflowInstanceId);
        
        if (workflow == null) {
            throw new IllegalArgumentException("Workflow instance not found: " + workflowInstanceId);
        }
        
        // Check if workflow is in a state that can be updated
        if (WorkflowConstants.STATUS_COMPLETED.equals(workflow.getStatus()) ||
            WorkflowConstants.STATUS_FAILED.equals(workflow.getStatus()) ||
            WorkflowConstants.STATUS_TERMINATED.equals(workflow.getStatus())) {
            throw new WorkflowException(
                "Workflow is in terminal state: " + workflowInstanceId,
                ErrorHandlingConstants.ERROR_CODE_WORKFLOW_EXECUTION_FAILED,
                ErrorHandlingConstants.ERROR_TYPE_VALIDATION,
                "false",
                workflowInstanceId
            );
        }
        
        // Update workflow instance DTO
        workflow.setInstanceDto(updatedInstanceDto);
        
        // Update properties
        Map<String, Object> properties = workflow.getPropertiesMap();
        if (properties == null) {
            properties = new HashMap<>();
        }
        
        properties.put(WorkflowControlConstants.PROP_LAST_MODIFIED_AT, new Timestamp(System.currentTimeMillis()));
        properties.put(WorkflowControlConstants.PROP_LAST_MODIFIED_BY, userId);
        properties.put(WorkflowControlConstants.PROP_MODIFICATION_REASON, reason);
        
        workflow.setPropertiesMap(properties);
        
        // Save workflow
        workflowInstanceDAO.updateWorkflowInstance(workflow);
        
        return workflow;
    }
    
    /**
     * Migrate a workflow instance to a new version
     * @param workflowInstanceId The workflow instance ID
     * @param targetVersionId The target version ID
     * @return The migrated workflow instance
     */
    public WorkflowInstance migrateWorkflow(Integer workflowInstanceId, Integer targetVersionId) {
        return migrateWorkflow(workflowInstanceId, targetVersionId, "system");
    }
    
    /**
     * Migrate a workflow instance to a new version
     * @param workflowInstanceId The workflow instance ID
     * @param targetVersionId The target version ID
     * @param userId The user ID requesting the migration
     * @return The migrated workflow instance
     */
    public WorkflowInstance migrateWorkflow(Integer workflowInstanceId, Integer targetVersionId, String userId) {
        LOGGER.info("Migrating workflow: {} to version: {}, requested by: {}", 
                   workflowInstanceId, targetVersionId, userId);
        
        // Get workflow instance
        WorkflowInstance workflow = workflowInstanceDAO.getWorkflowInstance(workflowInstanceId);
        
        if (workflow == null) {
            throw new IllegalArgumentException("Workflow instance not found: " + workflowInstanceId);
        }
        
        // Check if workflow is in a state that can be migrated
        if (WorkflowConstants.STATUS_COMPLETED.equals(workflow.getStatus()) ||
            WorkflowConstants.STATUS_FAILED.equals(workflow.getStatus()) ||
            WorkflowConstants.STATUS_TERMINATED.equals(workflow.getStatus())) {
            throw new WorkflowException(
                "Workflow is in terminal state: " + workflowInstanceId,
                ErrorHandlingConstants.ERROR_CODE_WORKFLOW_EXECUTION_FAILED,
                ErrorHandlingConstants.ERROR_TYPE_VALIDATION,
                "false",
                workflowInstanceId
            );
        }
        
        // In a real implementation, this would fetch the new version definition and update the workflow
        // For now, just update the version ID
        workflow.setVersion(targetVersionId);
        
        // Update properties
        Map<String, Object> properties = workflow.getPropertiesMap();
        if (properties == null) {
            properties = new HashMap<>();
        }
        
        properties.put(WorkflowControlConstants.PROP_LAST_MODIFIED_AT, new Timestamp(System.currentTimeMillis()));
        properties.put(WorkflowControlConstants.PROP_LAST_MODIFIED_BY, userId);
        properties.put(WorkflowControlConstants.PROP_MODIFICATION_REASON, WorkflowControlConstants.REASON_VERSION_UPDATE);
        
        workflow.setPropertiesMap(properties);
        
        // Save workflow
        workflowInstanceDAO.updateWorkflowInstance(workflow);
        
        return workflow;
    }
    
    /**
     * Convert a WorkflowInstanceRequest to a WorkflowInstanceDTO
     * @param request The request to convert
     * @return The converted DTO
     */
    private WorkflowInstanceDTO convertToDTO(WorkflowInstanceRequest request) {
        // In a real implementation, this would do a proper conversion
        // For now, just create a simple DTO with the name
        WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
        dto.setName(request.getName());
        return dto;
    }
}
