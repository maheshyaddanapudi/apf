package com.workday.apflow.service;

import com.workday.apflow.constants.ErrorHandlingConstants;
import com.workday.apflow.constants.TaskConstants;
import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.error.RetryPolicy;
import com.workday.apflow.error.TaskException;
import com.workday.apflow.execution.ExecutionQueuingInterceptor;
import com.workday.apflow.model.TaskInstance;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Timestamp;
import java.util.Map;

/**
 * Service for retrying failed tasks.
 * Provides methods for retrying tasks with configurable retry policies.
 */
public class TaskRetryService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskRetryService.class);
    
    private final TaskInstanceDAO taskInstanceDAO;
    private final ExecutionQueuingInterceptor interceptor;
    
    /**
     * Constructor
     * @param taskInstanceDAO The task instance DAO
     * @param interceptor The execution queuing interceptor
     */
    public TaskRetryService(TaskInstanceDAO taskInstanceDAO, ExecutionQueuingInterceptor interceptor) {
        this.taskInstanceDAO = taskInstanceDAO;
        this.interceptor = interceptor;
    }
    
    /**
     * Retry a failed task
     * @param taskInstanceId The task instance ID
     * @return The retried task instance
     */
    public TaskInstance retryTask(Integer taskInstanceId) {
        LOGGER.info("Retrying task: {}", taskInstanceId);
        
        // Get task instance
        TaskInstance task = taskInstanceDAO.getTaskInstance(taskInstanceId);
        
        if (task == null) {
            throw new IllegalArgumentException("Task instance not found: " + taskInstanceId);
        }
        
        // Check if task is in a state that can be retried
        if (!TaskConstants.STATUS_FAILED.equals(task.getStatus())) {
            throw new TaskException(
                "Task is not in a failed state: " + taskInstanceId,
                ErrorHandlingConstants.ERROR_CODE_TASK_EXECUTION_FAILED,
                ErrorHandlingConstants.ERROR_TYPE_VALIDATION,
                false,
                taskInstanceId
            );
        }
        
        // Update task status
        task.setStatus(TaskConstants.STATUS_PENDING);
        task.setStartedAt(null);
        task.setCompletedAt(null);
        
        // Increment retry count if it exists, otherwise set it to 1
        Map<String, Object> properties = task.getPropertiesMap();
        if (properties.containsKey("retryCount")) {
            int retryCount = (int) properties.get("retryCount");
            properties.put("retryCount", retryCount + 1);
        } else {
            properties.put("retryCount", 1);
        }
        task.setPropertiesMap(properties);
        
        // Save task
        taskInstanceDAO.updateTaskInstance(task);
        
        // Queue for execution
        interceptor.interceptTaskRetry(task);
        
        return task;
    }
    
    /**
     * Retry a failed task with new input
     * @param taskInstanceId The task instance ID
     * @param newInputMap The new input data
     * @return The retried task instance
     */
    public TaskInstance retryTaskWithNewInput(Integer taskInstanceId, Map<String, Object> newInputMap) {
        LOGGER.info("Retrying task with new input: {}", taskInstanceId);
        
        // Get task instance
        TaskInstance task = taskInstanceDAO.getTaskInstance(taskInstanceId);
        
        if (task == null) {
            throw new IllegalArgumentException("Task instance not found: " + taskInstanceId);
        }
        
        // Check if task is in a state that can be retried
        if (!TaskConstants.STATUS_FAILED.equals(task.getStatus())) {
            throw new TaskException(
                "Task is not in a failed state: " + taskInstanceId,
                ErrorHandlingConstants.ERROR_CODE_TASK_EXECUTION_FAILED,
                ErrorHandlingConstants.ERROR_TYPE_VALIDATION,
                false,
                taskInstanceId
            );
        }
        
        // Update task status and input
        task.setStatus(TaskConstants.STATUS_PENDING);
        task.setStartedAt(null);
        task.setCompletedAt(null);
        task.setInputMap(newInputMap);
        
        // Increment retry count if it exists, otherwise set it to 1
        Map<String, Object> properties = task.getPropertiesMap();
        if (properties.containsKey("retryCount")) {
            int retryCount = (int) properties.get("retryCount");
            properties.put("retryCount", retryCount + 1);
        } else {
            properties.put("retryCount", 1);
        }
        task.setPropertiesMap(properties);
        
        // Save task
        taskInstanceDAO.updateTaskInstance(task);
        
        // Queue for execution
        interceptor.interceptTaskRetry(task);
        
        return task;
    }
    
    /**
     * Apply retry policy to a failed task
     * @param taskInstanceId The task instance ID
     * @param retryPolicy The retry policy
     * @return True if the task was retried, false if max retries reached
     */
    public boolean applyRetryPolicy(Integer taskInstanceId, RetryPolicy retryPolicy) {
        LOGGER.info("Applying retry policy to task: {}", taskInstanceId);
        
        // Get task instance
        TaskInstance task = taskInstanceDAO.getTaskInstance(taskInstanceId);
        
        if (task == null) {
            throw new IllegalArgumentException("Task instance not found: " + taskInstanceId);
        }
        
        // Check if task is in a state that can be retried
        if (!TaskConstants.STATUS_FAILED.equals(task.getStatus())) {
            throw new TaskException(
                "Task is not in a failed state: " + taskInstanceId,
                ErrorHandlingConstants.ERROR_CODE_TASK_EXECUTION_FAILED,
                ErrorHandlingConstants.ERROR_TYPE_VALIDATION,
                false,
                taskInstanceId
            );
        }
        
        // Get current retry count
        Map<String, Object> properties = task.getPropertiesMap();
        int retryCount = 0;
        if (properties.containsKey("retryCount")) {
            retryCount = (int) properties.get("retryCount");
        }
        
        // Check if max retries reached
        if (retryCount >= retryPolicy.getMaxRetries()) {
            LOGGER.info("Max retries reached for task: {}", taskInstanceId);
            return false;
        }
        
        // Calculate delay
        long delayMillis = retryPolicy.calculateDelayMillis(retryCount + 1);
        
        // Update task status
        task.setStatus(TaskConstants.STATUS_PENDING);
        task.setStartedAt(null);
        task.setCompletedAt(null);
        
        // Increment retry count
        properties.put("retryCount", retryCount + 1);
        properties.put("lastRetryTime", new Timestamp(System.currentTimeMillis()));
        task.setPropertiesMap(properties);
        
        // Save task
        taskInstanceDAO.updateTaskInstance(task);
        
        // Queue for execution with delay
        if (delayMillis > 0) {
            // In a real implementation, this would schedule the task for execution after the delay
            LOGGER.info("Scheduling task retry with delay of {} ms: {}", delayMillis, taskInstanceId);
            // For now, just queue it immediately
            interceptor.interceptTaskRetry(task);
        } else {
            interceptor.interceptTaskRetry(task);
        }
        
        return true;
    }
}
