package com.workday.apflow.service;
import com.workday.apflow.constants.TaskConstants;
import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.dto.request.TaskInstanceRequest;
import com.workday.apflow.model.TaskInstance;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Abstract implementation of TaskInstanceService that provides common functionality.
 */
public abstract class AbstractTaskInstanceService implements TaskInstanceService {
    
    /**
     * Get the TaskInstanceDAO
     * @return The TaskInstanceDAO
     */
    public abstract TaskInstanceDAO getTaskInstanceDAO();
    
    @Override
    public TaskInstance getTaskInstance(Integer taskInstanceId) {
        return getTaskInstanceDAO().getTaskInstance(taskInstanceId);
    }
    
    @Override
    public List<TaskInstance> getTaskInstancesByWorkflowInstance(Integer workflowInstanceId) {
        return getTaskInstanceDAO().getTaskInstancesByWorkflowInstance(workflowInstanceId);
    }
    
    @Override
    public List<TaskInstance> getTaskInstancesByStatus(String status) {
        return getTaskInstanceDAO().getTaskInstancesByStatus(status);
    }
    
    @Override
    public List<TaskInstance> getTaskInstancesByAssignment(String assignment) {
        return getTaskInstanceDAO().getTaskInstancesByAssignment(assignment);
    }
    
    @Override
    public TaskInstance cancelTaskInstance(Integer taskInstanceId) {
        TaskInstance taskInstance = getTaskInstanceDAO().getTaskInstance(taskInstanceId);
        if (taskInstance == null) {
            throw new RuntimeException("Task instance not found: " + taskInstanceId);
        }
        
        if (TaskConstants.STATUS_COMPLETED.equals(taskInstance.getStatus()) || 
            TaskConstants.STATUS_TERMINATED.equals(taskInstance.getStatus())) {
            throw new RuntimeException("Cannot cancel a task that is already terminated");
        }
        
        taskInstance.setStatus(TaskConstants.STATUS_TERMINATED);
        return getTaskInstanceDAO().updateTaskInstance(taskInstance);
    }
    
    @Override
    public TaskInstance updateTaskInstance(TaskInstance taskInstance) {
        return getTaskInstanceDAO().updateTaskInstance(taskInstance);
    }
    
    @Override
    public List<TaskInstance> getTasksByDueDate(Date dueDate) {
        // Since this method is not in the DAO, we need to implement it here
        // We'll get all pending tasks and filter by due date
        List<TaskInstance> allPendingTasks = getTaskInstanceDAO().getTaskInstancesByStatus(TaskConstants.STATUS_PENDING);
        List<TaskInstance> tasksDueOnDate = new ArrayList<>();
        
        Calendar dueDateCal = Calendar.getInstance();
        dueDateCal.setTime(dueDate);
        dueDateCal.set(Calendar.HOUR_OF_DAY, 0);
        dueDateCal.set(Calendar.MINUTE, 0);
        dueDateCal.set(Calendar.SECOND, 0);
        dueDateCal.set(Calendar.MILLISECOND, 0);
        
        Calendar endOfDayCal = Calendar.getInstance();
        endOfDayCal.setTime(dueDate);
        endOfDayCal.set(Calendar.HOUR_OF_DAY, 23);
        endOfDayCal.set(Calendar.MINUTE, 59);
        endOfDayCal.set(Calendar.SECOND, 59);
        endOfDayCal.set(Calendar.MILLISECOND, 999);
        
        Date startOfDay = dueDateCal.getTime();
        Date endOfDay = endOfDayCal.getTime();
        
        for (TaskInstance task : allPendingTasks) {
            if (task.getDueDate() != null && 
                !task.getDueDate().before(startOfDay) && 
                !task.getDueDate().after(endOfDay)) {
                tasksDueOnDate.add(task);
            }
        }
        
        return tasksDueOnDate;
    }
    
    @Override
    public List<TaskInstance> getOverdueTasks() {
        // Since this method is not in the DAO, we need to implement it here
        // We'll get all pending tasks and filter by due date
        List<TaskInstance> allPendingTasks = getTaskInstanceDAO().getTaskInstancesByStatus(TaskConstants.STATUS_PENDING);
        List<TaskInstance> overdueTasks = new ArrayList<>();
        
        Date now = new Date();
        
        for (TaskInstance task : allPendingTasks) {
            if (task.getDueDate() != null && task.getDueDate().before(now)) {
                overdueTasks.add(task);
            }
        }
        
        return overdueTasks;
    }
    
    /**
     * Update the status of a task instance
     * @param taskInstanceId The task instance ID
     * @param newStatus The new status
     * @return The updated task instance
     */
    public TaskInstance updateTaskStatus(Integer taskInstanceId, String newStatus) {
        TaskInstance taskInstance = getTaskInstanceDAO().getTaskInstance(taskInstanceId);
        if (taskInstance == null) {
            throw new RuntimeException("Task instance not found: " + taskInstanceId);
        }
        
        taskInstance.setStatus(newStatus);
        return getTaskInstanceDAO().updateTaskInstance(taskInstance);
    }
}
