package com.workday.apflow.service;

import com.workday.apflow.dto.request.WorkflowInstanceRequest;
import com.workday.apflow.model.WorkflowInstance;
import java.util.Date;
import java.util.List;

/**
 * Service for workflow instance operations.
 * This is a simplified implementation that focuses on pure workflow lifecycle and state management.
 */
public interface WorkflowInstanceService {
    
    /**
     * Create a workflow instance
     * @param request The workflow instance request
     * @return The created workflow instance
     */
    WorkflowInstance createWorkflowInstance(WorkflowInstanceRequest request);
    
    /**
     * Start a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return The started workflow instance
     */
    WorkflowInstance startWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Get a workflow instance by ID
     * @param workflowInstanceId The workflow instance ID
     * @return The workflow instance
     */
    WorkflowInstance getWorkflowInstance(Integer workflowInstanceId);
    
    /**
     * Get all workflow instances
     * @return List of all workflow instances
     */
    List<WorkflowInstance> getAllWorkflowInstances();
    
    /**
     * Get workflow instances by status
     * @param status The status
     * @return List of workflow instances with the specified status
     */
    List<WorkflowInstance> getWorkflowInstancesByStatus(String status);
    
    /**
     * Get workflow instances by creator
     * @param creator The creator
     * @return List of workflow instances created by the specified user
     */
    List<WorkflowInstance> getWorkflowInstancesByCreator(String creator);
    
    /**
     * Get workflow instances by date range
     * @param startDate The start date
     * @param endDate The end date
     * @return List of workflow instances created within the specified date range
     */
    List<WorkflowInstance> getWorkflowInstancesByDateRange(Date startDate, Date endDate);
    
    /**
     * Update a workflow instance
     * @param workflowInstance The workflow instance to update
     * @return The updated workflow instance
     */
    WorkflowInstance updateWorkflowInstance(WorkflowInstance workflowInstance);
    
    /**
     * Cancel a workflow instance
     * @param workflowInstanceId The workflow instance ID
     * @return The canceled workflow instance
     */
    WorkflowInstance cancelWorkflowInstance(Integer workflowInstanceId);
}
