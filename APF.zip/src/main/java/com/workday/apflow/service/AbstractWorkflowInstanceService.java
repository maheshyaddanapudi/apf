package com.workday.apflow.service;

import com.workday.apflow.dao.WorkflowInstanceDAO;
import com.workday.apflow.dto.request.WorkflowInstanceRequest;
import com.workday.apflow.dto.workflow.WorkflowInstanceDTO;
import com.workday.apflow.model.WorkflowInstance;
import com.workday.apflow.util.DtoConverter;

/**
 * Abstract implementation of WorkflowInstanceService that provides common functionality.
 */
public abstract class AbstractWorkflowInstanceService implements WorkflowInstanceService {
    
    /**
     * Get the WorkflowInstanceDAO
     * @return The WorkflowInstanceDAO
     */
    public abstract WorkflowInstanceDAO getWorkflowInstanceDAO();
    
    /**
     * Update a workflow instance with a request
     * @param workflowInstanceId The workflow instance ID
     * @param request The workflow instance request
     * @return The updated workflow instance
     */
    public WorkflowInstance updateWorkflowInstance(Integer workflowInstanceId, WorkflowInstanceRequest request) {
        // Get the existing workflow instance
        WorkflowInstance instance = getWorkflowInstance(workflowInstanceId);
        if (instance == null) {
            throw new IllegalArgumentException("Workflow instance not found: " + workflowInstanceId);
        }
        
        // Update the instance with the request data
        if (request.getName() != null) {
            instance.setName(request.getName());
        }
        
        // Update the instance DTO
        WorkflowInstanceDTO dto = instance.getInstanceDto();
        if (dto == null) {
            dto = new WorkflowInstanceDTO();
        }
        
        // Update the DTO with the request data
        if (request.getName() != null) {
            dto.setName(request.getName());
        }
        
        // Set the updated DTO
        instance.setInstanceDto(dto);
        
        // Update the instance
        return updateWorkflowInstance(instance);
    }
}
