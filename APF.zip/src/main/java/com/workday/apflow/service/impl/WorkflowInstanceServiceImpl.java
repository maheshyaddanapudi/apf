package com.workday.apflow.service.impl;

import com.workday.apflow.dao.WorkflowInstanceDAO;
import com.workday.apflow.dto.request.WorkflowInstanceRequest;
import com.workday.apflow.dto.workflow.WorkflowInstanceDTO;
import com.workday.apflow.model.WorkflowInstance;
import com.workday.apflow.service.WorkflowInstanceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Concrete implementation of the WorkflowInstanceService interface.
 */
public class WorkflowInstanceServiceImpl implements WorkflowInstanceService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(WorkflowInstanceServiceImpl.class);
    private final WorkflowInstanceDAO workflowInstanceDAO;
    
    /**
     * Constructor with WorkflowInstanceDAO injection.
     * 
     * @param workflowInstanceDAO The WorkflowInstanceDAO implementation
     */
    public WorkflowInstanceServiceImpl(WorkflowInstanceDAO workflowInstanceDAO) {
        this.workflowInstanceDAO = workflowInstanceDAO;
    }
    
    /**
     * Get the WorkflowInstanceDAO
     * @return The WorkflowInstanceDAO
     */
    public WorkflowInstanceDAO getWorkflowInstanceDAO() {
        return workflowInstanceDAO;
    }
    
    @Override
    public WorkflowInstance createWorkflowInstance(WorkflowInstanceRequest request) {
        try {
            LOGGER.info("Creating workflow instance: {}", request.getName());
            
            WorkflowInstance instance = new WorkflowInstance();
            instance.setName(request.getName());
            // Store workflow ID in properties map since there's no direct field
            Map<String, Object> properties = new HashMap<>();
            properties.put("workflowId", 1); // Default value
            instance.setPropertiesMap(properties);
            
            instance.setStatus("CREATED");
            instance.setCreatedBy(request.getCreatedBy());
            
            // Create and set the instance DTO
            WorkflowInstanceDTO dto = new WorkflowInstanceDTO();
            dto.setName(request.getName());
            // Store workflow ID in metadata since there's no direct field
            Map<String, Object> metadata = new HashMap<>();
            metadata.put("workflowId", 1); // Default value
            dto.setMetadata(metadata);
            
            instance.setInstanceDto(dto);
            
            return workflowInstanceDAO.createWorkflowInstance(instance);
        } catch (Exception e) {
            LOGGER.error("Failed to create workflow instance", e);
            throw new RuntimeException("Failed to create workflow instance", e);
        }
    }
    
    @Override
    public WorkflowInstance startWorkflowInstance(Integer workflowInstanceId) {
        try {
            LOGGER.info("Starting workflow instance: {}", workflowInstanceId);
            
            WorkflowInstance instance = getWorkflowInstance(workflowInstanceId);
            if (instance == null) {
                throw new RuntimeException("Workflow instance not found: " + workflowInstanceId);
            }
            
            if (!"CREATED".equals(instance.getStatus())) {
                throw new RuntimeException("Cannot start workflow instance that is not in CREATED status");
            }
            
            instance.setStatus("RUNNING");
            return workflowInstanceDAO.updateWorkflowInstance(instance);
        } catch (Exception e) {
            LOGGER.error("Failed to start workflow instance", e);
            throw new RuntimeException("Failed to start workflow instance", e);
        }
    }
    
    @Override
    public WorkflowInstance getWorkflowInstance(Integer workflowInstanceId) {
        try {
            LOGGER.info("Getting workflow instance: {}", workflowInstanceId);
            return workflowInstanceDAO.getWorkflowInstance(workflowInstanceId);
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow instance", e);
            throw new RuntimeException("Failed to get workflow instance", e);
        }
    }
    
    @Override
    public List<WorkflowInstance> getAllWorkflowInstances() {
        try {
            LOGGER.info("Getting all workflow instances");
            return workflowInstanceDAO.getAllWorkflowInstances();
        } catch (Exception e) {
            LOGGER.error("Failed to get all workflow instances", e);
            throw new RuntimeException("Failed to get all workflow instances", e);
        }
    }
    
    @Override
    public List<WorkflowInstance> getWorkflowInstancesByStatus(String status) {
        try {
            LOGGER.info("Getting workflow instances with status: {}", status);
            return workflowInstanceDAO.getWorkflowInstancesByStatus(status);
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow instances by status", e);
            throw new RuntimeException("Failed to get workflow instances by status", e);
        }
    }
    
    @Override
    public List<WorkflowInstance> getWorkflowInstancesByCreator(String creator) {
        try {
            LOGGER.info("Getting workflow instances created by: {}", creator);
            // Since WorkflowInstanceDAO doesn't have getWorkflowInstancesByCreator method,
            // we'll implement it here by filtering all instances
            List<WorkflowInstance> allInstances = workflowInstanceDAO.getAllWorkflowInstances();
            List<WorkflowInstance> filteredInstances = new ArrayList<>();
            
            for (WorkflowInstance instance : allInstances) {
                if (creator.equals(instance.getCreatedBy())) {
                    filteredInstances.add(instance);
                }
            }
            
            return filteredInstances;
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow instances by creator", e);
            throw new RuntimeException("Failed to get workflow instances by creator", e);
        }
    }
    
    @Override
    public List<WorkflowInstance> getWorkflowInstancesByDateRange(Date startDate, Date endDate) {
        try {
            LOGGER.info("Getting workflow instances between {} and {}", startDate, endDate);
            // Since WorkflowInstanceDAO doesn't have getWorkflowInstancesByDateRange method,
            // we'll implement it here by filtering all instances
            List<WorkflowInstance> allInstances = workflowInstanceDAO.getAllWorkflowInstances();
            List<WorkflowInstance> filteredInstances = new ArrayList<>();
            
            for (WorkflowInstance instance : allInstances) {
                Date createdAt = instance.getCreatedAt();
                if (createdAt != null && 
                    (startDate == null || !createdAt.before(startDate)) && 
                    (endDate == null || !createdAt.after(endDate))) {
                    filteredInstances.add(instance);
                }
            }
            
            return filteredInstances;
        } catch (Exception e) {
            LOGGER.error("Failed to get workflow instances by date range", e);
            throw new RuntimeException("Failed to get workflow instances by date range", e);
        }
    }
    
    @Override
    public WorkflowInstance updateWorkflowInstance(WorkflowInstance workflowInstance) {
        try {
            LOGGER.info("Updating workflow instance: {}", workflowInstance.getId());
            return workflowInstanceDAO.updateWorkflowInstance(workflowInstance);
        } catch (Exception e) {
            LOGGER.error("Failed to update workflow instance", e);
            throw new RuntimeException("Failed to update workflow instance", e);
        }
    }
    
    /**
     * Update a workflow instance with a request
     * @param workflowInstanceId The workflow instance ID
     * @param request The workflow instance request
     * @return The updated workflow instance
     */
    public WorkflowInstance updateWorkflowInstance(Integer workflowInstanceId, WorkflowInstanceRequest request) {
        try {
            LOGGER.info("Updating workflow instance: {} with request", workflowInstanceId);
            
            // Get the existing workflow instance
            WorkflowInstance instance = getWorkflowInstance(workflowInstanceId);
            if (instance == null) {
                throw new IllegalArgumentException("Workflow instance not found: " + workflowInstanceId);
            }
            
            // Update the instance with the request data
            if (request.getName() != null) {
                instance.setName(request.getName());
            }
            
            // Update the instance DTO
            WorkflowInstanceDTO dto = instance.getInstanceDto();
            if (dto == null) {
                dto = new WorkflowInstanceDTO();
            }
            
            // Update the DTO with the request data
            if (request.getName() != null) {
                dto.setName(request.getName());
            }
            
            // Set the updated DTO
            instance.setInstanceDto(dto);
            
            // Update the instance
            return updateWorkflowInstance(instance);
        } catch (Exception e) {
            LOGGER.error("Failed to update workflow instance with request", e);
            throw new RuntimeException("Failed to update workflow instance with request", e);
        }
    }
    
    @Override
    public WorkflowInstance cancelWorkflowInstance(Integer workflowInstanceId) {
        try {
            LOGGER.info("Cancelling workflow instance: {}", workflowInstanceId);
            
            WorkflowInstance instance = getWorkflowInstance(workflowInstanceId);
            if (instance == null) {
                throw new RuntimeException("Workflow instance not found: " + workflowInstanceId);
            }
            
            if ("COMPLETED".equals(instance.getStatus()) || "CANCELLED".equals(instance.getStatus())) {
                throw new RuntimeException("Cannot cancel a workflow that is already completed or cancelled");
            }
            
            instance.setStatus("CANCELLED");
            return workflowInstanceDAO.updateWorkflowInstance(instance);
        } catch (Exception e) {
            LOGGER.error("Failed to cancel workflow instance", e);
            throw new RuntimeException("Failed to cancel workflow instance", e);
        }
    }
}
