package com.workday.apflow.service.impl;

import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.dto.request.TaskInstanceRequest;
import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.service.TaskInstanceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Implementation of the TaskInstanceService interface.
 */
public class TaskInstanceServiceImpl implements TaskInstanceService {
    
    private static final Logger LOGGER = LoggerFactory.getLogger(TaskInstanceServiceImpl.class);
    private final TaskInstanceDAO taskInstanceDAO;
    
    /**
     * Constructor with TaskInstanceDAO injection.
     * 
     * @param taskInstanceDAO The TaskInstanceDAO implementation
     */
    public TaskInstanceServiceImpl(TaskInstanceDAO taskInstanceDAO) {
        this.taskInstanceDAO = taskInstanceDAO;
    }
    
    @Override
    public TaskInstanceDAO getTaskInstanceDAO() {
        return taskInstanceDAO;
    }
    
    @Override
    public TaskInstance createTaskInstance(TaskInstanceRequest request) {
        try {
            LOGGER.info("Creating task instance: {}", request.getName());
            
            TaskInstance taskInstance = new TaskInstance();
            taskInstance.setWorkflowInstanceId(request.getWorkflowInstanceId());
            // TaskGroupInstanceId is not in the request, so set to null
            taskInstance.setTaskGroupInstanceId(null);
            taskInstance.setName(request.getName());
            taskInstance.setType(request.getType());
            taskInstance.setStatus("CREATED");
            taskInstance.setAssignment(request.getAssignment());
            // Use operatorId as createdBy since there's no createdBy in the request
            taskInstance.setCreatedBy(request.getOperatorId());
            taskInstance.setInputJson(request.getInputJson());
            // No propertiesJson in the request, so set to null
            taskInstance.setPropertiesJson(null);
            
            return taskInstanceDAO.createTaskInstance(taskInstance);
        } catch (Exception e) {
            LOGGER.error("Failed to create task instance", e);
            throw new RuntimeException("Failed to create task instance", e);
        }
    }
    
    @Override
    public List<TaskInstance> createTaskInstances(List<TaskInstanceRequest> requests) {
        try {
            LOGGER.info("Creating {} task instances", requests.size());
            
            List<TaskInstance> createdInstances = new ArrayList<>();
            for (TaskInstanceRequest request : requests) {
                TaskInstance taskInstance = createTaskInstance(request);
                if (taskInstance != null) {
                    createdInstances.add(taskInstance);
                }
            }
            
            return createdInstances;
        } catch (Exception e) {
            LOGGER.error("Failed to create task instances", e);
            throw new RuntimeException("Failed to create task instances", e);
        }
    }
    
    @Override
    public TaskInstance getTaskInstance(Integer taskInstanceId) {
        try {
            LOGGER.info("Getting task instance: {}", taskInstanceId);
            return taskInstanceDAO.getTaskInstance(taskInstanceId);
        } catch (Exception e) {
            LOGGER.error("Failed to get task instance", e);
            throw new RuntimeException("Failed to get task instance", e);
        }
    }
    
    @Override
    public List<TaskInstance> getTaskInstancesByWorkflowInstance(Integer workflowInstanceId) {
        try {
            LOGGER.info("Getting task instances for workflow: {}", workflowInstanceId);
            return taskInstanceDAO.getTaskInstancesByWorkflowInstance(workflowInstanceId);
        } catch (Exception e) {
            LOGGER.error("Failed to get task instances for workflow", e);
            throw new RuntimeException("Failed to get task instances for workflow", e);
        }
    }
    
    @Override
    public List<TaskInstance> getTaskInstancesByStatus(String status) {
        try {
            LOGGER.info("Getting task instances with status: {}", status);
            return taskInstanceDAO.getTaskInstancesByStatus(status);
        } catch (Exception e) {
            LOGGER.error("Failed to get task instances by status", e);
            throw new RuntimeException("Failed to get task instances by status", e);
        }
    }
    
    @Override
    public List<TaskInstance> getTaskInstancesByAssignment(String assignment) {
        try {
            LOGGER.info("Getting task instances with assignment: {}", assignment);
            return taskInstanceDAO.getTaskInstancesByAssignment(assignment);
        } catch (Exception e) {
            LOGGER.error("Failed to get task instances by assignment", e);
            throw new RuntimeException("Failed to get task instances by assignment", e);
        }
    }
    
    @Override
    public TaskInstance cancelTaskInstance(Integer taskInstanceId) {
        try {
            LOGGER.info("Cancelling task instance: {}", taskInstanceId);
            
            TaskInstance taskInstance = taskInstanceDAO.getTaskInstance(taskInstanceId);
            if (taskInstance == null) {
                throw new RuntimeException("Task instance not found: " + taskInstanceId);
            }
            
            taskInstance.setStatus("CANCELLED");
            return taskInstanceDAO.updateTaskInstance(taskInstance);
        } catch (Exception e) {
            LOGGER.error("Failed to cancel task instance", e);
            throw new RuntimeException("Failed to cancel task instance", e);
        }
    }
    
    @Override
    public TaskInstance updateTaskInstance(TaskInstance taskInstance) {
        try {
            LOGGER.info("Updating task instance: {}", taskInstance.getId());
            return taskInstanceDAO.updateTaskInstance(taskInstance);
        } catch (Exception e) {
            LOGGER.error("Failed to update task instance", e);
            throw new RuntimeException("Failed to update task instance", e);
        }
    }
    
    @Override
    public List<TaskInstance> getTasksByDueDate(Date dueDate) {
        // This would typically query tasks with a due date property
        // For now, return an empty list as the schema doesn't have a due date field
        LOGGER.info("Getting tasks by due date: {}", dueDate);
        return new ArrayList<>();
    }
    
    @Override
    public List<TaskInstance> getOverdueTasks() {
        // This would typically query tasks with a due date in the past
        // For now, return an empty list as the schema doesn't have a due date field
        LOGGER.info("Getting overdue tasks");
        return new ArrayList<>();
    }
    
    @Override
    public List<TaskInstance> getTasksByTaskGroup(Integer taskGroupInstanceId) {
        try {
            LOGGER.info("Getting tasks for task group: {}", taskGroupInstanceId);
            return taskInstanceDAO.getTaskInstancesByTaskGroupId(taskGroupInstanceId);
        } catch (Exception e) {
            LOGGER.error("Failed to get tasks by task group", e);
            throw new RuntimeException("Failed to get tasks by task group", e);
        }
    }
    
    @Override
    public List<TaskInstance> getTasksByType(String type) {
        try {
            LOGGER.info("Getting tasks by type: {}", type);
            return taskInstanceDAO.getTaskInstancesByType(type);
        } catch (Exception e) {
            LOGGER.error("Failed to get tasks by type", e);
            throw new RuntimeException("Failed to get tasks by type", e);
        }
    }
}
