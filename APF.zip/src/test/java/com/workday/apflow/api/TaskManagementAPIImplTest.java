package com.workday.apflow.api;

import com.workday.apflow.dto.request.TaskInstanceRequest;
import com.workday.apflow.dto.response.TaskInstanceResponse;
import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.service.TaskInstanceService;
import com.workday.apflow.service.TaskCompletionService;
import com.workday.apflow.service.TaskRetryService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class TaskManagementAPIImplTest {
    
    @Mock
    private TaskInstanceService taskInstanceService;
    
    @Mock
    private TaskCompletionService taskCompletionService;
    
    @Mock
    private TaskRetryService taskRetryService;
    
    private TaskManagementAPIImpl taskManagementAPI;
    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        taskManagementAPI = new TaskManagementAPIImpl(taskInstanceService, taskCompletionService, taskRetryService);
    }
    
    @Test
    void testCreateTaskInstance() {
        // Setup
        TaskInstanceRequest request = new TaskInstanceRequest();
        request.setName("Test Task");
        request.setType("TODO");
        request.setAssignment("user1");
        
        TaskInstance createdTask = new TaskInstance();
        createdTask.setId(123);
        createdTask.setName("Test Task");
        createdTask.setType("TODO");
        createdTask.setStatus("PENDING");
        createdTask.setAssignment("user1");
        createdTask.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        
        when(taskInstanceService.createTaskInstance(any(TaskInstanceRequest.class))).thenReturn(createdTask);
        
        // Execute
        TaskInstanceResponse response = taskManagementAPI.createTaskInstance(request);
        
        // Verify
        assertNotNull(response);
        assertEquals(123, response.getId());
        assertEquals("Test Task", response.getName());
        assertEquals("TODO", response.getType());
        assertEquals("PENDING", response.getStatus());
        assertEquals("user1", response.getAssignment());
        assertNotNull(response.getCreatedAt());
        
        verify(taskInstanceService).createTaskInstance(any(TaskInstanceRequest.class));
    }
    
    @Test
    void testCreateTaskInstances() {
        // Setup
        List<TaskInstanceRequest> requests = new ArrayList<>();
        TaskInstanceRequest request1 = new TaskInstanceRequest();
        request1.setName("Task 1");
        request1.setType("TODO");
        request1.setAssignment("user1");
        
        TaskInstanceRequest request2 = new TaskInstanceRequest();
        request2.setName("Task 2");
        request2.setType("TODO");
        request2.setAssignment("user2");
        
        requests.add(request1);
        requests.add(request2);
        
        List<TaskInstance> createdTasks = new ArrayList<>();
        TaskInstance task1 = new TaskInstance();
        task1.setId(123);
        task1.setName("Task 1");
        task1.setType("TODO");
        task1.setStatus("PENDING");
        task1.setAssignment("user1");
        
        TaskInstance task2 = new TaskInstance();
        task2.setId(456);
        task2.setName("Task 2");
        task2.setType("TODO");
        task2.setStatus("PENDING");
        task2.setAssignment("user2");
        
        createdTasks.add(task1);
        createdTasks.add(task2);
        
        when(taskInstanceService.createTaskInstances(anyList())).thenReturn(createdTasks);
        
        // Execute
        List<TaskInstanceResponse> responses = taskManagementAPI.createTaskInstances(requests);
        
        // Verify
        assertNotNull(responses);
        assertEquals(2, responses.size());
        assertEquals(123, responses.get(0).getId());
        assertEquals("Task 1", responses.get(0).getName());
        assertEquals(456, responses.get(1).getId());
        assertEquals("Task 2", responses.get(1).getName());
        
        verify(taskInstanceService).createTaskInstances(anyList());
    }
    
    @Test
    void testGetTaskInstance() {
        // Setup
        Integer taskId = 123;
        TaskInstance task = new TaskInstance();
        task.setId(taskId);
        task.setName("Test Task");
        task.setType("TODO");
        task.setStatus("PENDING");
        task.setAssignment("user1");
        
        when(taskInstanceService.getTaskInstance(taskId)).thenReturn(task);
        
        // Execute
        TaskInstanceResponse response = taskManagementAPI.getTaskInstance(taskId);
        
        // Verify
        assertNotNull(response);
        assertEquals(taskId, response.getId());
        assertEquals("Test Task", response.getName());
        assertEquals("TODO", response.getType());
        assertEquals("PENDING", response.getStatus());
        assertEquals("user1", response.getAssignment());
        
        verify(taskInstanceService).getTaskInstance(taskId);
    }
    
    @Test
    void testGetTaskInstancesByWorkflowInstance() {
        // Setup
        Integer workflowInstanceId = 123;
        List<TaskInstance> tasks = new ArrayList<>();
        TaskInstance task1 = new TaskInstance();
        task1.setId(456);
        task1.setName("Task 1");
        task1.setWorkflowInstanceId(workflowInstanceId);
        
        TaskInstance task2 = new TaskInstance();
        task2.setId(789);
        task2.setName("Task 2");
        task2.setWorkflowInstanceId(workflowInstanceId);
        
        tasks.add(task1);
        tasks.add(task2);
        
        when(taskInstanceService.getTaskInstancesByWorkflowInstance(workflowInstanceId)).thenReturn(tasks);
        
        // Execute
        List<TaskInstanceResponse> responses = taskManagementAPI.getTaskInstancesByWorkflowInstance(workflowInstanceId);
        
        // Verify
        assertNotNull(responses);
        assertEquals(2, responses.size());
        assertEquals(456, responses.get(0).getId());
        assertEquals("Task 1", responses.get(0).getName());
        assertEquals(789, responses.get(1).getId());
        assertEquals("Task 2", responses.get(1).getName());
        
        verify(taskInstanceService).getTaskInstancesByWorkflowInstance(workflowInstanceId);
    }
    
    @Test
    void testGetTaskInstancesByStatus() {
        // Setup
        String status = "PENDING";
        List<TaskInstance> tasks = new ArrayList<>();
        TaskInstance task1 = new TaskInstance();
        task1.setId(123);
        task1.setName("Task 1");
        task1.setStatus(status);
        
        TaskInstance task2 = new TaskInstance();
        task2.setId(456);
        task2.setName("Task 2");
        task2.setStatus(status);
        
        tasks.add(task1);
        tasks.add(task2);
        
        when(taskInstanceService.getTaskInstancesByStatus(status)).thenReturn(tasks);
        
        // Execute
        List<TaskInstanceResponse> responses = taskManagementAPI.getTaskInstancesByStatus(status);
        
        // Verify
        assertNotNull(responses);
        assertEquals(2, responses.size());
        assertEquals(123, responses.get(0).getId());
        assertEquals("Task 1", responses.get(0).getName());
        assertEquals(status, responses.get(0).getStatus());
        assertEquals(456, responses.get(1).getId());
        assertEquals("Task 2", responses.get(1).getName());
        assertEquals(status, responses.get(1).getStatus());
        
        verify(taskInstanceService).getTaskInstancesByStatus(status);
    }
    
    @Test
    void testGetTaskInstancesByAssignment() {
        // Setup
        String assignment = "user1";
        List<TaskInstance> tasks = new ArrayList<>();
        TaskInstance task1 = new TaskInstance();
        task1.setId(123);
        task1.setName("Task 1");
        task1.setAssignment(assignment);
        
        TaskInstance task2 = new TaskInstance();
        task2.setId(456);
        task2.setName("Task 2");
        task2.setAssignment(assignment);
        
        tasks.add(task1);
        tasks.add(task2);
        
        when(taskInstanceService.getTaskInstancesByAssignment(assignment)).thenReturn(tasks);
        
        // Execute
        List<TaskInstanceResponse> responses = taskManagementAPI.getTaskInstancesByAssignment(assignment);
        
        // Verify
        assertNotNull(responses);
        assertEquals(2, responses.size());
        assertEquals(123, responses.get(0).getId());
        assertEquals("Task 1", responses.get(0).getName());
        assertEquals(assignment, responses.get(0).getAssignment());
        assertEquals(456, responses.get(1).getId());
        assertEquals("Task 2", responses.get(1).getName());
        assertEquals(assignment, responses.get(1).getAssignment());
        
        verify(taskInstanceService).getTaskInstancesByAssignment(assignment);
    }
    
    @Test
    void testCompleteTask() {
        // Setup
        Integer taskId = 123;
        Map<String, Object> outputMap = new HashMap<>();
        outputMap.put("key1", "value1");
        outputMap.put("key2", 123);
        
        TaskInstance completedTask = new TaskInstance();
        completedTask.setId(taskId);
        completedTask.setName("Test Task");
        completedTask.setStatus("COMPLETED");
        completedTask.setCompletedAt(new Timestamp(System.currentTimeMillis()));
        
        when(taskCompletionService.completeTask(eq(taskId), anyMap())).thenReturn(completedTask);
        
        // Execute
        TaskInstanceResponse response = taskManagementAPI.completeTask(taskId, outputMap);
        
        // Verify
        assertNotNull(response);
        assertEquals(taskId, response.getId());
        assertEquals("Test Task", response.getName());
        assertEquals("COMPLETED", response.getStatus());
        assertNotNull(response.getCompletedAt());
        
        verify(taskCompletionService).completeTask(eq(taskId), anyMap());
    }
    
    @Test
    void testCancelTask() {
        // Setup
        Integer taskId = 123;
        TaskInstance cancelledTask = new TaskInstance();
        cancelledTask.setId(taskId);
        cancelledTask.setName("Test Task");
        cancelledTask.setStatus("CANCELLED");
        // No setCancelledAt method, so we'll skip this line
        when(taskInstanceService.cancelTaskInstance(taskId)).thenReturn(cancelledTask);
        // Execute
        TaskInstanceResponse response = taskManagementAPI.cancelTask(taskId);
        // Verify
        assertNotNull(response);
        assertEquals(taskId, response.getId());
        assertEquals("Test Task", response.getName());
        assertEquals("CANCELLED", response.getStatus());
        // No getCancelledAt method, so we'll skip this line
        verify(taskInstanceService).cancelTaskInstance(taskId);
    }
    
    @Test
    void testReassignTask() {
        // Setup
        Integer taskId = 123;
        String newAssignment = "user2";
        TaskInstance task = new TaskInstance();
        task.setId(taskId);
        task.setName("Test Task");
        task.setStatus("PENDING");
        task.setAssignment("user1");
        TaskInstance reassignedTask = new TaskInstance();
        reassignedTask.setId(taskId);
        reassignedTask.setName("Test Task");
        reassignedTask.setStatus("PENDING");
        reassignedTask.setAssignment(newAssignment);
        when(taskInstanceService.getTaskInstance(taskId)).thenReturn(task);
        when(taskInstanceService.updateTaskInstance(any(TaskInstance.class))).thenReturn(reassignedTask);
        // Execute
        TaskInstanceResponse response = taskManagementAPI.reassignTask(taskId, newAssignment);
        // Verify
        assertNotNull(response);
        assertEquals(taskId, response.getId());
        assertEquals("Test Task", response.getName());
        assertEquals("PENDING", response.getStatus());
        assertEquals(newAssignment, response.getAssignment());
        verify(taskInstanceService).getTaskInstance(taskId);
        verify(taskInstanceService).updateTaskInstance(any(TaskInstance.class));
    }
    
    @Test
    void testSkipTask() {
        // Setup
        Integer taskId = 123;
        TaskInstance task = new TaskInstance();
        task.setId(taskId);
        task.setName("Test Task");
        task.setStatus("PENDING");
        TaskInstance skippedTask = new TaskInstance();
        skippedTask.setId(taskId);
        skippedTask.setName("Test Task");
        skippedTask.setStatus("SKIPPED");
        when(taskInstanceService.getTaskInstance(taskId)).thenReturn(task);
        when(taskInstanceService.updateTaskInstance(any(TaskInstance.class))).thenReturn(skippedTask);
        // Execute
        TaskInstanceResponse response = taskManagementAPI.skipTask(taskId);
        // Verify
        assertNotNull(response);
        assertEquals(taskId, response.getId());
        assertEquals("Test Task", response.getName());
        assertEquals("SKIPPED", response.getStatus());
        verify(taskInstanceService).getTaskInstance(taskId);
        verify(taskInstanceService).updateTaskInstance(any(TaskInstance.class));
    }
    
    @Test
    void testRetryTask() {
        // Setup
        Integer taskId = 123;
        TaskInstance task = new TaskInstance();
        task.setId(taskId);
        task.setName("Test Task");
        task.setStatus("FAILED");
        TaskInstance retriedTask = new TaskInstance();
        retriedTask.setId(taskId);
        retriedTask.setName("Test Task");
        retriedTask.setStatus("PENDING");
        when(taskRetryService.retryTask(taskId)).thenReturn(retriedTask);
        // Execute
        TaskInstanceResponse response = taskManagementAPI.retryTask(taskId);
        // Verify
        assertNotNull(response);
        assertEquals(taskId, response.getId());
        assertEquals("Test Task", response.getName());
        assertEquals("PENDING", response.getStatus());
        verify(taskRetryService).retryTask(taskId);
    }
    
    @Test
    void testRetryTaskWithNewInput() {
        // Setup
        Integer taskId = 123;
        Map<String, Object> newInput = new HashMap<>();
        newInput.put("key1", "value1");
        newInput.put("key2", 123);
        TaskInstance task = new TaskInstance();
        task.setId(taskId);
        task.setName("Test Task");
        task.setStatus("FAILED");
        TaskInstance retriedTask = new TaskInstance();
        retriedTask.setId(taskId);
        retriedTask.setName("Test Task");
        retriedTask.setStatus("PENDING");
        retriedTask.setInputMap(newInput);
        when(taskRetryService.retryTaskWithNewInput(eq(taskId), anyMap())).thenReturn(retriedTask);
        // Execute
        TaskInstanceResponse response = taskManagementAPI.retryTaskWithNewInput(taskId, newInput);
        // Verify
        assertNotNull(response);
        assertEquals(taskId, response.getId());
        assertEquals("Test Task", response.getName());
        assertEquals("PENDING", response.getStatus());
        verify(taskRetryService).retryTaskWithNewInput(eq(taskId), anyMap());
    }
    
    @Test
    void testGetTasksByDueDate() {
        // Setup
        Date dueDate = new Date();
        List<TaskInstance> tasks = new ArrayList<>();
        
        TaskInstance task1 = new TaskInstance();
        task1.setId(123);
        task1.setName("Task 1");
        task1.setStatus("PENDING");
        task1.setDueDate(dueDate);
        
        TaskInstance task2 = new TaskInstance();
        task2.setId(456);
        task2.setName("Task 2");
        task2.setStatus("PENDING");
        task2.setDueDate(dueDate);
        
        tasks.add(task1);
        tasks.add(task2);
        
        when(taskInstanceService.getTasksByDueDate(dueDate)).thenReturn(tasks);
        
        // Execute
        List<TaskInstanceResponse> responses = taskManagementAPI.getTasksByDueDate(dueDate);
        
        // Verify
        assertNotNull(responses);
        assertEquals(2, responses.size());
        assertEquals(123, responses.get(0).getId());
        assertEquals("Task 1", responses.get(0).getName());
        assertEquals("PENDING", responses.get(0).getStatus());
        assertEquals(456, responses.get(1).getId());
        assertEquals("Task 2", responses.get(1).getName());
        assertEquals("PENDING", responses.get(1).getStatus());
        
        verify(taskInstanceService).getTasksByDueDate(dueDate);
    }
    
    @Test
    void testGetOverdueTasks() {
        // Setup
        List<TaskInstance> tasks = new ArrayList<>();
        
        TaskInstance task1 = new TaskInstance();
        task1.setId(123);
        task1.setName("Task 1");
        task1.setStatus("PENDING");
        task1.setDueDate(new Date(System.currentTimeMillis() - 86400000)); // Yesterday
        
        TaskInstance task2 = new TaskInstance();
        task2.setId(456);
        task2.setName("Task 2");
        task2.setStatus("PENDING");
        task2.setDueDate(new Date(System.currentTimeMillis() - 172800000)); // 2 days ago
        
        tasks.add(task1);
        tasks.add(task2);
        
        when(taskInstanceService.getOverdueTasks()).thenReturn(tasks);
        
        // Execute
        List<TaskInstanceResponse> responses = taskManagementAPI.getOverdueTasks();
        
        // Verify
        assertNotNull(responses);
        assertEquals(2, responses.size());
        assertEquals(123, responses.get(0).getId());
        assertEquals("Task 1", responses.get(0).getName());
        assertEquals("PENDING", responses.get(0).getStatus());
        assertEquals(456, responses.get(1).getId());
        assertEquals("Task 2", responses.get(1).getName());
        assertEquals("PENDING", responses.get(1).getStatus());
        
        verify(taskInstanceService).getOverdueTasks();
    }
    
    @Test
    void testGetTaskMetrics() {
        // Setup
        Integer taskId = 123;
        TaskInstance task = new TaskInstance();
        task.setId(taskId);
        task.setName("Test Task");
        task.setStatus("COMPLETED");
        task.setCreatedAt(new Timestamp(System.currentTimeMillis() - 3600000)); // 1 hour ago
        task.setStartedAt(new Timestamp(System.currentTimeMillis() - 1800000)); // 30 minutes ago
        task.setCompletedAt(new Timestamp(System.currentTimeMillis())); // Now
        
        when(taskInstanceService.getTaskInstance(taskId)).thenReturn(task);
        
        // Execute
        Map<String, Object> metrics = taskManagementAPI.getTaskMetrics(taskId);
        
        // Verify
        assertNotNull(metrics);
        assertEquals(taskId, metrics.get("id"));
        assertEquals("Test Task", metrics.get("name"));
        assertEquals("COMPLETED", metrics.get("status"));
        assertNotNull(metrics.get("createdAt"));
        assertNotNull(metrics.get("startedAt"));
        assertNotNull(metrics.get("completedAt"));
        assertTrue((Long)metrics.get("durationMs") > 0);
        
        verify(taskInstanceService).getTaskInstance(taskId);
    }
    
    @Test
    void testUpdateTaskProperties() {
        // Setup
        Integer taskId = 123;
        Map<String, Object> properties = new HashMap<>();
        properties.put("priority", "HIGH");
        properties.put("notes", "Updated task notes");
        
        TaskInstance task = new TaskInstance();
        task.setId(taskId);
        task.setName("Test Task");
        task.setStatus("PENDING");
        
        TaskInstance updatedTask = new TaskInstance();
        updatedTask.setId(taskId);
        updatedTask.setName("Test Task");
        updatedTask.setStatus("PENDING");
        // In a real implementation, properties would be updated here
        
        when(taskInstanceService.getTaskInstance(taskId)).thenReturn(task);
        when(taskInstanceService.updateTaskInstance(any(TaskInstance.class))).thenReturn(updatedTask);
        
        // Execute
        TaskInstanceResponse response = taskManagementAPI.updateTaskProperties(taskId, properties);
        
        // Verify
        assertNotNull(response);
        assertEquals(taskId, response.getId());
        assertEquals("Test Task", response.getName());
        assertEquals("PENDING", response.getStatus());
        
        verify(taskInstanceService).getTaskInstance(taskId);
        verify(taskInstanceService).updateTaskInstance(any(TaskInstance.class));
    }
}
