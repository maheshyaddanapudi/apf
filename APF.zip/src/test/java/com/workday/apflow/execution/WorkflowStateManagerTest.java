package com.workday.apflow.execution;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.workday.apflow.constants.TaskConstants;
import com.workday.apflow.constants.WorkflowConstants;
import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.dao.WorkflowExecutionQueueDAO;
import com.workday.apflow.dao.WorkflowInstanceDAO;
import com.workday.apflow.dto.workflow.TaskSequenceItemDTO;
import com.workday.apflow.dto.workflow.WorkflowInstanceDTO;
import com.workday.apflow.handler.TaskGroupHandlerRegistry;
import com.workday.apflow.handler.TaskHandler;
import com.workday.apflow.handler.TaskHandlerRegistry;
import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.model.WorkflowInstance;
import com.workday.apflow.util.DtoConverter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.verifyNoMoreInteractions;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class WorkflowStateManagerTest {

    @Mock
    private WorkflowInstanceDAO workflowInstanceDAO;

    @Mock
    private TaskInstanceDAO taskInstanceDAO;

    @Mock
    private WorkflowExecutionQueueDAO queueDAO;

    @Mock
    private TaskHandlerRegistry taskHandlerRegistry;

    @Mock
    private TaskGroupHandlerRegistry taskGroupHandlerRegistry;

    @InjectMocks
    private WorkflowStateManager workflowStateManager;

    private WorkflowInstance workflow;
    private WorkflowInstanceDTO instanceDto;
    private String jsonString;
    private ObjectMapper objectMapper = new ObjectMapper();

    @BeforeEach
    public void setup() {
        workflow = new WorkflowInstance();
        workflow.setId(1);
        workflow.setStatus(WorkflowConstants.STATUS_RUNNING);
        workflow.setCreatedBy("testUser");

        instanceDto = new WorkflowInstanceDTO();
        instanceDto.setCurrentPosition(0);
        instanceDto.setSequence(new ArrayList<>());
    }

    @Test
    public void testProcessWorkflowInstance_WorkflowNotFound() {
        // Arrange
        Integer workflowInstanceId = 1;
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(null);
        
        // Act
        workflowStateManager.processWorkflowInstance(workflowInstanceId);
        
        // Assert
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verifyNoMoreInteractions(workflowInstanceDAO);
        verifyNoInteractions(taskInstanceDAO);
        verifyNoInteractions(taskHandlerRegistry);
        verifyNoInteractions(taskGroupHandlerRegistry);
    }
    
    @Test
    public void testProcessWorkflowInstance_WorkflowPaused() {
        // Arrange
        Integer workflowInstanceId = 1;
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_PAUSED);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        workflowStateManager.processWorkflowInstance(workflowInstanceId);
        
        // Assert
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verifyNoMoreInteractions(workflowInstanceDAO);
        verifyNoInteractions(taskInstanceDAO);
        verifyNoInteractions(taskHandlerRegistry);
        verifyNoInteractions(taskGroupHandlerRegistry);
    }
    
    @Test
    public void testProcessWorkflowInstance_WorkflowCompleted() {
        // Arrange
        Integer workflowInstanceId = 1;
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_COMPLETED);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        workflowStateManager.processWorkflowInstance(workflowInstanceId);
        
        // Assert
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verifyNoMoreInteractions(workflowInstanceDAO);
        verifyNoInteractions(taskInstanceDAO);
        verifyNoInteractions(taskHandlerRegistry);
        verifyNoInteractions(taskGroupHandlerRegistry);
    }
    
    @Test
    public void testProcessWorkflowInstance_WorkflowCancelled() {
        // Arrange
        Integer workflowInstanceId = 1;
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_CANCELLED);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        workflowStateManager.processWorkflowInstance(workflowInstanceId);
        
        // Assert
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verifyNoMoreInteractions(workflowInstanceDAO);
        verifyNoInteractions(taskInstanceDAO);
        verifyNoInteractions(taskHandlerRegistry);
        verifyNoInteractions(taskGroupHandlerRegistry);
    }
    
    @Test
    public void testProcessWorkflowInstance_WorkflowFailed() {
        // Arrange
        Integer workflowInstanceId = 1;
        WorkflowInstance workflow = new WorkflowInstance();
        workflow.setId(workflowInstanceId);
        workflow.setStatus(WorkflowConstants.STATUS_FAILED);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflowInstanceId)).thenReturn(workflow);
        
        // Act
        workflowStateManager.processWorkflowInstance(workflowInstanceId);
        
        // Assert
        verify(workflowInstanceDAO).getWorkflowInstance(workflowInstanceId);
        verifyNoMoreInteractions(workflowInstanceDAO);
        verifyNoInteractions(taskInstanceDAO);
        verifyNoInteractions(taskHandlerRegistry);
        verifyNoInteractions(taskGroupHandlerRegistry);
    }

    @Test
    public void testProcessWorkflowInstance_TaskSequenceItem_ExistingTask_Completed() {
        // Arrange
        instanceDto.setCurrentPosition(0);
        
        TaskSequenceItemDTO taskItem = new TaskSequenceItemDTO();
        taskItem.setId("task1");
        taskItem.setName("Test Task");
        taskItem.setTaskType("TODO");
        taskItem.setTaskInstanceId(1);
        instanceDto.getSequence().add(taskItem);
        
        jsonString = DtoConverter.toJson(instanceDto);
        workflow.setInstanceJson(jsonString);
        
        TaskInstance existingTask = new TaskInstance();
        existingTask.setId(1);
        existingTask.setStatus(TaskConstants.STATUS_COMPLETED);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflow.getId())).thenReturn(workflow);
        when(taskInstanceDAO.getTaskInstance(1)).thenReturn(existingTask);
        
        // Act
        workflowStateManager.processWorkflowInstance(workflow.getId());
        
        // Assert
        verify(workflowInstanceDAO).getWorkflowInstance(workflow.getId());
        verify(taskInstanceDAO).getTaskInstance(1);
        verify(workflowInstanceDAO).updateWorkflowInstance(workflow);
        
        // Verify current position was incremented
        WorkflowInstanceDTO updatedDto = WorkflowJsonParser.parseWorkflowInstance(workflow.getInstanceJson());
        assertEquals(1, updatedDto.getCurrentPosition());
    }

    @Test
    public void testProcessWorkflowInstance_TaskSequenceItem_ExistingTask_Failed() {
        // Arrange
        instanceDto.setCurrentPosition(0);
        
        TaskSequenceItemDTO taskItem = new TaskSequenceItemDTO();
        taskItem.setId("task1");
        taskItem.setName("Test Task");
        taskItem.setTaskType("TODO");
        taskItem.setTaskInstanceId(1);
        instanceDto.getSequence().add(taskItem);
        
        jsonString = DtoConverter.toJson(instanceDto);
        workflow.setInstanceJson(jsonString);
        
        TaskInstance existingTask = new TaskInstance();
        existingTask.setId(1);
        existingTask.setStatus(TaskConstants.STATUS_FAILED);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflow.getId())).thenReturn(workflow);
        when(taskInstanceDAO.getTaskInstance(1)).thenReturn(existingTask);
        
        // Act
        workflowStateManager.processWorkflowInstance(workflow.getId());
        
        // Assert
        verify(workflowInstanceDAO).getWorkflowInstance(workflow.getId());
        verify(taskInstanceDAO).getTaskInstance(1);
        verify(workflowInstanceDAO).updateWorkflowInstance(workflow);
        
        // Verify current position was incremented
        WorkflowInstanceDTO updatedDto = WorkflowJsonParser.parseWorkflowInstance(workflow.getInstanceJson());
        assertEquals(1, updatedDto.getCurrentPosition());
    }

    @Test
    public void testProcessWorkflowInstance_TaskSequenceItem_ExistingTask_Terminated() {
        // Arrange
        instanceDto.setCurrentPosition(0);
        
        TaskSequenceItemDTO taskItem = new TaskSequenceItemDTO();
        taskItem.setId("task1");
        taskItem.setName("Test Task");
        taskItem.setTaskType("TODO");
        taskItem.setTaskInstanceId(1);
        instanceDto.getSequence().add(taskItem);
        
        jsonString = DtoConverter.toJson(instanceDto);
        workflow.setInstanceJson(jsonString);
        
        TaskInstance existingTask = new TaskInstance();
        existingTask.setId(1);
        existingTask.setStatus(TaskConstants.STATUS_TERMINATED);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflow.getId())).thenReturn(workflow);
        when(taskInstanceDAO.getTaskInstance(1)).thenReturn(existingTask);
        
        // Act
        workflowStateManager.processWorkflowInstance(workflow.getId());
        
        // Assert
        verify(workflowInstanceDAO).getWorkflowInstance(workflow.getId());
        verify(taskInstanceDAO).getTaskInstance(1);
        verify(workflowInstanceDAO).updateWorkflowInstance(workflow);
        
        // Verify current position was incremented
        WorkflowInstanceDTO updatedDto = WorkflowJsonParser.parseWorkflowInstance(workflow.getInstanceJson());
        assertEquals(1, updatedDto.getCurrentPosition());
    }

    @Test
    public void testProcessWorkflowInstance_TaskSequenceItem_ExistingTask_Pending() {
        // Arrange
        instanceDto.setCurrentPosition(0);
        
        TaskSequenceItemDTO taskItem = new TaskSequenceItemDTO();
        taskItem.setId("task1");
        taskItem.setName("Test Task");
        taskItem.setTaskType("TODO");
        taskItem.setTaskInstanceId(1);
        instanceDto.getSequence().add(taskItem);
        
        jsonString = DtoConverter.toJson(instanceDto);
        workflow.setInstanceJson(jsonString);
        
        TaskInstance existingTask = new TaskInstance();
        existingTask.setId(1);
        existingTask.setType("TODO");
        existingTask.setStatus(TaskConstants.STATUS_PENDING);
        
        TaskHandler taskHandler = mock(TaskHandler.class);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflow.getId())).thenReturn(workflow);
        when(taskInstanceDAO.getTaskInstance(1)).thenReturn(existingTask);
        when(taskHandlerRegistry.getHandler("TODO")).thenReturn(taskHandler);
        
        // Act
        workflowStateManager.processWorkflowInstance(workflow.getId());
        
        // Assert
        verify(workflowInstanceDAO).getWorkflowInstance(workflow.getId());
        verify(taskInstanceDAO).getTaskInstance(1);
        verify(taskHandlerRegistry).getHandler("TODO");
        verify(taskHandler).execute(existingTask);
        
        // Verify current position was not incremented
        WorkflowInstanceDTO updatedDto = WorkflowJsonParser.parseWorkflowInstance(workflow.getInstanceJson());
        assertEquals(0, updatedDto.getCurrentPosition());
    }

    @Test
    public void testProcessWorkflowInstance_TaskSequenceItem_ExistingTask_Pending_HandlerNotFound() {
        // Arrange
        instanceDto.setCurrentPosition(0);
        
        TaskSequenceItemDTO taskItem = new TaskSequenceItemDTO();
        taskItem.setId("task1");
        taskItem.setName("Test Task");
        taskItem.setTaskType("UNKNOWN_TYPE");
        taskItem.setTaskInstanceId(1);
        instanceDto.getSequence().add(taskItem);
        
        jsonString = DtoConverter.toJson(instanceDto);
        workflow.setInstanceJson(jsonString);
        
        TaskInstance existingTask = new TaskInstance();
        existingTask.setId(1);
        existingTask.setType("UNKNOWN_TYPE");
        existingTask.setStatus(TaskConstants.STATUS_PENDING);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflow.getId())).thenReturn(workflow);
        when(taskInstanceDAO.getTaskInstance(1)).thenReturn(existingTask);
        when(taskHandlerRegistry.getHandler("UNKNOWN_TYPE")).thenReturn(null);
        
        // Act
        workflowStateManager.processWorkflowInstance(workflow.getId());
        
        // Assert
        verify(workflowInstanceDAO).getWorkflowInstance(workflow.getId());
        verify(taskInstanceDAO).getTaskInstance(1);
        verify(taskHandlerRegistry).getHandler("UNKNOWN_TYPE");
        
        // Verify current position was not incremented
        WorkflowInstanceDTO updatedDto = WorkflowJsonParser.parseWorkflowInstance(workflow.getInstanceJson());
        assertEquals(0, updatedDto.getCurrentPosition());
    }

    @Test
    public void testProcessWorkflowInstance_TaskSequenceItem_NewTask() {
        // Arrange
        instanceDto.setCurrentPosition(0);
        
        TaskSequenceItemDTO taskItem = new TaskSequenceItemDTO();
        taskItem.setId("task1");
        taskItem.setName("Test Task");
        taskItem.setTaskType("TODO");
        taskItem.setAssignment("testUser");
        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("key", "value");
        taskItem.setInputJson(inputJson);
        instanceDto.getSequence().add(taskItem);
        
        jsonString = DtoConverter.toJson(instanceDto);
        workflow.setInstanceJson(jsonString);
        
        TaskHandler taskHandler = mock(TaskHandler.class);
        
        when(workflowInstanceDAO.getWorkflowInstance(workflow.getId())).thenReturn(workflow);
        when(taskHandlerRegistry.getHandler("TODO")).thenReturn(taskHandler);
        when(taskInstanceDAO.createTaskInstance(any(TaskInstance.class))).thenAnswer(invocation -> {
            TaskInstance task = invocation.getArgument(0);
            task.setId(1);
            return task;
        });
        
        // Act
        workflowStateManager.processWorkflowInstance(workflow.getId());
        
        // Assert
        verify(workflowInstanceDAO).getWorkflowInstance(workflow.getId());
        verify(taskHandlerRegistry).getHandler("TODO");
        
        ArgumentCaptor<TaskInstance> taskCaptor = ArgumentCaptor.forClass(TaskInstance.class);
        verify(taskInstanceDAO).createTaskInstance(taskCaptor.capture());
        verify(taskHandler).execute(any(TaskInstance.class));
        
        TaskInstance capturedTask = taskCaptor.getValue();
        assertEquals(workflow.getId(), capturedTask.getWorkflowInstanceId());
        assertEquals("Test Task", capturedTask.getName());
        assertEquals("TODO", capturedTask.getType());
        assertEquals(TaskConstants.STATUS_PENDING, capturedTask.getStatus());
        assertEquals("testUser", capturedTask.getAssignment());
        assertEquals("testUser", capturedTask.getCreatedBy());
        assertNotNull(capturedTask.getCreatedAt());
        assertEquals(inputJson, capturedTask.getInputMap());
    }
}
