package com.workday.apflow.execution;

import com.workday.apflow.constants.QueueConstants;
import com.workday.apflow.dao.WorkflowExecutionQueueDAO;
import com.workday.apflow.model.WorkflowExecutionQueue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class WorkflowExecutionSweeperTest {

    @Mock
    private WorkflowExecutionQueueDAO queueDAO;
    
    @Mock
    private WorkflowStateManager stateManager;
    
    private WorkflowExecutionSweeper sweeper;
    
    @BeforeEach
    public void setUp() {
        sweeper = new WorkflowExecutionSweeper(queueDAO, stateManager);
    }
    
    @Test
    public void testProcessQueueEntries_FirstSweep() {
        // Arrange
        int batchSize = 10;
        List<WorkflowExecutionQueue> mixedEntries = new ArrayList<>();
        
        WorkflowExecutionQueue pendingEntry = new WorkflowExecutionQueue();
        pendingEntry.setId(1);
        pendingEntry.setWorkflowInstanceId(101);
        pendingEntry.setStatus(QueueConstants.STATUS_PENDING);
        mixedEntries.add(pendingEntry);
        
        WorkflowExecutionQueue processingEntry = new WorkflowExecutionQueue();
        processingEntry.setId(2);
        processingEntry.setWorkflowInstanceId(102);
        processingEntry.setStatus(QueueConstants.STATUS_PROCESSING);
        mixedEntries.add(processingEntry);
        
        WorkflowExecutionQueue failedEntry = new WorkflowExecutionQueue();
        failedEntry.setId(3);
        failedEntry.setWorkflowInstanceId(103);
        failedEntry.setStatus(QueueConstants.STATUS_FAILED);
        mixedEntries.add(failedEntry);
        
        when(queueDAO.getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize)).thenReturn(mixedEntries);
        
        // Act
        sweeper.processQueueEntries(batchSize);
        
        // Assert
        verify(queueDAO).getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize);
        verify(stateManager).processWorkflowInstance(eq(101), eq(pendingEntry));
        verify(stateManager).processWorkflowInstance(eq(102), eq(processingEntry));
        verify(stateManager).processWorkflowInstance(eq(103), eq(failedEntry));
    }
    
    @Test
    public void testProcessQueueEntries_SubsequentSweep() {
        // Arrange
        int batchSize = 10;
        List<WorkflowExecutionQueue> failedEntries = new ArrayList<>();
        
        WorkflowExecutionQueue failedEntry = new WorkflowExecutionQueue();
        failedEntry.setId(3);
        failedEntry.setWorkflowInstanceId(103);
        failedEntry.setStatus(QueueConstants.STATUS_FAILED);
        failedEntries.add(failedEntry);
        
        // First call for mixed statuses (first sweep)
        when(queueDAO.getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize)).thenReturn(new ArrayList<>());
        
        // Second call for failed only (subsequent sweep)
        when(queueDAO.getQueueEntriesByStatus(QueueConstants.STATUS_FAILED, batchSize))
            .thenReturn(failedEntries);
        
        // Act - first sweep (will be empty)
        sweeper.processQueueEntries(batchSize);
        
        // Act - second sweep (should process failed entries)
        sweeper.processQueueEntries(batchSize);
        
        // Assert
        verify(queueDAO).getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize);
        verify(queueDAO).getQueueEntriesByStatus(QueueConstants.STATUS_FAILED, batchSize);
        verify(stateManager).processWorkflowInstance(eq(103), eq(failedEntry));
    }
    
    @Test
    public void testProcessQueueEntries_ProcessingFailure() {
        // Arrange
        int batchSize = 10;
        List<WorkflowExecutionQueue> entries = new ArrayList<>();
        
        WorkflowExecutionQueue entry = new WorkflowExecutionQueue();
        entry.setId(1);
        entry.setWorkflowInstanceId(101);
        entry.setStatus(QueueConstants.STATUS_PENDING);
        entries.add(entry);
        
        when(queueDAO.getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize)).thenReturn(entries);
        doThrow(new RuntimeException("Processing failed"))
            .when(stateManager).processWorkflowInstance(eq(101), eq(entry));
        
        // Act
        sweeper.processQueueEntries(batchSize);
        
        // Assert
        verify(queueDAO).getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize);
        verify(stateManager).processWorkflowInstance(eq(101), eq(entry));
    }
    
    @Test
    public void testProcessQueueEntries_DAOFailure() {
        // Arrange
        int batchSize = 10;
        
        when(queueDAO.getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize)).thenThrow(new RuntimeException("DAO failure"));
        
        // Act
        sweeper.processQueueEntries(batchSize);
        
        // Assert
        verify(queueDAO).getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize);
        verifyNoInteractions(stateManager);
    }
    
    @Test
    public void testProcessQueueEntries_EmptyQueue() {
        // Arrange
        int batchSize = 10;
        List<WorkflowExecutionQueue> emptyList = new ArrayList<>();
        
        when(queueDAO.getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize)).thenReturn(emptyList);
        
        // Act
        sweeper.processQueueEntries(batchSize);
        
        // Assert
        verify(queueDAO).getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize);
        verifyNoInteractions(stateManager);
    }
    
    @Test
    public void testProcessPendingQueueEntries_BackwardCompatibility() {
        // Arrange
        int batchSize = 10;
        List<WorkflowExecutionQueue> mixedEntries = new ArrayList<>();
        
        WorkflowExecutionQueue pendingEntry = new WorkflowExecutionQueue();
        pendingEntry.setId(1);
        pendingEntry.setWorkflowInstanceId(101);
        pendingEntry.setStatus(QueueConstants.STATUS_PENDING);
        mixedEntries.add(pendingEntry);
        
        when(queueDAO.getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize)).thenReturn(mixedEntries);
        
        // Act - should call processQueueEntries internally
        sweeper.processPendingQueueEntries(batchSize);
        
        // Assert
        verify(queueDAO).getQueueEntriesByStatuses(
            List.of(QueueConstants.STATUS_PENDING, QueueConstants.STATUS_PROCESSING, QueueConstants.STATUS_FAILED),
            batchSize);
        verify(stateManager).processWorkflowInstance(eq(101), eq(pendingEntry));
    }
}
