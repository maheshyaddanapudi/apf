package com.workday.apflow.dto;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

public class UserGroupDTOTest {

    @Test
    public void testDefaultConstructor() {
        UserGroupDTO userGroupDTO = new UserGroupDTO();
        
        assertNotNull(userGroupDTO);
        assertNull(userGroupDTO.getId());
        assertNull(userGroupDTO.getName());
        assertNull(userGroupDTO.getDescription());
        assertNull(userGroupDTO.getMembers());
    }
    
    @Test
    public void testParameterizedConstructor() {
        UUID id = UUID.randomUUID();
        String name = "Engineering Team";
        
        UserGroupDTO userGroupDTO = new UserGroupDTO(id, name);
        
        assertEquals(id, userGroupDTO.getId());
        assertEquals(name, userGroupDTO.getName());
        assertNull(userGroupDTO.getDescription());
        assertNull(userGroupDTO.getMembers());
    }
    
    @Test
    public void testSettersAndGetters() {
        UserGroupDTO userGroupDTO = new UserGroupDTO();
        
        UUID id = UUID.randomUUID();
        String name = "Engineering Team";
        String description = "Team responsible for product engineering";
        List<UserDTO> members = new ArrayList<>();
        UserDTO user = new UserDTO();
        user.setId(UUID.randomUUID());
        user.setUsername("johndoe");
        user.setDisplayName("John Doe");
        members.add(user);
        
        userGroupDTO.setId(id);
        userGroupDTO.setName(name);
        userGroupDTO.setDescription(description);
        userGroupDTO.setMembers(members);
        
        assertEquals(id, userGroupDTO.getId());
        assertEquals(name, userGroupDTO.getName());
        assertEquals(description, userGroupDTO.getDescription());
        assertEquals(members, userGroupDTO.getMembers());
        assertEquals(1, userGroupDTO.getMembers().size());
    }
    
    @Test
    public void testAddMember() {
        UserGroupDTO userGroupDTO = new UserGroupDTO();
        
        List<UserDTO> members = new ArrayList<>();
        userGroupDTO.setMembers(members);
        
        UserDTO user1 = new UserDTO();
        user1.setId(UUID.randomUUID());
        user1.setUsername("johndoe");
        user1.setDisplayName("John Doe");
        
        UserDTO user2 = new UserDTO();
        user2.setId(UUID.randomUUID());
        user2.setUsername("janedoe");
        user2.setDisplayName("Jane Doe");
        
        userGroupDTO.addMember(user1);
        userGroupDTO.addMember(user2);
        
        assertEquals(2, userGroupDTO.getMembers().size());
        assertTrue(userGroupDTO.getMembers().contains(user1));
        assertTrue(userGroupDTO.getMembers().contains(user2));
    }
    
    @Test
    public void testContainsUser() {
        UserGroupDTO userGroupDTO = new UserGroupDTO();
        
        List<UserDTO> members = new ArrayList<>();
        UUID userId1 = UUID.randomUUID();
        UUID userId2 = UUID.randomUUID();
        
        UserDTO user1 = new UserDTO();
        user1.setId(userId1);
        user1.setUsername("johndoe");
        
        UserDTO user2 = new UserDTO();
        user2.setId(userId2);
        user2.setUsername("janedoe");
        
        members.add(user1);
        members.add(user2);
        
        userGroupDTO.setMembers(members);
        
        assertTrue(userGroupDTO.containsUser(userId1));
        assertTrue(userGroupDTO.containsUser(userId2));
        assertFalse(userGroupDTO.containsUser(UUID.randomUUID()));
    }
    
    @Test
    public void testContainsUserWithNullMembers() {
        UserGroupDTO userGroupDTO = new UserGroupDTO();
        
        // Members is null by default
        assertFalse(userGroupDTO.containsUser(UUID.randomUUID()));
    }
    
    @Test
    public void testEqualsAndHashCode() {
        UUID id1 = UUID.fromString("00000000-0000-0000-0000-000000000001");
        UUID id2 = UUID.fromString("00000000-0000-0000-0000-000000000002");
        
        UserGroupDTO userGroupDTO1 = new UserGroupDTO(id1, "Engineering Team");
        UserGroupDTO userGroupDTO2 = new UserGroupDTO(id1, "Engineering Team");
        UserGroupDTO userGroupDTO3 = new UserGroupDTO(id2, "Marketing Team");
        
        // Test reflexivity
        assertEquals(userGroupDTO1, userGroupDTO1);
        
        // Test symmetry
        assertEquals(userGroupDTO1, userGroupDTO2);
        assertEquals(userGroupDTO2, userGroupDTO1);
        
        // Test transitivity
        assertNotEquals(userGroupDTO1, userGroupDTO3);
        assertNotEquals(userGroupDTO2, userGroupDTO3);
        
        // Test null and different class
        assertNotEquals(userGroupDTO1, null);
        assertNotEquals(userGroupDTO1, new Object());
        
        // Test hashCode
        assertEquals(userGroupDTO1.hashCode(), userGroupDTO1.hashCode());
        assertEquals(userGroupDTO1.hashCode(), userGroupDTO2.hashCode());
        assertNotEquals(userGroupDTO1.hashCode(), userGroupDTO3.hashCode());
    }
}
