package com.workday.apflow.dto.response;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class MetricsResponseTest {

    @Test
    void testDefaultConstructor() {
        // Execute
        MetricsResponse response = new MetricsResponse();
        
        // Verify
        assertNull(response.getWorkflowInstanceId());
        assertNotNull(response.getMetrics());
        assertTrue(response.getMetrics().isEmpty());
    }
    
    @Test
    void testConstructorWithWorkflowInstanceId() {
        // Execute
        MetricsResponse response = new MetricsResponse(100);
        
        // Verify
        assertEquals(100, response.getWorkflowInstanceId());
        assertNotNull(response.getMetrics());
        assertTrue(response.getMetrics().isEmpty());
    }
    
    @Test
    void testGettersAndSetters() {
        // Setup
        MetricsResponse response = new MetricsResponse();
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("executionTime", 1500);
        metrics.put("taskCount", 5);
        
        // Execute
        response.setWorkflowInstanceId(100);
        response.setMetrics(metrics);
        
        // Verify
        assertEquals(100, response.getWorkflowInstanceId());
        assertNotNull(response.getMetrics());
        assertEquals(2, response.getMetrics().size());
        assertEquals(1500, response.getMetrics().get("executionTime"));
        assertEquals(5, response.getMetrics().get("taskCount"));
    }
    
    @Test
    void testSetMetricsWithNull() {
        // Setup
        MetricsResponse response = new MetricsResponse();
        
        // Execute
        response.setMetrics(null);
        
        // Verify
        assertNotNull(response.getMetrics());
        assertTrue(response.getMetrics().isEmpty());
    }
    
    @Test
    void testAddMetric() {
        // Setup
        MetricsResponse response = new MetricsResponse();
        
        // Execute
        response.addMetric("executionTime", 1500);
        response.addMetric("taskCount", 5);
        response.addMetric("status", "COMPLETED");
        
        // Verify
        assertNotNull(response.getMetrics());
        assertEquals(3, response.getMetrics().size());
        assertEquals(1500, response.getMetrics().get("executionTime"));
        assertEquals(5, response.getMetrics().get("taskCount"));
        assertEquals("COMPLETED", response.getMetrics().get("status"));
    }
    
    @Test
    void testAddMetricWithNullMetrics() {
        // Setup
        MetricsResponse response = new MetricsResponse();
        // Force metrics to null using reflection
        try {
            java.lang.reflect.Field field = MetricsResponse.class.getDeclaredField("metrics");
            field.setAccessible(true);
            field.set(response, null);
        } catch (Exception e) {
            fail("Failed to set metrics to null: " + e.getMessage());
        }
        
        // Execute
        response.addMetric("executionTime", 1500);
        
        // Verify
        assertNotNull(response.getMetrics());
        assertEquals(1, response.getMetrics().size());
        assertEquals(1500, response.getMetrics().get("executionTime"));
    }
    
    @Test
    void testAddMetricWithNullKeyOrValue() {
        // Setup
        MetricsResponse response = new MetricsResponse();
        
        // Execute
        response.addMetric(null, 1500);
        response.addMetric("nullValue", null);
        
        // Verify
        assertNotNull(response.getMetrics());
        assertEquals(2, response.getMetrics().size());
        assertEquals(1500, response.getMetrics().get(null));
        assertNull(response.getMetrics().get("nullValue"));
    }
}
