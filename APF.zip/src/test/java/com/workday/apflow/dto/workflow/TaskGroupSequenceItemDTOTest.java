package com.workday.apflow.dto.workflow;

import com.workday.apflow.constants.WorkflowConstants;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class TaskGroupSequenceItemDTOTest {

    @Test
    void testDefaultConstructor() {
        // Execute
        TaskGroupSequenceItemDTO sequenceItem = new TaskGroupSequenceItemDTO();
        
        // Verify
        assertNotNull(sequenceItem);
        assertEquals(WorkflowConstants.TYPE_TASK_GROUP, sequenceItem.getType());
        assertNull(sequenceItem.getTaskGroupType());
        assertNull(sequenceItem.getTaskGroupInstanceId());
        assertNull(sequenceItem.getInputJson());
    }
    
    @Test
    void testSettersAndGetters() {
        // Setup
        String id = "tg-seq-123";
        String name = "Test Task Group Sequence Item";
        String taskGroupType = "HORIZONTAL";
        Integer taskGroupInstanceId = 123;
        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("key1", "value1");
        
        // Execute
        TaskGroupSequenceItemDTO sequenceItem = new TaskGroupSequenceItemDTO();
        sequenceItem.setId(id);
        sequenceItem.setName(name);
        sequenceItem.setTaskGroupType(taskGroupType);
        sequenceItem.setTaskGroupInstanceId(taskGroupInstanceId);
        sequenceItem.setInputJson(inputJson);
        
        // Verify
        assertEquals(id, sequenceItem.getId());
        assertEquals(name, sequenceItem.getName());
        assertEquals(WorkflowConstants.TYPE_TASK_GROUP, sequenceItem.getType());
        assertEquals(taskGroupType, sequenceItem.getTaskGroupType());
        assertEquals(taskGroupInstanceId, sequenceItem.getTaskGroupInstanceId());
        assertEquals(inputJson, sequenceItem.getInputJson());
    }
    
    @Test
    void testEqualsAndHashCode() {
        // Setup
        TaskGroupSequenceItemDTO item1 = new TaskGroupSequenceItemDTO();
        item1.setId("tg-seq-123");
        item1.setTaskGroupType("HORIZONTAL");
        item1.setTaskGroupInstanceId(123);
        
        TaskGroupSequenceItemDTO item2 = new TaskGroupSequenceItemDTO();
        item2.setId("tg-seq-123");
        item2.setTaskGroupType("HORIZONTAL");
        item2.setTaskGroupInstanceId(123);
        
        TaskGroupSequenceItemDTO item3 = new TaskGroupSequenceItemDTO();
        item3.setId("tg-seq-456");
        item3.setTaskGroupType("VERTICAL");
        item3.setTaskGroupInstanceId(456);
        
        // Verify
        assertTrue(item1.equals(item2));
        assertFalse(item1.equals(item3));
        assertEquals(item1.hashCode(), item2.hashCode());
        assertNotEquals(item1.hashCode(), item3.hashCode());
    }
    
    @Test
    void testEqualsWithNull() {
        // Setup
        TaskGroupSequenceItemDTO item = new TaskGroupSequenceItemDTO();
        item.setId("tg-seq-123");
        
        // Verify
        assertFalse(item.equals(null));
    }
    
    @Test
    void testEqualsWithDifferentClass() {
        // Setup
        TaskGroupSequenceItemDTO item = new TaskGroupSequenceItemDTO();
        item.setId("tg-seq-123");
        String string = "tg-seq-123";
        
        // Verify
        assertFalse(item.equals(string));
    }
    
    @Test
    void testEqualsSameObject() {
        // Setup
        TaskGroupSequenceItemDTO item = new TaskGroupSequenceItemDTO();
        item.setId("tg-seq-123");
        
        // Verify
        assertTrue(item.equals(item));
    }
    
    @Test
    void testToString() {
        // Setup
        TaskGroupSequenceItemDTO item = new TaskGroupSequenceItemDTO();
        item.setId("tg-seq-123");
        item.setType("TASK_GROUP");
        item.setTaskGroupType("HORIZONTAL");
        item.setTaskGroupInstanceId(123);
        
        // Execute
        String result = item.toString();
        
        // Verify
        assertNotNull(result);
        assertTrue(result.contains("tg-seq-123"));
        assertTrue(result.contains("TASK_GROUP"));
        assertTrue(result.contains("HORIZONTAL"));
        assertTrue(result.contains("123"));
    }
    
    @Test
    void testInheritanceFromSequenceItemDTO() {
        // Setup
        TaskGroupSequenceItemDTO item = new TaskGroupSequenceItemDTO();
        item.setId("tg-seq-123");
        item.setType("TASK_GROUP");
        
        // Verify
        assertTrue(item instanceof SequenceItemDTO);
        assertEquals("tg-seq-123", ((SequenceItemDTO)item).getId());
        assertEquals("TASK_GROUP", ((SequenceItemDTO)item).getType());
    }
    
    @Test
    void testAddInputParameter() {
        // Setup
        TaskGroupSequenceItemDTO item = new TaskGroupSequenceItemDTO();
        
        // Execute
        item.addInputParameter("key1", "value1");
        item.addInputParameter("key2", 123);
        
        // Verify
        assertNotNull(item.getInputJson());
        assertEquals(2, item.getInputJson().size());
        assertEquals("value1", item.getInputJson().get("key1"));
        assertEquals(123, item.getInputJson().get("key2"));
    }
    
    @Test
    void testAddInputParameterToExistingMap() {
        // Setup
        TaskGroupSequenceItemDTO item = new TaskGroupSequenceItemDTO();
        Map<String, Object> inputJson = new HashMap<>();
        inputJson.put("key1", "value1");
        item.setInputJson(inputJson);
        
        // Execute
        item.addInputParameter("key2", 123);
        
        // Verify
        assertNotNull(item.getInputJson());
        assertEquals(2, item.getInputJson().size());
        assertEquals("value1", item.getInputJson().get("key1"));
        assertEquals(123, item.getInputJson().get("key2"));
    }
    
    @Test
    void testNullInputJson() {
        // Setup
        TaskGroupSequenceItemDTO item = new TaskGroupSequenceItemDTO();
        
        // Execute
        item.setInputJson(null);
        
        // Verify
        assertNull(item.getInputJson());
    }
    
    @Test
    void testEmptyInputJson() {
        // Setup
        TaskGroupSequenceItemDTO item = new TaskGroupSequenceItemDTO();
        Map<String, Object> emptyInputJson = new HashMap<>();
        
        // Execute
        item.setInputJson(emptyInputJson);
        
        // Verify
        assertNotNull(item.getInputJson());
        assertTrue(item.getInputJson().isEmpty());
    }
}
