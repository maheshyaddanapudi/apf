package com.workday.apflow.dto;

import com.workday.apflow.enums.WorkflowStatus;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

public class WorkflowQueryDTOTest {

    @Test
    public void testDefaultConstructor() {
        WorkflowQueryDTO queryDTO = new WorkflowQueryDTO();
        
        assertNotNull(queryDTO);
        assertNull(queryDTO.getWorkflowDefId());
        assertNull(queryDTO.getStatus());
        assertNull(queryDTO.getNameContains());
        assertNull(queryDTO.getStartedAfter());
        assertNull(queryDTO.getStartedBefore());
        assertNull(queryDTO.getCompletedAfter());
        assertNull(queryDTO.getCompletedBefore());
        assertNull(queryDTO.getAssignee());
        assertEquals(100, queryDTO.getLimit());
        assertEquals(0, queryDTO.getOffset());
        assertEquals("created_at", queryDTO.getSortBy());
        assertFalse(queryDTO.isAscending());
    }
    
    @Test
    public void testBuilderMethods() {
        UUID workflowDefId = UUID.randomUUID();
        WorkflowStatus status = WorkflowStatus.RUNNING;
        String nameContains = "test";
        LocalDateTime startedAfter = LocalDateTime.now().minusDays(7);
        LocalDateTime startedBefore = LocalDateTime.now();
        LocalDateTime completedAfter = LocalDateTime.now().minusDays(3);
        LocalDateTime completedBefore = LocalDateTime.now();
        String assignee = "user1";
        int limit = 50;
        int offset = 10;
        String sortBy = "name";
        boolean ascending = true;
        
        WorkflowQueryDTO queryDTO = new WorkflowQueryDTO()
                .withWorkflowDefId(workflowDefId)
                .withStatus(status)
                .withNameContains(nameContains)
                .withStartedAfter(startedAfter)
                .withStartedBefore(startedBefore)
                .withCompletedAfter(completedAfter)
                .withCompletedBefore(completedBefore)
                .withAssignee(assignee)
                .withLimit(limit)
                .withOffset(offset)
                .withSortBy(sortBy)
                .withAscending(ascending);
        
        assertEquals(workflowDefId, queryDTO.getWorkflowDefId());
        assertEquals(status, queryDTO.getStatus());
        assertEquals(nameContains, queryDTO.getNameContains());
        assertEquals(startedAfter, queryDTO.getStartedAfter());
        assertEquals(startedBefore, queryDTO.getStartedBefore());
        assertEquals(completedAfter, queryDTO.getCompletedAfter());
        assertEquals(completedBefore, queryDTO.getCompletedBefore());
        assertEquals(assignee, queryDTO.getAssignee());
        assertEquals(limit, queryDTO.getLimit());
        assertEquals(offset, queryDTO.getOffset());
        assertEquals(sortBy, queryDTO.getSortBy());
        assertEquals(ascending, queryDTO.isAscending());
    }
    
    @Test
    public void testLimitConstraints() {
        // Test minimum limit
        WorkflowQueryDTO queryDTO1 = new WorkflowQueryDTO().withLimit(0);
        assertEquals(1, queryDTO1.getLimit()); // Should be constrained to minimum 1
        
        // Test maximum limit
        WorkflowQueryDTO queryDTO2 = new WorkflowQueryDTO().withLimit(2000);
        assertEquals(1000, queryDTO2.getLimit()); // Should be constrained to maximum 1000
        
        // Test valid limit
        WorkflowQueryDTO queryDTO3 = new WorkflowQueryDTO().withLimit(500);
        assertEquals(500, queryDTO3.getLimit());
    }
    
    @Test
    public void testOffsetConstraints() {
        // Test minimum offset
        WorkflowQueryDTO queryDTO1 = new WorkflowQueryDTO().withOffset(-10);
        assertEquals(0, queryDTO1.getOffset()); // Should be constrained to minimum 0
        
        // Test valid offset
        WorkflowQueryDTO queryDTO2 = new WorkflowQueryDTO().withOffset(100);
        assertEquals(100, queryDTO2.getOffset());
    }
    
    @Test
    public void testToSqlWhereClause() {
        // Test with no conditions
        WorkflowQueryDTO emptyQuery = new WorkflowQueryDTO();
        assertEquals("", emptyQuery.toSqlWhereClause());
        
        // Test with one condition
        WorkflowQueryDTO statusQuery = new WorkflowQueryDTO()
                .withStatus(WorkflowStatus.COMPLETED);
        assertEquals("WHERE status = 'COMPLETED'", statusQuery.toSqlWhereClause());
        
        // Test with multiple conditions
        UUID workflowDefId = UUID.fromString("00000000-0000-0000-0000-000000000001");
        WorkflowQueryDTO multiQuery = new WorkflowQueryDTO()
                .withWorkflowDefId(workflowDefId)
                .withStatus(WorkflowStatus.RUNNING)
                .withNameContains("test");
        String whereClause = multiQuery.toSqlWhereClause();
        assertTrue(whereClause.startsWith("WHERE "));
        assertTrue(whereClause.contains("workflow_def_id = '" + workflowDefId + "'"));
        assertTrue(whereClause.contains("status = 'RUNNING'"));
        assertTrue(whereClause.contains("name LIKE '%test%'"));
        assertTrue(whereClause.contains(" AND "));
    }
    
    @Test
    public void testToSqlOrderByClause() {
        // Test default
        WorkflowQueryDTO defaultQuery = new WorkflowQueryDTO();
        assertEquals("ORDER BY created_at DESC", defaultQuery.toSqlOrderByClause());
        
        // Test custom
        WorkflowQueryDTO customQuery = new WorkflowQueryDTO()
                .withSortBy("name")
                .withAscending(true);
        assertEquals("ORDER BY name ASC", customQuery.toSqlOrderByClause());
    }
    
    @Test
    public void testToSqlLimitOffsetClause() {
        // Test default
        WorkflowQueryDTO defaultQuery = new WorkflowQueryDTO();
        assertEquals("LIMIT 100 OFFSET 0", defaultQuery.toSqlLimitOffsetClause());
        
        // Test custom
        WorkflowQueryDTO customQuery = new WorkflowQueryDTO()
                .withLimit(50)
                .withOffset(10);
        assertEquals("LIMIT 50 OFFSET 10", customQuery.toSqlLimitOffsetClause());
    }
}
