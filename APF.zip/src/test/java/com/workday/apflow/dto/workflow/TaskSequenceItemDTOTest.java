package com.workday.apflow.dto.workflow;

import com.workday.apflow.constants.DtoConstants;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class TaskSequenceItemDTOTest {

    @Test
    void testDefaultConstructor() {
        TaskSequenceItemDTO dto = new TaskSequenceItemDTO();
        assertNotNull(dto);
        assertEquals(DtoConstants.TYPE_TASK, dto.getType());
        assertNull(dto.getId());
        assertNull(dto.getTaskId());
    }

    @Test
    void testGettersAndSetters() {
        TaskSequenceItemDTO dto = new TaskSequenceItemDTO();
        
        // Test id
        String id = "task123";
        dto.setId(id);
        assertEquals(id, dto.getId());
        
        // Test taskId
        Integer taskId = 456;
        dto.setTaskId(taskId);
        assertEquals(taskId, dto.getTaskId());
    }

    @Test
    void testTypeIsAlwaysTask() {
        TaskSequenceItemDTO dto = new TaskSequenceItemDTO();
        assertEquals(DtoConstants.TYPE_TASK, dto.getType());
        
        // Try to set a different type (should be ignored or overridden)
        dto.setType("something_else");
        assertEquals(DtoConstants.TYPE_TASK, dto.getType());
    }

    @Test
    void testEqualsAndHashCode() {
        TaskSequenceItemDTO dto1 = new TaskSequenceItemDTO();
        dto1.setId("task123");
        dto1.setTaskId(456);
        
        TaskSequenceItemDTO dto2 = new TaskSequenceItemDTO();
        dto2.setId("task123");
        dto2.setTaskId(456);
        
        TaskSequenceItemDTO dto3 = new TaskSequenceItemDTO();
        dto3.setId("task789");
        dto3.setTaskId(456);
        
        // Test equals
        assertEquals(dto1, dto1); // Same object
        assertEquals(dto1, dto2); // Equal objects
        assertNotEquals(dto1, dto3); // Different id
        assertNotEquals(dto1, null); // Null
        assertNotEquals(dto1, new Object()); // Different class
        
        // Test hashCode
        assertEquals(dto1.hashCode(), dto2.hashCode());
        assertNotEquals(dto1.hashCode(), dto3.hashCode());
    }

    @Test
    void testToString() {
        TaskSequenceItemDTO dto = new TaskSequenceItemDTO();
        dto.setId("task123");
        dto.setTaskId(456);
        
        String toString = dto.toString();
        assertNotNull(toString);
        assertTrue(toString.contains("task123"));
        assertTrue(toString.contains("456"));
        assertTrue(toString.contains(DtoConstants.TYPE_TASK));
    }
}
