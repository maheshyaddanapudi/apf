package com.workday.apflow.dto.response;

import com.workday.apflow.model.WorkflowHistory;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.time.Instant;

import static org.junit.jupiter.api.Assertions.*;

class WorkflowHistoryResponseTest {

    @Test
    void testDefaultConstructor() {
        // Execute
        WorkflowHistoryResponse response = new WorkflowHistoryResponse();
        
        // Verify
        assertNull(response.getId());
        assertNull(response.getWorkflowInstanceId());
        assertNull(response.getTaskInstanceId());
        assertNull(response.getEventType());
        assertNull(response.getEventDetails());
        assertNull(response.getCreatedAt());
        assertNull(response.getCreatedBy());
        assertNull(response.getStatus());
        assertNull(response.getUser());
        assertNull(response.getDetails());
        assertNull(response.getTimestamp());
    }
    
    @Test
    void testConstructorWithWorkflowHistory() {
        // Setup
        WorkflowHistory history = new WorkflowHistory();
        history.setId(1);
        history.setWorkflowInstanceId(100);
        history.setTaskInstanceId(200);
        history.setEventType("WORKFLOW_CREATED");
        history.setEventDetails("Workflow created successfully");
        Timestamp timestamp = Timestamp.from(Instant.now());
        history.setCreatedAt(timestamp);
        history.setCreatedBy("testUser");
        history.setStatus("ACTIVE");
        
        // Execute
        WorkflowHistoryResponse response = new WorkflowHistoryResponse(history);
        
        // Verify
        assertEquals(1, response.getId());
        assertEquals(100, response.getWorkflowInstanceId());
        assertEquals(200, response.getTaskInstanceId());
        assertEquals("WORKFLOW_CREATED", response.getEventType());
        assertEquals("Workflow created successfully", response.getEventDetails());
        assertEquals(timestamp, response.getCreatedAt());
        assertEquals("testUser", response.getCreatedBy());
        assertEquals("ACTIVE", response.getStatus());
        assertEquals("testUser", response.getUser());
        assertEquals("Workflow created successfully", response.getDetails());
        assertEquals(timestamp.toString(), response.getTimestamp());
    }
    
    @Test
    void testFromModel() {
        // Setup
        WorkflowHistory history = new WorkflowHistory();
        history.setId(1);
        history.setWorkflowInstanceId(100);
        
        // Execute
        WorkflowHistoryResponse response = WorkflowHistoryResponse.fromModel(history);
        
        // Verify
        assertNotNull(response);
        assertEquals(1, response.getId());
        assertEquals(100, response.getWorkflowInstanceId());
    }
    
    @Test
    void testGettersAndSetters() {
        // Setup
        WorkflowHistoryResponse response = new WorkflowHistoryResponse();
        Timestamp timestamp = Timestamp.from(Instant.now());
        
        // Execute
        response.setId(1);
        response.setWorkflowInstanceId(100);
        response.setTaskInstanceId(200);
        response.setEventType("WORKFLOW_CREATED");
        response.setEventDetails("Workflow created successfully");
        response.setCreatedAt(timestamp);
        response.setCreatedBy("testUser");
        response.setStatus("ACTIVE");
        response.setUser("anotherUser");
        response.setDetails("Additional details");
        
        // Verify
        assertEquals(1, response.getId());
        assertEquals(100, response.getWorkflowInstanceId());
        assertEquals(200, response.getTaskInstanceId());
        assertEquals("WORKFLOW_CREATED", response.getEventType());
        assertEquals("Workflow created successfully", response.getEventDetails());
        assertEquals(timestamp, response.getCreatedAt());
        assertEquals("testUser", response.getCreatedBy());
        assertEquals("ACTIVE", response.getStatus());
        assertEquals("anotherUser", response.getUser());
        assertEquals("Additional details", response.getDetails());
        assertEquals(timestamp.toString(), response.getTimestamp());
    }
    
    @Test
    void testGetTimestampWithNullCreatedAt() {
        // Setup
        WorkflowHistoryResponse response = new WorkflowHistoryResponse();
        response.setCreatedAt(null);
        
        // Execute & Verify
        assertNull(response.getTimestamp());
    }
}
