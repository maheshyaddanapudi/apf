package com.workday.apflow.dto.response;

import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class WorkflowHistoryRecordResponseTest {

    @Test
    void testDefaultConstructor() {
        // Execute
        WorkflowHistoryRecordResponse response = new WorkflowHistoryRecordResponse();
        
        // Verify
        assertNull(response.getId());
        assertNull(response.getWorkflowInstanceId());
        assertNull(response.getTaskInstanceId());
        assertNull(response.getEventType());
        assertNull(response.getEventDetails());
        assertNull(response.getTimestamp());
        assertNull(response.getUserId());
    }
    
    @Test
    void testGettersAndSetters() {
        // Setup
        WorkflowHistoryRecordResponse response = new WorkflowHistoryRecordResponse();
        Date timestamp = new Date();
        
        // Execute
        response.setId(1);
        response.setWorkflowInstanceId(100);
        response.setTaskInstanceId(200);
        response.setEventType("WORKFLOW_CREATED");
        response.setEventDetails("Workflow created successfully");
        response.setTimestamp(timestamp);
        response.setUserId("testUser");
        
        // Verify
        assertEquals(1, response.getId());
        assertEquals(100, response.getWorkflowInstanceId());
        assertEquals(200, response.getTaskInstanceId());
        assertEquals("WORKFLOW_CREATED", response.getEventType());
        assertEquals("Workflow created successfully", response.getEventDetails());
        assertEquals(timestamp, response.getTimestamp());
        assertEquals("testUser", response.getUserId());
    }
    
    @Test
    void testBuilderPattern() {
        // Setup
        Date timestamp = new Date();
        
        // Execute
        WorkflowHistoryRecordResponse response = new WorkflowHistoryRecordResponse.Builder()
                .withId(1)
                .withWorkflowInstanceId(100)
                .withTaskInstanceId(200)
                .withEventType("WORKFLOW_CREATED")
                .withEventDetails("Workflow created successfully")
                .withTimestamp(timestamp)
                .withUserId("testUser")
                .build();
        
        // Verify
        assertEquals(1, response.getId());
        assertEquals(100, response.getWorkflowInstanceId());
        assertEquals(200, response.getTaskInstanceId());
        assertEquals("WORKFLOW_CREATED", response.getEventType());
        assertEquals("Workflow created successfully", response.getEventDetails());
        assertEquals(timestamp, response.getTimestamp());
        assertEquals("testUser", response.getUserId());
    }
    
    @Test
    void testBuilderWithNullValues() {
        // Execute
        WorkflowHistoryRecordResponse response = new WorkflowHistoryRecordResponse.Builder()
                .withId(null)
                .withWorkflowInstanceId(null)
                .withTaskInstanceId(null)
                .withEventType(null)
                .withEventDetails(null)
                .withTimestamp(null)
                .withUserId(null)
                .build();
        
        // Verify
        assertNull(response.getId());
        assertNull(response.getWorkflowInstanceId());
        assertNull(response.getTaskInstanceId());
        assertNull(response.getEventType());
        assertNull(response.getEventDetails());
        assertNull(response.getTimestamp());
        assertNull(response.getUserId());
    }
    
    @Test
    void testBuilderWithPartialValues() {
        // Execute
        WorkflowHistoryRecordResponse response = new WorkflowHistoryRecordResponse.Builder()
                .withId(1)
                .withWorkflowInstanceId(100)
                .build();
        
        // Verify
        assertEquals(1, response.getId());
        assertEquals(100, response.getWorkflowInstanceId());
        assertNull(response.getTaskInstanceId());
        assertNull(response.getEventType());
        assertNull(response.getEventDetails());
        assertNull(response.getTimestamp());
        assertNull(response.getUserId());
    }
}
