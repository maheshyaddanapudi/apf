package com.workday.apflow.dto.response;

import com.workday.apflow.dto.workflow.WorkflowInstanceDTO;
import com.workday.apflow.model.WorkflowInstance;
import org.junit.jupiter.api.Test;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class WorkflowInstanceResponseTest {

    @Test
    public void testDefaultConstructor() {
        WorkflowInstanceResponse response = new WorkflowInstanceResponse();
        
        assertNotNull(response);
        assertNull(response.getId());
        assertNull(response.getName());
        assertNull(response.getStatus());
        assertNull(response.getCreatedBy());
        assertNull(response.getCreatedAt());
        assertNull(response.getStartedAt());
        assertNull(response.getCompletedAt());
        assertNotNull(response.getInputData());
        assertTrue(response.getInputData().isEmpty());
        assertNotNull(response.getOutputData());
        assertTrue(response.getOutputData().isEmpty());
        assertNull(response.getInstanceDto());
    }
    
    @Test
    public void testBuilder() {
        Integer id = 1;
        String name = "Test Workflow";
        String status = "RUNNING";
        String createdBy = "test-user";
        Timestamp createdAt = new Timestamp(System.currentTimeMillis());
        Timestamp startedAt = new Timestamp(System.currentTimeMillis());
        Timestamp completedAt = null;
        Map<String, Object> inputData = new HashMap<>();
        inputData.put("key1", "value1");
        Map<String, Object> outputData = new HashMap<>();
        outputData.put("result", "success");
        WorkflowInstanceDTO instanceDto = new WorkflowInstanceDTO();
        
        WorkflowInstanceResponse response = WorkflowInstanceResponse.builder()
                .id(id)
                .name(name)
                .status(status)
                .createdBy(createdBy)
                .createdAt(createdAt)
                .startedAt(startedAt)
                .completedAt(completedAt)
                .inputData(inputData)
                .outputData(outputData)
                .instanceDto(instanceDto)
                .build();
        
        assertEquals(id, response.getId());
        assertEquals(name, response.getName());
        assertEquals(status, response.getStatus());
        assertEquals(createdBy, response.getCreatedBy());
        assertEquals(createdAt, response.getCreatedAt());
        assertEquals(startedAt, response.getStartedAt());
        assertEquals(completedAt, response.getCompletedAt());
        assertEquals(inputData, response.getInputData());
        assertEquals(outputData, response.getOutputData());
        assertEquals(instanceDto, response.getInstanceDto());
    }
    
    @Test
    public void testSettersAndGetters() {
        WorkflowInstanceResponse response = new WorkflowInstanceResponse();
        
        Integer id = 1;
        String name = "Test Workflow";
        String status = "RUNNING";
        String createdBy = "test-user";
        Timestamp createdAt = new Timestamp(System.currentTimeMillis());
        Timestamp startedAt = new Timestamp(System.currentTimeMillis());
        Timestamp completedAt = null;
        Map<String, Object> inputData = new HashMap<>();
        inputData.put("key1", "value1");
        Map<String, Object> outputData = new HashMap<>();
        outputData.put("result", "success");
        WorkflowInstanceDTO instanceDto = new WorkflowInstanceDTO();
        
        response.setId(id);
        response.setName(name);
        response.setStatus(status);
        response.setCreatedBy(createdBy);
        response.setCreatedAt(createdAt);
        response.setStartedAt(startedAt);
        response.setCompletedAt(completedAt);
        response.setInputData(inputData);
        response.setOutputData(outputData);
        response.setInstanceDto(instanceDto);
        
        assertEquals(id, response.getId());
        assertEquals(name, response.getName());
        assertEquals(status, response.getStatus());
        assertEquals(createdBy, response.getCreatedBy());
        assertEquals(createdAt, response.getCreatedAt());
        assertEquals(startedAt, response.getStartedAt());
        assertEquals(completedAt, response.getCompletedAt());
        assertEquals(inputData, response.getInputData());
        assertEquals(outputData, response.getOutputData());
        assertEquals(instanceDto, response.getInstanceDto());
    }
    
    @Test
    public void testFromModel() {
        // Create a workflow instance model
        WorkflowInstance model = new WorkflowInstance();
        model.setId(1);
        model.setName("Test Workflow");
        model.setStatus("RUNNING");
        model.setCreatedBy("test-user");
        model.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        model.setStartedAt(new Timestamp(System.currentTimeMillis()));
        model.setCompletedAt(null);
        
        // Set input and output data
        Map<String, Object> inputData = new HashMap<>();
        inputData.put("key1", "value1");
        model.setInputMap(inputData);
        
        Map<String, Object> outputData = new HashMap<>();
        outputData.put("result", "success");
        model.setOutputMap(outputData);
        
        // Set instance DTO
        WorkflowInstanceDTO instanceDto = new WorkflowInstanceDTO();
        model.setInstanceDto(instanceDto);
        
        // Convert model to response
        WorkflowInstanceResponse response = WorkflowInstanceResponse.fromModel(model);
        
        // Verify conversion
        assertEquals(model.getId(), response.getId());
        assertEquals(model.getName(), response.getName());
        assertEquals(model.getStatus(), response.getStatus());
        assertEquals(model.getCreatedBy(), response.getCreatedBy());
        assertEquals(model.getCreatedAt(), response.getCreatedAt());
        assertEquals(model.getStartedAt(), response.getStartedAt());
        assertEquals(model.getCompletedAt(), response.getCompletedAt());
        assertEquals(model.getInputMap(), response.getInputData());
        assertEquals(model.getOutputMap(), response.getOutputData());
        assertEquals(model.getInstanceDto(), response.getInstanceDto());
    }
    
    @Test
    public void testFromModelWithNullModel() {
        assertNull(WorkflowInstanceResponse.fromModel(null));
    }
    
    @Test
    public void testInputJsonBackwardCompatibility() {
        WorkflowInstanceResponse response = new WorkflowInstanceResponse();
        
        // Test setting input data via JSON
        response.setInputJson("{\"key1\":\"value1\",\"key2\":123}");
        
        assertEquals(2, response.getInputData().size());
        assertEquals("value1", response.getInputData().get("key1"));
        assertEquals(123, response.getInputData().get("key2"));
        
        // Test getting input data as JSON
        String inputJson = response.getInputJson();
        assertTrue(inputJson.contains("\"key1\":\"value1\""));
        assertTrue(inputJson.contains("\"key2\":123"));
        
        // Test setting null or empty input JSON
        response.setInputJson(null);
        assertNotNull(response.getInputData());
        assertTrue(response.getInputData().isEmpty());
        
        response.setInputJson("");
        assertNotNull(response.getInputData());
        assertTrue(response.getInputData().isEmpty());
        
        // Test setting invalid input JSON
        response.setInputJson("invalid json");
        assertNotNull(response.getInputData());
        assertTrue(response.getInputData().isEmpty());
    }
    
    @Test
    public void testOutputJsonBackwardCompatibility() {
        WorkflowInstanceResponse response = new WorkflowInstanceResponse();
        
        // Test setting output data via JSON
        response.setOutputJson("{\"result\":\"success\",\"count\":42}");
        
        assertEquals(2, response.getOutputData().size());
        assertEquals("success", response.getOutputData().get("result"));
        assertEquals(42, response.getOutputData().get("count"));
        
        // Test getting output data as JSON
        String outputJson = response.getOutputJson();
        assertTrue(outputJson.contains("\"result\":\"success\""));
        assertTrue(outputJson.contains("\"count\":42"));
        
        // Test setting null or empty output JSON
        response.setOutputJson(null);
        assertNotNull(response.getOutputData());
        assertTrue(response.getOutputData().isEmpty());
        
        response.setOutputJson("");
        assertNotNull(response.getOutputData());
        assertTrue(response.getOutputData().isEmpty());
        
        // Test setting invalid output JSON
        response.setOutputJson("invalid json");
        assertNotNull(response.getOutputData());
        assertTrue(response.getOutputData().isEmpty());
    }
    
    @Test
    public void testEqualsAndHashCode() {
        WorkflowInstanceResponse response1 = new WorkflowInstanceResponse();
        response1.setId(1);
        response1.setName("Test Workflow");
        response1.setStatus("RUNNING");
        
        WorkflowInstanceResponse response2 = new WorkflowInstanceResponse();
        response2.setId(1);
        response2.setName("Test Workflow");
        response2.setStatus("RUNNING");
        
        WorkflowInstanceResponse response3 = new WorkflowInstanceResponse();
        response3.setId(2);
        response3.setName("Different Workflow");
        response3.setStatus("PENDING");
        
        // Test equals
        assertEquals(response1, response1); // Same object
        assertEquals(response1, response2); // Equal objects
        assertNotEquals(response1, response3); // Different ID
        assertNotEquals(response1, null); // Null
        assertNotEquals(response1, new Object()); // Different class
        
        // Test hashCode
        assertEquals(response1.hashCode(), response2.hashCode());
        assertNotEquals(response1.hashCode(), response3.hashCode());
    }
    
    @Test
    public void testToString() {
        WorkflowInstanceResponse response = new WorkflowInstanceResponse();
        response.setId(1);
        response.setName("Test Workflow");
        response.setStatus("RUNNING");
        
        String toString = response.toString();
        assertNotNull(toString);
        assertTrue(toString.contains("id=1"));
        assertTrue(toString.contains("name='Test Workflow'"));
        assertTrue(toString.contains("status='RUNNING'"));
    }
}
