package com.workday.apflow.dto.workflow;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class TaskDTOTest {

    @Test
    void testDefaultConstructor() {
        // Execute
        TaskDTO taskDTO = new TaskDTO();
        
        // Verify
        assertNotNull(taskDTO);
        assertNull(taskDTO.getId());
        assertNull(taskDTO.getName());
        assertNull(taskDTO.getType());
        assertNull(taskDTO.getAssignment());
        assertNotNull(taskDTO.getProperties());
        assertTrue(taskDTO.getProperties().isEmpty());
        assertNotNull(taskDTO.getInputData());
        assertTrue(taskDTO.getInputData().isEmpty());
        assertNotNull(taskDTO.getOutputData());
        assertTrue(taskDTO.getOutputData().isEmpty());
    }
    
    @Test
    void testGettersAndSetters() {
        // Setup
        TaskDTO taskDTO = new TaskDTO();
        String id = "task-123";
        String name = "Test Task";
        String type = "TODO";
        String assignment = "testUser";
        Map<String, Object> properties = new HashMap<>();
        properties.put("priority", "high");
        Map<String, Object> inputData = new HashMap<>();
        inputData.put("key1", "value1");
        Map<String, Object> outputData = new HashMap<>();
        outputData.put("result", "success");
        
        // Execute
        taskDTO.setId(id);
        taskDTO.setName(name);
        taskDTO.setType(type);
        taskDTO.setAssignment(assignment);
        taskDTO.setProperties(properties);
        taskDTO.setInputData(inputData);
        taskDTO.setOutputData(outputData);
        
        // Verify
        assertEquals(id, taskDTO.getId());
        assertEquals(name, taskDTO.getName());
        assertEquals(type, taskDTO.getType());
        assertEquals(assignment, taskDTO.getAssignment());
        assertEquals(properties, taskDTO.getProperties());
        assertEquals(inputData, taskDTO.getInputData());
        assertEquals(outputData, taskDTO.getOutputData());
    }
    
    @Test
    void testEqualsAndHashCode() {
        // Setup
        TaskDTO task1 = new TaskDTO();
        task1.setId("task-123");
        task1.setName("Test Task");
        task1.setType("TODO");
        
        TaskDTO task2 = new TaskDTO();
        task2.setId("task-123");
        task2.setName("Test Task");
        task2.setType("TODO");
        
        TaskDTO task3 = new TaskDTO();
        task3.setId("task-456");
        task3.setName("Another Task");
        task3.setType("APPROVAL");
        
        // Verify
        assertEquals(task1, task2);
        assertNotEquals(task1, task3);
        assertEquals(task1.hashCode(), task2.hashCode());
        assertNotEquals(task1.hashCode(), task3.hashCode());
    }
    
    @Test
    void testEqualsWithNull() {
        // Setup
        TaskDTO task = new TaskDTO();
        task.setId("task-123");
        
        // Verify
        assertNotEquals(task, null);
    }
    
    @Test
    void testEqualsWithDifferentClass() {
        // Setup
        TaskDTO task = new TaskDTO();
        task.setId("task-123");
        String string = "task-123";
        
        // Verify
        assertNotEquals(task, string);
    }
    
    @Test
    void testEqualsSameObject() {
        // Setup
        TaskDTO task = new TaskDTO();
        task.setId("task-123");
        
        // Verify
        assertEquals(task, task);
    }
    
    @Test
    void testToString() {
        // Setup
        TaskDTO task = new TaskDTO();
        task.setId("task-123");
        task.setName("Test Task");
        task.setType("TODO");
        
        // Execute
        String result = task.toString();
        
        // Verify
        assertNotNull(result);
        assertTrue(result.contains("task-123"));
        assertTrue(result.contains("Test Task"));
        assertTrue(result.contains("TODO"));
    }
    
    @Test
    void testInputDataHandling() {
        // Setup
        TaskDTO task = new TaskDTO();
        Map<String, Object> inputData = new HashMap<>();
        inputData.put("key1", "value1");
        inputData.put("key2", 123);
        inputData.put("key3", true);
        
        // Execute
        task.setInputData(inputData);
        
        // Verify
        assertEquals(inputData, task.getInputData());
        assertEquals("value1", task.getInputData().get("key1"));
        assertEquals(123, task.getInputData().get("key2"));
        assertEquals(true, task.getInputData().get("key3"));
    }
    
    @Test
    void testOutputDataHandling() {
        // Setup
        TaskDTO task = new TaskDTO();
        Map<String, Object> outputData = new HashMap<>();
        outputData.put("result", "success");
        outputData.put("count", 42);
        outputData.put("completed", true);
        
        // Execute
        task.setOutputData(outputData);
        
        // Verify
        assertEquals(outputData, task.getOutputData());
        assertEquals("success", task.getOutputData().get("result"));
        assertEquals(42, task.getOutputData().get("count"));
        assertEquals(true, task.getOutputData().get("completed"));
    }
    
    @Test
    void testNullInputData() {
        // Setup
        TaskDTO task = new TaskDTO();
        
        // Execute
        task.setInputData(null);
        
        // Verify
        assertNotNull(task.getInputData());
        assertTrue(task.getInputData().isEmpty());
    }
    
    @Test
    void testEmptyInputData() {
        // Setup
        TaskDTO task = new TaskDTO();
        Map<String, Object> emptyInputData = new HashMap<>();
        
        // Execute
        task.setInputData(emptyInputData);
        
        // Verify
        assertNotNull(task.getInputData());
        assertTrue(task.getInputData().isEmpty());
    }
    
    @Test
    void testNullOutputData() {
        // Setup
        TaskDTO task = new TaskDTO();
        
        // Execute
        task.setOutputData(null);
        
        // Verify
        assertNotNull(task.getOutputData());
        assertTrue(task.getOutputData().isEmpty());
    }
    
    @Test
    void testEmptyOutputData() {
        // Setup
        TaskDTO task = new TaskDTO();
        Map<String, Object> emptyOutputData = new HashMap<>();
        
        // Execute
        task.setOutputData(emptyOutputData);
        
        // Verify
        assertNotNull(task.getOutputData());
        assertTrue(task.getOutputData().isEmpty());
    }
    
    @Test
    void testAddProperty() {
        // Setup
        TaskDTO task = new TaskDTO();
        
        // Execute
        task.addProperty("priority", "high");
        task.addProperty("dueDate", "2023-12-31");
        
        // Verify
        assertNotNull(task.getProperties());
        assertEquals("high", task.getProperties().get("priority"));
        assertEquals("2023-12-31", task.getProperties().get("dueDate"));
    }
    
    @Test
    void testAddInputData() {
        // Setup
        TaskDTO task = new TaskDTO();
        
        // Execute
        task.addInputData("key1", "value1");
        task.addInputData("key2", 123);
        
        // Verify
        assertNotNull(task.getInputData());
        assertEquals("value1", task.getInputData().get("key1"));
        assertEquals(123, task.getInputData().get("key2"));
    }
    
    @Test
    void testAddOutputData() {
        // Setup
        TaskDTO task = new TaskDTO();
        
        // Execute
        task.addOutputData("result", "success");
        task.addOutputData("count", 42);
        
        // Verify
        assertNotNull(task.getOutputData());
        assertEquals("success", task.getOutputData().get("result"));
        assertEquals(42, task.getOutputData().get("count"));
    }
    
    @Test
    void testMethodChaining() {
        // Setup
        TaskDTO task = new TaskDTO();
        
        // Execute
        task.setId("task-123")
            .setName("Test Task")
            .setType("TODO")
            .setAssignment("testUser")
            .addProperty("priority", "high")
            .addInputData("key1", "value1")
            .addOutputData("result", "success");
        
        // Verify
        assertEquals("task-123", task.getId());
        assertEquals("Test Task", task.getName());
        assertEquals("TODO", task.getType());
        assertEquals("testUser", task.getAssignment());
        assertEquals("high", task.getProperties().get("priority"));
        assertEquals("value1", task.getInputData().get("key1"));
        assertEquals("success", task.getOutputData().get("result"));
    }
}
