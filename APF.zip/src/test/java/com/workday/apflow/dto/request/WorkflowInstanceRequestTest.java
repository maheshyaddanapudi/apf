package com.workday.apflow.dto.request;

import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class WorkflowInstanceRequestTest {

    @Test
    public void testDefaultConstructor() {
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        
        assertNotNull(request);
        assertNotNull(request.getSequence());
        assertTrue(request.getSequence().isEmpty());
        assertNotNull(request.getOperators());
        assertTrue(request.getOperators().isEmpty());
        assertNotNull(request.getStandaloneTasks());
        assertTrue(request.getStandaloneTasks().isEmpty());
        assertNotNull(request.getInputData());
        assertTrue(request.getInputData().isEmpty());
    }
    
    @Test
    public void testBuilder() {
        String name = "Test Workflow";
        String createdBy = "test-user";
        Map<String, Object> inputData = new HashMap<>();
        inputData.put("key1", "value1");
        
        WorkflowInstanceRequest request = WorkflowInstanceRequest.builder()
                .name(name)
                .createdBy(createdBy)
                .inputData(inputData)
                .build();
        
        assertEquals(name, request.getName());
        assertEquals(createdBy, request.getCreatedBy());
        assertEquals(inputData, request.getInputData());
        assertNotNull(request.getSequence());
        assertNotNull(request.getOperators());
        assertNotNull(request.getStandaloneTasks());
    }
    
    @Test
    public void testSettersAndGetters() {
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        
        String name = "Test Workflow";
        String createdBy = "test-user";
        Map<String, Object> inputData = new HashMap<>();
        inputData.put("key1", "value1");
        List<String> sequence = List.of("op1", "task1");
        
        request.setName(name);
        request.setCreatedBy(createdBy);
        request.setInputData(inputData);
        request.setSequence(sequence);
        
        assertEquals(name, request.getName());
        assertEquals(createdBy, request.getCreatedBy());
        assertEquals(inputData, request.getInputData());
        assertEquals(sequence, request.getSequence());
    }
    
    @Test
    public void testAddOperator() {
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        
        Map<String, Object> operatorProps = new HashMap<>();
        operatorProps.put("assignees", List.of("user1", "user2"));
        
        String operatorId = request.addOperator("dynamicFork", operatorProps);
        
        assertNotNull(operatorId);
        assertTrue(operatorId.startsWith("op-"));
        assertEquals(1, request.getOperators().size());
        assertTrue(request.getOperators().containsKey(operatorId));
        
        Map<String, Object> operator = request.getOperators().get(operatorId);
        assertEquals("dynamicFork", operator.get("type"));
        assertNotNull(operator.get("properties"));
        assertNotNull(operator.get("tasks"));
    }
    
    @Test
    public void testAddTaskToOperator() {
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        
        // Add operator
        String operatorId = request.addOperator("dynamicFork", null);
        
        // Add task to operator
        Map<String, Object> taskProps = new HashMap<>();
        taskProps.put("priority", "high");
        String taskId = request.addTaskToOperator(operatorId, "Review Document", "TODO", taskProps);
        
        assertNotNull(taskId);
        assertTrue(taskId.startsWith("task-"));
        
        Map<String, Object> operator = request.getOperators().get(operatorId);
        assertNotNull(operator);
        
        @SuppressWarnings("unchecked")
        Map<String, Object> tasks = (Map<String, Object>) operator.get("tasks");
        assertNotNull(tasks);
        assertEquals(1, tasks.size());
        assertTrue(tasks.containsKey(taskId));
        
        Map<String, Object> task = (Map<String, Object>) tasks.get(taskId);
        assertEquals("Review Document", task.get("name"));
        assertEquals("TODO", task.get("type"));
        assertEquals(taskProps, task.get("properties"));
    }
    
    @Test
    public void testAddTaskToNonExistentOperator() {
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        
        Map<String, Object> taskProps = new HashMap<>();
        taskProps.put("priority", "high");
        
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            request.addTaskToOperator("non-existent", "Review Document", "TODO", taskProps);
        });
        
        assertTrue(exception.getMessage().contains("Operator not found"));
    }
    
    @Test
    public void testAddStandaloneTask() {
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        
        Map<String, Object> taskProps = new HashMap<>();
        taskProps.put("priority", "high");
        
        String taskId = request.addStandaloneTask("Final Approval", "TODO", taskProps);
        
        assertNotNull(taskId);
        assertTrue(taskId.startsWith("task-"));
        assertEquals(1, request.getStandaloneTasks().size());
        assertTrue(request.getStandaloneTasks().containsKey(taskId));
        
        Map<String, Object> task = request.getStandaloneTasks().get(taskId);
        assertEquals("Final Approval", task.get("name"));
        assertEquals("TODO", task.get("type"));
        assertEquals(taskProps, task.get("properties"));
    }
    
    @Test
    public void testInputDataManipulation() {
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        
        // Test adding input data
        request.addInputData("key1", "value1");
        request.addInputData("key2", 123);
        
        assertEquals(2, request.getInputData().size());
        assertEquals("value1", request.getInputData().get("key1"));
        assertEquals(123, request.getInputData().get("key2"));
        
        // Test setting input data
        Map<String, Object> newInputData = new HashMap<>();
        newInputData.put("key3", "value3");
        request.setInputData(newInputData);
        
        assertEquals(1, request.getInputData().size());
        assertEquals("value3", request.getInputData().get("key3"));
        
        // Test setting null input data
        request.setInputData(null);
        assertNotNull(request.getInputData());
        assertTrue(request.getInputData().isEmpty());
    }
    
    @Test
    public void testInputJsonBackwardCompatibility() {
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        
        // Test setting input data via JSON
        request.setInputJson("{\"key1\":\"value1\",\"key2\":123}");
        
        assertEquals(2, request.getInputData().size());
        assertEquals("value1", request.getInputData().get("key1"));
        assertEquals(123, request.getInputData().get("key2"));
        
        // Test getting input data as JSON
        String inputJson = request.getInputJson();
        assertTrue(inputJson.contains("\"key1\":\"value1\""));
        assertTrue(inputJson.contains("\"key2\":123"));
        
        // Test setting null or empty input JSON
        request.setInputJson(null);
        assertNotNull(request.getInputData());
        assertTrue(request.getInputData().isEmpty());
        
        request.setInputJson("");
        assertNotNull(request.getInputData());
        assertTrue(request.getInputData().isEmpty());
        
        // Test setting invalid input JSON
        request.setInputJson("invalid json");
        assertNotNull(request.getInputData());
        assertTrue(request.getInputData().isEmpty());
    }
    
    @Test
    public void testEqualsAndHashCode() {
        WorkflowInstanceRequest request1 = new WorkflowInstanceRequest();
        request1.setName("Test Workflow");
        request1.setCreatedBy("test-user");
        request1.addInputData("key1", "value1");
        
        WorkflowInstanceRequest request2 = new WorkflowInstanceRequest();
        request2.setName("Test Workflow");
        request2.setCreatedBy("test-user");
        request2.addInputData("key1", "value1");
        
        WorkflowInstanceRequest request3 = new WorkflowInstanceRequest();
        request3.setName("Different Workflow");
        request3.setCreatedBy("test-user");
        
        // Test equals
        assertEquals(request1, request1); // Same object
        assertEquals(request1, request2); // Equal objects
        assertNotEquals(request1, request3); // Different name
        assertNotEquals(request1, null); // Null
        assertNotEquals(request1, new Object()); // Different class
        
        // Test hashCode
        assertEquals(request1.hashCode(), request2.hashCode());
        assertNotEquals(request1.hashCode(), request3.hashCode());
    }
    
    @Test
    public void testToString() {
        WorkflowInstanceRequest request = new WorkflowInstanceRequest();
        request.setName("Test Workflow");
        request.setCreatedBy("test-user");
        request.addInputData("key1", "value1");
        
        String toString = request.toString();
        assertNotNull(toString);
        assertTrue(toString.contains("name='Test Workflow'"));
        assertTrue(toString.contains("createdBy='test-user'"));
        assertTrue(toString.contains("inputData={key1=value1}"));
    }
    
    @Test
    public void testComplexWorkflowConstruction() {
        WorkflowInstanceRequest request = new WorkflowInstanceRequest()
                .setName("Complex Workflow")
                .setCreatedBy("test-user");
        
        // Add input data
        request.addInputData("documentId", "doc-123");
        request.addInputData("priority", "high");
        
        // Add fork operator
        Map<String, Object> forkProps = new HashMap<>();
        forkProps.put("assignees", List.of("user1", "user2", "user3"));
        String forkId = request.addOperator("dynamicFork", forkProps);
        
        // Add tasks to fork
        Map<String, Object> reviewProps = new HashMap<>();
        reviewProps.put("priority", "high");
        reviewProps.put("dueDate", "2023-12-31");
        String review1 = request.addTaskToOperator(forkId, "Review Document", "TODO", reviewProps);
        String review2 = request.addTaskToOperator(forkId, "Verify Content", "TODO", reviewProps);
        
        // Add join operator
        Map<String, Object> joinProps = new HashMap<>();
        joinProps.put("requiredApprovals", 2);
        String joinId = request.addOperator("dynamicJoin", joinProps);
        
        // Add final approval task
        Map<String, Object> approvalProps = new HashMap<>();
        approvalProps.put("priority", "critical");
        approvalProps.put("escalation", "manager");
        String finalApprovalId = request.addStandaloneTask("Final Approval", "APPROVAL", approvalProps);
        
        // Set sequence
        request.setSequence(List.of(forkId, joinId, finalApprovalId));
        
        // Verify structure
        assertEquals(3, request.getSequence().size());
        assertEquals(2, request.getOperators().size());
        assertEquals(1, request.getStandaloneTasks().size());
        assertEquals(2, request.getInputData().size());
        
        // Verify operators
        assertTrue(request.getOperators().containsKey(forkId));
        assertTrue(request.getOperators().containsKey(joinId));
        
        // Verify fork tasks
        Map<String, Object> forkOperator = request.getOperators().get(forkId);
        @SuppressWarnings("unchecked")
        Map<String, Object> forkTasks = (Map<String, Object>) forkOperator.get("tasks");
        assertEquals(2, forkTasks.size());
        
        // Verify standalone tasks
        assertTrue(request.getStandaloneTasks().containsKey(finalApprovalId));
        Map<String, Object> finalApproval = request.getStandaloneTasks().get(finalApprovalId);
        assertEquals("Final Approval", finalApproval.get("name"));
        assertEquals("APPROVAL", finalApproval.get("type"));
    }
}
