package com.workday.apflow.test.java.com.workday.apflow.handler;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.workday.apflow.constants.TaskConstants;
import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.execution.ExecutionQueuingInterceptor;
import com.workday.apflow.execution.WorkflowStateManager;
import com.workday.apflow.handler.ToDoTaskHandler;
import com.workday.apflow.model.TaskInstance;
import com.workday.apflow.model.WorkflowExecutionQueue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ToDoTaskHandlerTest {

    @Mock
    private TaskInstanceDAO taskInstanceDAO;
    
    @Mock
    private ExecutionQueuingInterceptor executionQueuingInterceptor;
    
    @Mock
    private WorkflowStateManager workflowStateManager;
    
    private ToDoTaskHandler taskHandler;
    private ObjectMapper objectMapper = new ObjectMapper();
    
    @BeforeEach
    public void setUp() {
        taskHandler = new ToDoTaskHandler(taskInstanceDAO, executionQueuingInterceptor, workflowStateManager);
    }
    
    @Test
    public void testGetType() {
        assertEquals(TaskConstants.TYPE_TODO, taskHandler.getType());
    }
    
    @Test
    public void testExecute() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        task.setStatus(TaskConstants.STATUS_PENDING);
        
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(task);
        
        // Execute
        taskHandler.execute(task);
        
        // Verify
        assertEquals(TaskConstants.STATUS_IN_PROGRESS, task.getStatus());
        assertNotNull(task.getStartedAt());
        verify(taskInstanceDAO).updateTaskInstance(task);
    }
    
    @Test
    public void testComplete() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        task.setWorkflowInstanceId(100);
        task.setStatus(TaskConstants.STATUS_IN_PROGRESS);
        
        WorkflowExecutionQueue queueEntry = new WorkflowExecutionQueue();
        queueEntry.setId(1);
        queueEntry.setWorkflowInstanceId(100);
        queueEntry.setNewlyCreated(true);
        
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(task);
        when(executionQueuingInterceptor.interceptTaskCompletion(any(TaskInstance.class))).thenReturn(queueEntry);
        
        // Execute
        taskHandler.complete(task);
        
        // Verify
        assertEquals(TaskConstants.STATUS_COMPLETED, task.getStatus());
        assertNotNull(task.getCompletedAt());
        verify(taskInstanceDAO).updateTaskInstance(task);
        verify(executionQueuingInterceptor).interceptTaskCompletion(task);
        verify(workflowStateManager).processWorkflowInstance(100, queueEntry);
    }
    
    @Test
    public void testComplete_QueueEntryNotNewlyCreated() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        task.setWorkflowInstanceId(100);
        task.setStatus(TaskConstants.STATUS_IN_PROGRESS);
        
        WorkflowExecutionQueue queueEntry = new WorkflowExecutionQueue();
        queueEntry.setId(1);
        queueEntry.setWorkflowInstanceId(100);
        queueEntry.setNewlyCreated(false);
        
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(task);
        when(executionQueuingInterceptor.interceptTaskCompletion(any(TaskInstance.class))).thenReturn(queueEntry);
        
        // Execute
        taskHandler.complete(task);
        
        // Verify
        assertEquals(TaskConstants.STATUS_COMPLETED, task.getStatus());
        assertNotNull(task.getCompletedAt());
        verify(taskInstanceDAO).updateTaskInstance(task);
        verify(executionQueuingInterceptor).interceptTaskCompletion(task);
        verify(workflowStateManager, never()).processWorkflowInstance(anyInt(), any(WorkflowExecutionQueue.class));
    }
    
    @Test
    public void testCreateTask() {
        // Setup
        Integer workflowInstanceId = 1;
        String taskId = "task1";
        String name = "Test Task";
        String assignment = "user1";
        JsonNode properties = objectMapper.createObjectNode().put(TaskConstants.PROP_TASK_GROUP_ID, 10);
        
        TaskInstance expectedTask = new TaskInstance();
        expectedTask.setId(1);
        
        when(taskInstanceDAO.createTaskInstance(any(TaskInstance.class))).thenReturn(expectedTask);
        
        // Execute
        TaskInstance result = taskHandler.createTask(workflowInstanceId, taskId, name, assignment, properties);
        
        // Verify
        assertNotNull(result);
        assertEquals(expectedTask.getId(), result.getId());
        
        ArgumentCaptor<TaskInstance> taskCaptor = ArgumentCaptor.forClass(TaskInstance.class);
        verify(taskInstanceDAO).createTaskInstance(taskCaptor.capture());
        
        TaskInstance capturedTask = taskCaptor.getValue();
        assertEquals(workflowInstanceId, capturedTask.getWorkflowInstanceId());
        assertEquals(taskId, capturedTask.getTaskId());
        assertEquals(name, capturedTask.getName());
        assertEquals(TaskConstants.TYPE_TODO, capturedTask.getType());
        assertEquals(TaskConstants.STATUS_PENDING, capturedTask.getStatus());
        assertEquals(assignment, capturedTask.getAssignment());
        assertEquals(10, capturedTask.getTaskGroupInstanceId());
    }
    
    @Test
    public void testCreateTaskWithString() {
        // Setup
        Integer workflowInstanceId = 1;
        String name = "Test Task";
        String inputJson = "{\"key\":\"value\"}";
        String assignment = "user1";
        Integer taskGroupInstanceId = 10;
        
        TaskInstance expectedTask = new TaskInstance();
        expectedTask.setId(1);
        
        when(taskInstanceDAO.createTaskInstance(any(TaskInstance.class))).thenReturn(expectedTask);
        
        // Execute
        TaskInstance result = taskHandler.createTask(workflowInstanceId, name, inputJson, assignment, taskGroupInstanceId);
        
        // Verify
        assertNotNull(result);
        assertEquals(expectedTask.getId(), result.getId());
        
        ArgumentCaptor<TaskInstance> taskCaptor = ArgumentCaptor.forClass(TaskInstance.class);
        verify(taskInstanceDAO).createTaskInstance(taskCaptor.capture());
        
        TaskInstance capturedTask = taskCaptor.getValue();
        assertEquals(workflowInstanceId, capturedTask.getWorkflowInstanceId());
        assertEquals(name, capturedTask.getName());
        assertEquals(TaskConstants.TYPE_TODO, capturedTask.getType());
        assertEquals(TaskConstants.STATUS_PENDING, capturedTask.getStatus());
        assertEquals(assignment, capturedTask.getAssignment());
        assertEquals(inputJson, capturedTask.getInputJson());
        assertEquals(taskGroupInstanceId, capturedTask.getTaskGroupInstanceId());
    }
    
    @Test
    public void testCreateAndExecuteWithString() {
        // Setup
        Integer workflowInstanceId = 1;
        String name = "Test Task";
        Map<String, Object> input = new HashMap<>();
        input.put("key", "value");
        String assignment = "user1";
        Integer taskGroupInstanceId = 10;
        
        TaskInstance createdTask = new TaskInstance();
        createdTask.setId(1);
        createdTask.setStatus(TaskConstants.STATUS_PENDING);
        
        TaskInstance executedTask = new TaskInstance();
        executedTask.setId(1);
        executedTask.setStatus(TaskConstants.STATUS_IN_PROGRESS);
        
        when(taskInstanceDAO.createTaskInstance(any(TaskInstance.class))).thenReturn(createdTask);
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(executedTask);
        
        // Execute
        TaskInstance result = taskHandler.createAndExecute(workflowInstanceId, name, input, assignment, taskGroupInstanceId);
        
        // Verify
        assertNotNull(result);
        assertEquals(executedTask.getId(), result.getId());
        assertEquals(executedTask.getStatus(), result.getStatus());
        
        verify(taskInstanceDAO).createTaskInstance(any(TaskInstance.class));
        verify(taskInstanceDAO).updateTaskInstance(any(TaskInstance.class));
    }
    
    @Test
    public void testCompleteAndCloseWithMap() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        task.setWorkflowInstanceId(100);
        task.setStatus(TaskConstants.STATUS_IN_PROGRESS);
        
        Map<String, Object> output = new HashMap<>();
        output.put("result", "success");
        
        WorkflowExecutionQueue queueEntry = new WorkflowExecutionQueue();
        queueEntry.setId(1);
        queueEntry.setWorkflowInstanceId(100);
        queueEntry.setNewlyCreated(true);
        
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(task);
        when(executionQueuingInterceptor.interceptTaskCompletion(any(TaskInstance.class))).thenReturn(queueEntry);
        
        // Execute
        TaskInstance result = taskHandler.completeAndClose(task, output);
        
        // Verify
        assertNotNull(result);
        assertEquals(task.getId(), result.getId());
        assertEquals(TaskConstants.STATUS_COMPLETED, task.getStatus());
        assertNotNull(task.getCompletedAt());
        assertNotNull(task.getOutputJson());
        
        verify(taskInstanceDAO).updateTaskInstance(task);
        verify(executionQueuingInterceptor).interceptTaskCompletion(task);
        verify(workflowStateManager).processWorkflowInstance(100, queueEntry);
    }
    
    @Test
    public void testCompleteAndCloseWithString() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        task.setWorkflowInstanceId(100);
        task.setStatus(TaskConstants.STATUS_IN_PROGRESS);
        
        String outputJson = "{\"result\":\"success\"}";
        
        WorkflowExecutionQueue queueEntry = new WorkflowExecutionQueue();
        queueEntry.setId(1);
        queueEntry.setWorkflowInstanceId(100);
        queueEntry.setNewlyCreated(true);
        
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(task);
        when(executionQueuingInterceptor.interceptTaskCompletion(any(TaskInstance.class))).thenReturn(queueEntry);
        
        // Execute
        TaskInstance result = taskHandler.completeAndClose(task, outputJson);
        
        // Verify
        assertNotNull(result);
        assertEquals(task.getId(), result.getId());
        assertEquals(TaskConstants.STATUS_COMPLETED, task.getStatus());
        assertNotNull(task.getCompletedAt());
        assertEquals(outputJson, task.getOutputJson());
        
        verify(taskInstanceDAO).updateTaskInstance(task);
        verify(executionQueuingInterceptor).interceptTaskCompletion(task);
        verify(workflowStateManager).processWorkflowInstance(100, queueEntry);
    }
    
    @Test
    public void testMoveToCompleteWithMap() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        task.setWorkflowInstanceId(100);
        task.setStatus(TaskConstants.STATUS_IN_PROGRESS);
        
        Map<String, Object> output = new HashMap<>();
        output.put("result", "success");
        
        WorkflowExecutionQueue queueEntry = new WorkflowExecutionQueue();
        queueEntry.setId(1);
        queueEntry.setWorkflowInstanceId(100);
        queueEntry.setNewlyCreated(true);
        
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(task);
        when(executionQueuingInterceptor.interceptTaskCompletion(any(TaskInstance.class))).thenReturn(queueEntry);
        
        // Execute
        TaskInstance result = taskHandler.moveToComplete(task, output);
        
        // Verify
        assertNotNull(result);
        assertEquals(task.getId(), result.getId());
        assertEquals(TaskConstants.STATUS_COMPLETED, task.getStatus());
        assertNotNull(task.getCompletedAt());
        assertNotNull(task.getOutputJson());
        
        verify(taskInstanceDAO).updateTaskInstance(task);
        verify(executionQueuingInterceptor).interceptTaskCompletion(task);
        verify(workflowStateManager).processWorkflowInstance(100, queueEntry);
    }
    
    @Test
    public void testMoveToCompleteWithString() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        task.setWorkflowInstanceId(100);
        task.setStatus(TaskConstants.STATUS_IN_PROGRESS);
        
        String outputJson = "{\"result\":\"success\"}";
        
        WorkflowExecutionQueue queueEntry = new WorkflowExecutionQueue();
        queueEntry.setId(1);
        queueEntry.setWorkflowInstanceId(100);
        queueEntry.setNewlyCreated(true);
        
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(task);
        when(executionQueuingInterceptor.interceptTaskCompletion(any(TaskInstance.class))).thenReturn(queueEntry);
        
        // Execute
        TaskInstance result = taskHandler.moveToComplete(task, outputJson);
        
        // Verify
        assertNotNull(result);
        assertEquals(task.getId(), result.getId());
        assertEquals(TaskConstants.STATUS_COMPLETED, task.getStatus());
        assertNotNull(task.getCompletedAt());
        assertEquals(outputJson, task.getOutputJson());
        
        verify(taskInstanceDAO).updateTaskInstance(task);
        verify(executionQueuingInterceptor).interceptTaskCompletion(task);
        verify(workflowStateManager).processWorkflowInstance(100, queueEntry);
    }
    
    @Test
    public void testClose() {
        // Setup
        TaskInstance task = new TaskInstance();
        task.setId(1);
        
        // Execute
        taskHandler.close(task);
        
        // Verify - no interactions expected for close in ToDoTaskHandler
        verifyNoInteractions(taskInstanceDAO);
        verifyNoInteractions(executionQueuingInterceptor);
        verifyNoInteractions(workflowStateManager);
    }
}
