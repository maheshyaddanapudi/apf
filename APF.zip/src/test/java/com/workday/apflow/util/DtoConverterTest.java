package com.workday.apflow.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.workday.apflow.constants.WorkflowConstants;
import com.workday.apflow.dto.workflow.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class DtoConverterTest {

    private ObjectMapper objectMapper;
    private WorkflowInstanceDTO sampleDto;
    private String sampleJson;

    @BeforeEach
    public void setUp() {
        objectMapper = new ObjectMapper();
        
        // Create a sample WorkflowInstanceDTO
        sampleDto = new WorkflowInstanceDTO();
        sampleDto.setName("Test Workflow");
        sampleDto.setCurrentPosition(1);
        
        // Create a sample sequence
        List<SequenceItemDTO> sequence = new ArrayList<>();
        
        // Add a task group item
        TaskGroupSequenceItemDTO taskGroupItem = new TaskGroupSequenceItemDTO();
        taskGroupItem.setId("tg1");
        taskGroupItem.setType(WorkflowConstants.TYPE_TASK_GROUP);
        sequence.add(taskGroupItem);
        
        // Add a task item
        TaskSequenceItemDTO taskItem = new TaskSequenceItemDTO();
        taskItem.setId("task1");
        taskItem.setTaskType("TODO");
        taskItem.setName("Test Task");
        taskItem.setAssignment("user1");
        taskItem.setTaskInstanceId(123);
        sequence.add(taskItem);
        
        sampleDto.setSequence(sequence);
        
        // Create a sample task groups map
        Map<String, TaskGroupDTO> taskGroups = new HashMap<>();
        TaskGroupDTO taskGroupDto = new TaskGroupDTO();
        taskGroupDto.setType("HORIZONTAL");
        taskGroupDto.setName("Horizontal Task Group");
        taskGroupDto.setInitialized(true);
        taskGroups.put("tg1", taskGroupDto);
        
        sampleDto.setTaskGroups(taskGroups);
        
        // Create a sample JSON string
        sampleJson = "{\"" + WorkflowConstants.FIELD_CURRENT_POSITION + "\":1," +
                "\"" + WorkflowConstants.FIELD_SEQUENCE + "\":[" +
                "{\"" + WorkflowConstants.FIELD_TYPE + "\":\"" + WorkflowConstants.TYPE_TASK_GROUP + "\"," +
                "\"" + WorkflowConstants.FIELD_ID + "\":\"tg1\"}," +
                "{\"" + WorkflowConstants.FIELD_TYPE + "\":\"" + WorkflowConstants.TYPE_TASK + "\"," +
                "\"" + WorkflowConstants.FIELD_ID + "\":\"task1\"," +
                "\"" + WorkflowConstants.FIELD_TASK_TYPE + "\":\"TODO\"," +
                "\"" + WorkflowConstants.FIELD_NAME + "\":\"Test Task\"," +
                "\"" + WorkflowConstants.FIELD_ASSIGNMENT + "\":\"user1\"," +
                "\"" + WorkflowConstants.FIELD_TASK_INSTANCE_ID + "\":123}" +
                "]," +
                "\"" + WorkflowConstants.PROP_TASK_GROUPS + "\":{" +
                "\"tg1\":{" +
                "\"" + WorkflowConstants.FIELD_TYPE + "\":\"HORIZONTAL\"," +
                "\"" + WorkflowConstants.FIELD_NAME + "\":\"Horizontal Task Group\"," +
                "\"" + WorkflowConstants.FIELD_INITIALIZED + "\":true" +
                "}" +
                "}}";
    }

    @Test
    public void testToWorkflowInstanceDto_String() {
        // Convert JSON string to DTO
        WorkflowInstanceDTO result = DtoConverter.toWorkflowInstanceDto(sampleJson);
        
        // Verify the result
        assertNotNull(result);
        assertEquals(1, result.getCurrentPosition());
        assertNotNull(result.getSequence());
        assertEquals(2, result.getSequence().size());
        
        // Verify task group sequence item
        assertTrue(result.getSequence().get(0) instanceof TaskGroupSequenceItemDTO);
        TaskGroupSequenceItemDTO taskGroupItem = (TaskGroupSequenceItemDTO) result.getSequence().get(0);
        assertEquals("tg1", taskGroupItem.getId());
        assertEquals(WorkflowConstants.TYPE_TASK_GROUP, taskGroupItem.getType());
        
        // Verify task sequence item
        assertTrue(result.getSequence().get(1) instanceof TaskSequenceItemDTO);
        TaskSequenceItemDTO taskItem = (TaskSequenceItemDTO) result.getSequence().get(1);
        assertEquals("task1", taskItem.getId());
        assertEquals("TODO", taskItem.getTaskType());
        assertEquals("Test Task", taskItem.getName());
        assertEquals("user1", taskItem.getAssignment());
        assertEquals(123, taskItem.getTaskInstanceId());
        
        // Verify task groups
        assertNotNull(result.getTaskGroups());
        assertEquals(1, result.getTaskGroups().size());
        assertTrue(result.getTaskGroups().containsKey("tg1"));
        assertEquals("HORIZONTAL", result.getTaskGroups().get("tg1").getType());
        assertEquals("Horizontal Task Group", result.getTaskGroups().get("tg1").getName());
        assertTrue(result.getTaskGroups().get("tg1").isInitialized());
    }
    
    @Test
    public void testToWorkflowInstanceDto_EmptyString() {
        // Convert empty JSON string to DTO
        WorkflowInstanceDTO result = DtoConverter.toWorkflowInstanceDto("");
        
        // Verify the result
        assertNotNull(result);
        assertEquals(0, result.getCurrentPosition());
        assertNotNull(result.getSequence());
        assertTrue(result.getSequence().isEmpty());
        assertNotNull(result.getTaskGroups());
        assertTrue(result.getTaskGroups().isEmpty());
    }
    
    @Test
    public void testToWorkflowInstanceDto_NullString() {
        // Convert null JSON string to DTO
        String nullString = null;
        WorkflowInstanceDTO result = DtoConverter.toWorkflowInstanceDto(nullString);
        
        // Verify the result
        assertNotNull(result);
        assertEquals(0, result.getCurrentPosition());
        assertNotNull(result.getSequence());
        assertTrue(result.getSequence().isEmpty());
        assertNotNull(result.getTaskGroups());
        assertTrue(result.getTaskGroups().isEmpty());
    }
    
    @Test
    public void testToJson_WorkflowInstanceDTO() {
        // Convert DTO to JSON string
        String result = DtoConverter.toJson(sampleDto);
        
        // Verify the result
        assertNotNull(result);
        assertTrue(result.contains("\"currentPosition\":1"));
        assertTrue(result.contains("\"sequence\":["));
        assertTrue(result.contains("\"taskGroups\":{"));
    }
    
    @Test
    public void testToJson_NullWorkflowInstanceDTO() {
        // Convert null DTO to JSON string
        String result = DtoConverter.toJson((WorkflowInstanceDTO) null);
        
        // Verify the result
        assertNotNull(result);
        assertEquals("{}", result);
    }
    
    @Test
    public void testToMap() {
        // Create a sample JSON string
        String json = "{\"name\":\"John\",\"age\":30,\"isActive\":true}";
        
        // Convert JSON string to Map
        Map<String, Object> result = DtoConverter.toMap(json);
        
        // Verify the result
        assertNotNull(result);
        assertEquals(3, result.size());
        assertEquals("John", result.get("name"));
        assertEquals(30, result.get("age"));
        assertEquals(true, result.get("isActive"));
    }
    
    @Test
    public void testToMap_EmptyString() {
        // Convert empty JSON string to Map
        Map<String, Object> result = DtoConverter.toMap("");
        
        // Verify the result
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
    
    @Test
    public void testToMap_NullString() {
        // Convert null JSON string to Map
        Map<String, Object> result = DtoConverter.toMap(null);
        
        // Verify the result
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }
    
    @Test
    public void testToJson_Map() {
        // Create a sample Map
        Map<String, Object> map = new HashMap<>();
        map.put("name", "John");
        map.put("age", 30);
        map.put("isActive", true);
        
        // Convert Map to JSON string
        String result = DtoConverter.toJson(map);
        
        // Verify the result
        assertNotNull(result);
        assertTrue(result.contains("\"name\":\"John\""));
        assertTrue(result.contains("\"age\":30"));
        assertTrue(result.contains("\"isActive\":true"));
    }
    
    @Test
    public void testToJson_NullMap() {
        // Convert null Map to JSON string
        String result = DtoConverter.toJson((Map<String, Object>) null);
        
        // Verify the result
        assertNotNull(result);
        assertEquals("{}", result);
    }
    
    @Test
    public void testToWorkflowInstanceDto_JsonNode() {
        // Convert JsonNode to DTO
        JsonNode jsonNode = null;
        try {
            jsonNode = objectMapper.readTree(sampleJson);
        } catch (Exception e) {
            fail("Failed to parse JSON: " + e.getMessage());
        }
        
        WorkflowInstanceDTO result = DtoConverter.toWorkflowInstanceDto(jsonNode);
        
        // Verify the result
        assertNotNull(result);
        assertEquals(1, result.getCurrentPosition());
        assertNotNull(result.getSequence());
        assertEquals(2, result.getSequence().size());
    }
    
    @Test
    public void testToWorkflowInstanceDto_NullJsonNode() {
        // Convert null JsonNode to DTO
        JsonNode nullNode = null;
        WorkflowInstanceDTO result = DtoConverter.toWorkflowInstanceDto(nullNode);
        
        // Verify the result
        assertNotNull(result);
        assertEquals(0, result.getCurrentPosition());
        assertNotNull(result.getSequence());
        assertTrue(result.getSequence().isEmpty());
        assertNotNull(result.getTaskGroups());
        assertTrue(result.getTaskGroups().isEmpty());
    }
    
    @Test
    public void testToJsonNode_WorkflowInstanceDTO() {
        // Convert DTO to JsonNode
        JsonNode result = DtoConverter.toJsonNode(sampleDto);
        
        // Verify the result
        assertNotNull(result);
        assertTrue(result.has("currentPosition"));
        assertEquals(1, result.get("currentPosition").asInt());
        assertTrue(result.has("sequence"));
        assertTrue(result.has("taskGroups"));
    }
    
    @Test
    public void testToJsonNode_NullWorkflowInstanceDTO() {
        // Convert null DTO to JsonNode
        JsonNode result = DtoConverter.toJsonNode((WorkflowInstanceDTO) null);
        
        // Verify the result
        assertNotNull(result);
        assertTrue(result.isObject());
        assertEquals(0, result.size());
    }
    
    @Test
    public void testToJsonNode_TaskGroupDTO() {
        // Create a sample TaskGroupDTO
        TaskGroupDTO taskGroupDto = new TaskGroupDTO();
        taskGroupDto.setType("HORIZONTAL");
        taskGroupDto.setName("Horizontal Task Group");
        taskGroupDto.setInitialized(true);
        
        // Convert TaskGroupDTO to JsonNode
        JsonNode result = DtoConverter.toJsonNode(taskGroupDto);
        
        // Verify the result
        assertNotNull(result);
        assertTrue(result.has("type"));
        assertEquals("HORIZONTAL", result.get("type").asText());
        assertTrue(result.has("name"));
        assertEquals("Horizontal Task Group", result.get("name").asText());
        assertTrue(result.has("initialized"));
        assertTrue(result.get("initialized").asBoolean());
    }
    
    @Test
    public void testToJsonNode_NullTaskGroupDTO() {
        // Convert null TaskGroupDTO to JsonNode
        TaskGroupDTO nullTaskGroup = null;
        JsonNode result = DtoConverter.toJsonNode(nullTaskGroup);
        
        // Verify the result
        assertNotNull(result);
        assertTrue(result.isObject());
        assertEquals(0, result.size());
    }
    
    @Test
    public void testToJsonNode_Object() {
        // Create a sample Object
        Map<String, Object> map = new HashMap<>();
        map.put("name", "John");
        map.put("age", 30);
        
        // Convert Object to JsonNode
        JsonNode result = DtoConverter.toJsonNode(map);
        
        // Verify the result
        assertNotNull(result);
        assertTrue(result.has("name"));
        assertEquals("John", result.get("name").asText());
        assertTrue(result.has("age"));
        assertEquals(30, result.get("age").asInt());
    }
    
    @Test
    public void testToJsonNode_NullObject() {
        // Convert null Object to JsonNode
        Object nullObject = null;
        JsonNode result = DtoConverter.toJsonNode(nullObject);
        
        // Verify the result
        assertNotNull(result);
        assertTrue(result.isObject());
        assertEquals(0, result.size());
    }
}
