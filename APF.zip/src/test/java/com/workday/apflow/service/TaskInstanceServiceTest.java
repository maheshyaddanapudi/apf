package com.workday.apflow.service;

import com.workday.apflow.constants.TaskConstants;
import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.dto.request.TaskInstanceRequest;
import com.workday.apflow.model.TaskInstance;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class TaskInstanceServiceTest {
    
    @Mock
    private TaskInstanceDAO taskInstanceDAO;
    
    private TaskInstanceService taskInstanceService;
    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        taskInstanceService = createTaskInstanceService();
    }
    
    private TaskInstanceService createTaskInstanceService() {
        return new AbstractTaskInstanceService() {
            @Override
            public TaskInstanceDAO getTaskInstanceDAO() {
                return taskInstanceDAO;
            }
            
            @Override
            public TaskInstance createTaskInstance(TaskInstanceRequest request) {
                return new TaskInstance();
            }
            
            @Override
            public List<TaskInstance> createTaskInstances(List<TaskInstanceRequest> requests) {
                return new ArrayList<>();
            }
            
            @Override
            public TaskInstance getTaskInstance(Integer taskInstanceId) {
                return taskInstanceDAO.getTaskInstance(taskInstanceId);
            }
            
            @Override
            public List<TaskInstance> getTaskInstancesByWorkflowInstance(Integer workflowInstanceId) {
                return taskInstanceDAO.getTaskInstancesByWorkflowInstance(workflowInstanceId);
            }
            
            @Override
            public List<TaskInstance> getTaskInstancesByStatus(String status) {
                return taskInstanceDAO.getTaskInstancesByStatus(status);
            }
            
            @Override
            public List<TaskInstance> getTaskInstancesByAssignment(String assignment) {
                return taskInstanceDAO.getTaskInstancesByAssignment(assignment);
            }
            
            @Override
            public TaskInstance cancelTaskInstance(Integer taskInstanceId) {
                TaskInstance taskInstance = taskInstanceDAO.getTaskInstance(taskInstanceId);
                if (taskInstance.getStatus().equals(TaskConstants.STATUS_COMPLETED) || 
                    taskInstance.getStatus().equals(TaskConstants.STATUS_TERMINATED)) {
                    throw new RuntimeException("Cannot cancel a task that is already terminated");
                }
                taskInstance.setStatus(TaskConstants.STATUS_TERMINATED);
                return taskInstanceDAO.updateTaskInstance(taskInstance);
            }
            
            @Override
            public TaskInstance updateTaskInstance(TaskInstance taskInstance) {
                return taskInstanceDAO.updateTaskInstance(taskInstance);
            }
            
            @Override
            public List<TaskInstance> getTasksByDueDate(Date dueDate) {
                // Implement custom logic for test
                List<TaskInstance> tasks = new ArrayList<>();
                TaskInstance task = new TaskInstance();
                task.setId(1);
                task.setDueDate(dueDate);
                tasks.add(task);
                return tasks;
            }
            
            @Override
            public List<TaskInstance> getOverdueTasks() {
                // Implement custom logic for test
                List<TaskInstance> tasks = new ArrayList<>();
                TaskInstance task = new TaskInstance();
                task.setId(1);
                task.setDueDate(new Date(System.currentTimeMillis() - 86400000)); // Yesterday
                tasks.add(task);
                return tasks;
            }
            
            @Override
            public List<TaskInstance> getTasksByTaskGroup(Integer taskGroupInstanceId) {
                return new ArrayList<>();
            }
            
            @Override
            public List<TaskInstance> getTasksByType(String taskType) {
                return new ArrayList<>();
            }
        };
    }
    
    @Test
    void testGetTaskInstance() {
        // Setup
        Integer taskInstanceId = 1;
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(taskInstanceId);
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(taskInstance);
        
        // Execute
        TaskInstance result = taskInstanceService.getTaskInstance(taskInstanceId);
        
        // Verify
        assertNotNull(result);
        assertEquals(taskInstanceId, result.getId());
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
    }
    
    @Test
    void testGetTaskInstancesByWorkflowInstance() {
        // Setup
        Integer workflowInstanceId = 1;
        List<TaskInstance> taskInstances = new ArrayList<>();
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(1);
        taskInstance.setWorkflowInstanceId(workflowInstanceId);
        taskInstances.add(taskInstance);
        
        when(taskInstanceDAO.getTaskInstancesByWorkflowInstance(workflowInstanceId)).thenReturn(taskInstances);
        
        // Execute
        List<TaskInstance> result = taskInstanceService.getTaskInstancesByWorkflowInstance(workflowInstanceId);
        
        // Verify
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(workflowInstanceId, result.get(0).getWorkflowInstanceId());
        verify(taskInstanceDAO, times(1)).getTaskInstancesByWorkflowInstance(workflowInstanceId);
    }
    
    @Test
    void testGetTaskInstancesByStatus() {
        // Setup
        String status = TaskConstants.STATUS_PENDING;
        List<TaskInstance> taskInstances = new ArrayList<>();
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(1);
        taskInstance.setStatus(status);
        taskInstances.add(taskInstance);
        
        when(taskInstanceDAO.getTaskInstancesByStatus(status)).thenReturn(taskInstances);
        
        // Execute
        List<TaskInstance> result = taskInstanceService.getTaskInstancesByStatus(status);
        
        // Verify
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(status, result.get(0).getStatus());
        verify(taskInstanceDAO, times(1)).getTaskInstancesByStatus(status);
    }
    
    @Test
    void testGetTaskInstancesByAssignment() {
        // Setup
        String assignment = "test-user";
        List<TaskInstance> taskInstances = new ArrayList<>();
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(1);
        taskInstance.setAssignment(assignment);
        taskInstances.add(taskInstance);
        
        when(taskInstanceDAO.getTaskInstancesByAssignment(assignment)).thenReturn(taskInstances);
        
        // Execute
        List<TaskInstance> result = taskInstanceService.getTaskInstancesByAssignment(assignment);
        
        // Verify
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(assignment, result.get(0).getAssignment());
        verify(taskInstanceDAO, times(1)).getTaskInstancesByAssignment(assignment);
    }
    
    @Test
    void testCancelTaskInstance() {
        // Setup
        Integer taskInstanceId = 1;
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(taskInstanceId);
        taskInstance.setStatus(TaskConstants.STATUS_PENDING);
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(taskInstance);
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(taskInstance);
        
        // Execute
        TaskInstance result = taskInstanceService.cancelTaskInstance(taskInstanceId);
        
        // Verify
        assertNotNull(result);
        assertEquals(taskInstanceId, result.getId());
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, times(1)).updateTaskInstance(any(TaskInstance.class));
    }
    
    @Test
    void testCancelTaskInstance_AlreadyTerminated() {
        // Setup
        Integer taskInstanceId = 1;
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(taskInstanceId);
        taskInstance.setStatus(TaskConstants.STATUS_COMPLETED);
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(taskInstance);
        
        // Execute & Verify
        assertThrows(RuntimeException.class, () -> 
            taskInstanceService.cancelTaskInstance(taskInstanceId)
        );
        
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, never()).updateTaskInstance(any(TaskInstance.class));
    }
    
    @Test
    void testGetTasksByDueDate() {
        // Setup
        Date dueDate = new Date();
        
        // Execute
        List<TaskInstance> result = taskInstanceService.getTasksByDueDate(dueDate);
        
        // Verify
        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(dueDate, result.get(0).getDueDate());
    }
    
    @Test
    void testGetOverdueTasks() {
        // Setup
        Date now = new Date();
        
        // Execute
        List<TaskInstance> result = taskInstanceService.getOverdueTasks();
        
        // Verify
        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertTrue(result.get(0).getDueDate().before(now));
    }
    
    @Test
    void testUpdateTaskInstance() {
        // Setup
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(1);
        taskInstance.setName("Test Task");
        taskInstance.setStatus(TaskConstants.STATUS_PENDING);
        
        when(taskInstanceDAO.updateTaskInstance(taskInstance)).thenReturn(taskInstance);
        
        // Execute
        TaskInstance result = taskInstanceService.updateTaskInstance(taskInstance);
        
        // Verify
        assertNotNull(result);
        assertEquals(1, result.getId());
        assertEquals("Test Task", result.getName());
        assertEquals(TaskConstants.STATUS_PENDING, result.getStatus());
        verify(taskInstanceDAO, times(1)).updateTaskInstance(taskInstance);
    }
}
