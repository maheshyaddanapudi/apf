package com.workday.apflow.service;

import com.workday.apflow.constants.TaskConstants;
import com.workday.apflow.dao.TaskInstanceDAO;
import com.workday.apflow.error.RetryPolicy;
import com.workday.apflow.error.TaskException;
import com.workday.apflow.execution.ExecutionQueuingInterceptor;
import com.workday.apflow.model.TaskInstance;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TaskRetryServiceTest {

    @Mock
    private TaskInstanceDAO taskInstanceDAO;
    
    @Mock
    private ExecutionQueuingInterceptor interceptor;
    
    private TaskRetryService taskRetryService;
    
    @BeforeEach
    void setUp() {
        taskRetryService = new TaskRetryService(taskInstanceDAO, interceptor);
    }
    
    @Test
    void testRetryTask() {
        // Setup
        Integer taskInstanceId = 1;
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(taskInstanceId);
        taskInstance.setStatus(TaskConstants.STATUS_FAILED);
        taskInstance.setPropertiesMap(new HashMap<>());
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(taskInstance);
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(taskInstance);
        
        // Execute
        TaskInstance result = taskRetryService.retryTask(taskInstanceId);
        
        // Verify
        assertNotNull(result);
        assertEquals(TaskConstants.STATUS_PENDING, result.getStatus());
        assertEquals(1, result.getPropertiesMap().get("retryCount"));
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, times(1)).updateTaskInstance(any(TaskInstance.class));
        verify(interceptor, times(1)).interceptTaskRetry(any(TaskInstance.class));
    }
    
    @Test
    void testRetryTask_TaskNotFound() {
        // Setup
        Integer taskInstanceId = 1;
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(null);
        
        // Execute & Verify
        assertThrows(IllegalArgumentException.class, () -> 
            taskRetryService.retryTask(taskInstanceId)
        );
        
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, never()).updateTaskInstance(any(TaskInstance.class));
        verify(interceptor, never()).interceptTaskRetry(any(TaskInstance.class));
    }
    
    @Test
    void testRetryTask_TaskNotFailed() {
        // Setup
        Integer taskInstanceId = 1;
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(taskInstanceId);
        taskInstance.setStatus(TaskConstants.STATUS_COMPLETED);
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(taskInstance);
        
        // Execute & Verify
        assertThrows(TaskException.class, () -> 
            taskRetryService.retryTask(taskInstanceId)
        );
        
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, never()).updateTaskInstance(any(TaskInstance.class));
        verify(interceptor, never()).interceptTaskRetry(any(TaskInstance.class));
    }
    
    @Test
    void testRetryTaskWithNewInput() {
        // Setup
        Integer taskInstanceId = 1;
        Map<String, Object> newInputMap = new HashMap<>();
        newInputMap.put("key", "value");
        
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(taskInstanceId);
        taskInstance.setStatus(TaskConstants.STATUS_FAILED);
        taskInstance.setPropertiesMap(new HashMap<>());
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(taskInstance);
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(taskInstance);
        
        // Execute
        TaskInstance result = taskRetryService.retryTaskWithNewInput(taskInstanceId, newInputMap);
        
        // Verify
        assertNotNull(result);
        assertEquals(TaskConstants.STATUS_PENDING, result.getStatus());
        assertEquals(1, result.getPropertiesMap().get("retryCount"));
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, times(1)).updateTaskInstance(any(TaskInstance.class));
        verify(interceptor, times(1)).interceptTaskRetry(any(TaskInstance.class));
    }
    
    @Test
    void testRetryTaskWithNewInput_TaskNotFound() {
        // Setup
        Integer taskInstanceId = 1;
        Map<String, Object> newInputMap = new HashMap<>();
        newInputMap.put("key", "value");
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(null);
        
        // Execute & Verify
        assertThrows(IllegalArgumentException.class, () -> 
            taskRetryService.retryTaskWithNewInput(taskInstanceId, newInputMap)
        );
        
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, never()).updateTaskInstance(any(TaskInstance.class));
        verify(interceptor, never()).interceptTaskRetry(any(TaskInstance.class));
    }
    
    @Test
    void testRetryTaskWithNewInput_TaskNotFailed() {
        // Setup
        Integer taskInstanceId = 1;
        Map<String, Object> newInputMap = new HashMap<>();
        newInputMap.put("key", "value");
        
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(taskInstanceId);
        taskInstance.setStatus(TaskConstants.STATUS_COMPLETED);
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(taskInstance);
        
        // Execute & Verify
        assertThrows(TaskException.class, () -> 
            taskRetryService.retryTaskWithNewInput(taskInstanceId, newInputMap)
        );
        
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, never()).updateTaskInstance(any(TaskInstance.class));
        verify(interceptor, never()).interceptTaskRetry(any(TaskInstance.class));
    }
    
    @Test
    void testApplyRetryPolicy() {
        // Setup
        Integer taskInstanceId = 1;
        RetryPolicy retryPolicy = new RetryPolicy();
        retryPolicy.setMaxRetries(3);
        retryPolicy.setInitialDelayMillis(1000);
        retryPolicy.setBackoffMultiplier(2.0);
        
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(taskInstanceId);
        taskInstance.setStatus(TaskConstants.STATUS_FAILED);
        taskInstance.setPropertiesMap(new HashMap<>());
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(taskInstance);
        when(taskInstanceDAO.updateTaskInstance(any(TaskInstance.class))).thenReturn(taskInstance);
        
        // Execute
        boolean result = taskRetryService.applyRetryPolicy(taskInstanceId, retryPolicy);
        
        // Verify
        assertTrue(result);
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, times(1)).updateTaskInstance(any(TaskInstance.class));
        verify(interceptor, times(1)).interceptTaskRetry(any(TaskInstance.class));
    }
    
    @Test
    void testApplyRetryPolicy_MaxRetriesReached() {
        // Setup
        Integer taskInstanceId = 1;
        RetryPolicy retryPolicy = new RetryPolicy();
        retryPolicy.setMaxRetries(3);
        
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(taskInstanceId);
        taskInstance.setStatus(TaskConstants.STATUS_FAILED);
        
        Map<String, Object> properties = new HashMap<>();
        properties.put("retryCount", 3); // Already at max retries
        taskInstance.setPropertiesMap(properties);
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(taskInstance);
        
        // Execute
        boolean result = taskRetryService.applyRetryPolicy(taskInstanceId, retryPolicy);
        
        // Verify
        assertFalse(result);
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, never()).updateTaskInstance(any(TaskInstance.class));
        verify(interceptor, never()).interceptTaskRetry(any(TaskInstance.class));
    }
    
    @Test
    void testApplyRetryPolicy_TaskNotFound() {
        // Setup
        Integer taskInstanceId = 1;
        RetryPolicy retryPolicy = new RetryPolicy();
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(null);
        
        // Execute & Verify
        assertThrows(IllegalArgumentException.class, () -> 
            taskRetryService.applyRetryPolicy(taskInstanceId, retryPolicy)
        );
        
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, never()).updateTaskInstance(any(TaskInstance.class));
        verify(interceptor, never()).interceptTaskRetry(any(TaskInstance.class));
    }
    
    @Test
    void testApplyRetryPolicy_TaskNotFailed() {
        // Setup
        Integer taskInstanceId = 1;
        RetryPolicy retryPolicy = new RetryPolicy();
        
        TaskInstance taskInstance = new TaskInstance();
        taskInstance.setId(taskInstanceId);
        taskInstance.setStatus(TaskConstants.STATUS_COMPLETED);
        
        when(taskInstanceDAO.getTaskInstance(taskInstanceId)).thenReturn(taskInstance);
        
        // Execute & Verify
        assertThrows(TaskException.class, () -> 
            taskRetryService.applyRetryPolicy(taskInstanceId, retryPolicy)
        );
        
        verify(taskInstanceDAO, times(1)).getTaskInstance(taskInstanceId);
        verify(taskInstanceDAO, never()).updateTaskInstance(any(TaskInstance.class));
        verify(interceptor, never()).interceptTaskRetry(any(TaskInstance.class));
    }
}
