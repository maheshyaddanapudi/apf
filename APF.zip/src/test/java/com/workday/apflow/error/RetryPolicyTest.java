package com.workday.apflow.error;

import com.workday.apflow.constants.ErrorHandlingConstants;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class RetryPolicyTest {

    @Test
    void testDefaultConstructor() {
        // Execute
        RetryPolicy retryPolicy = new RetryPolicy();
        
        // Verify
        assertEquals(ErrorHandlingConstants.DEFAULT_MAX_RETRIES, retryPolicy.getMaxRetries());
        assertEquals(ErrorHandlingConstants.DEFAULT_RETRY_DELAY_SECONDS, retryPolicy.getRetryDelaySeconds());
        assertEquals(ErrorHandlingConstants.RETRY_POLICY_FIXED, retryPolicy.getRetryStrategy());
        assertEquals(ErrorHandlingConstants.DEFAULT_BACKOFF_MULTIPLIER, retryPolicy.getBackoffMultiplier());
        assertEquals(0, retryPolicy.getInitialDelayMillis());
    }
    
    @Test
    void testParameterizedConstructor() {
        // Execute
        int maxRetries = 3;
        int retryDelaySeconds = 10;
        String retryStrategy = "EXPONENTIAL";
        float backoffMultiplier = 1.5f;
        RetryPolicy retryPolicy = new RetryPolicy(maxRetries, retryDelaySeconds, retryStrategy, backoffMultiplier);
        
        // Verify
        assertEquals(maxRetries, retryPolicy.getMaxRetries());
        assertEquals(retryDelaySeconds, retryPolicy.getRetryDelaySeconds());
        assertEquals(retryStrategy, retryPolicy.getRetryStrategy());
        assertEquals(backoffMultiplier, retryPolicy.getBackoffMultiplier());
        assertEquals(0, retryPolicy.getInitialDelayMillis());
    }
    
    @Test
    void testGettersAndSetters() {
        // Setup
        RetryPolicy retryPolicy = new RetryPolicy();
        int maxRetries = 5;
        int retryDelaySeconds = 20;
        String retryStrategy = "FIXED";
        float backoffMultiplier = 2.5f;
        long initialDelayMillis = 1000L;
        
        // Execute
        retryPolicy.setMaxRetries(maxRetries);
        retryPolicy.setRetryDelaySeconds(retryDelaySeconds);
        retryPolicy.setRetryStrategy(retryStrategy);
        retryPolicy.setBackoffMultiplier(backoffMultiplier);
        retryPolicy.setInitialDelayMillis(initialDelayMillis);
        
        // Verify
        assertEquals(maxRetries, retryPolicy.getMaxRetries());
        assertEquals(retryDelaySeconds, retryPolicy.getRetryDelaySeconds());
        assertEquals(retryStrategy, retryPolicy.getRetryStrategy());
        assertEquals(backoffMultiplier, retryPolicy.getBackoffMultiplier());
        assertEquals(initialDelayMillis, retryPolicy.getInitialDelayMillis());
    }
    
    @Test
    void testSetBackoffMultiplierWithDouble() {
        // Setup
        RetryPolicy retryPolicy = new RetryPolicy();
        double backoffMultiplier = 3.5;
        
        // Execute
        retryPolicy.setBackoffMultiplier(backoffMultiplier);
        
        // Verify
        assertEquals((float)backoffMultiplier, retryPolicy.getBackoffMultiplier());
    }
    
    @Test
    void testCalculateDelayMillis_None() {
        // Setup
        RetryPolicy retryPolicy = new RetryPolicy();
        retryPolicy.setRetryStrategy(ErrorHandlingConstants.RETRY_POLICY_NONE);
        retryPolicy.setInitialDelayMillis(500L);
        
        // Execute & Verify
        assertEquals(500L, retryPolicy.calculateDelayMillis(1));
        assertEquals(500L, retryPolicy.calculateDelayMillis(2));
        assertEquals(500L, retryPolicy.calculateDelayMillis(3));
    }
    
    @Test
    void testCalculateDelayMillis_Fixed() {
        // Setup
        RetryPolicy retryPolicy = new RetryPolicy();
        retryPolicy.setRetryStrategy(ErrorHandlingConstants.RETRY_POLICY_FIXED);
        retryPolicy.setRetryDelaySeconds(10);
        retryPolicy.setInitialDelayMillis(500L);
        
        // Execute & Verify
        assertEquals(10500L, retryPolicy.calculateDelayMillis(1)); // 500 + (10 * 1000)
        assertEquals(10500L, retryPolicy.calculateDelayMillis(2)); // 500 + (10 * 1000)
        assertEquals(10500L, retryPolicy.calculateDelayMillis(3)); // 500 + (10 * 1000)
    }
    
    @Test
    void testCalculateDelayMillis_Exponential() {
        // Setup
        RetryPolicy retryPolicy = new RetryPolicy();
        retryPolicy.setRetryStrategy(ErrorHandlingConstants.RETRY_POLICY_EXPONENTIAL);
        retryPolicy.setRetryDelaySeconds(5);
        retryPolicy.setBackoffMultiplier(2.0f);
        retryPolicy.setInitialDelayMillis(500L);
        
        // Execute & Verify
        assertEquals(5500L, retryPolicy.calculateDelayMillis(1)); // 500 + (5 * 1000 * 2^0)
        assertEquals(10500L, retryPolicy.calculateDelayMillis(2)); // 500 + (5 * 1000 * 2^1)
        assertEquals(20500L, retryPolicy.calculateDelayMillis(3)); // 500 + (5 * 1000 * 2^2)
    }
    
    @Test
    void testCalculateDelayMillis_UnknownStrategy() {
        // Setup
        RetryPolicy retryPolicy = new RetryPolicy();
        retryPolicy.setRetryStrategy("UNKNOWN_STRATEGY");
        retryPolicy.setRetryDelaySeconds(10);
        retryPolicy.setInitialDelayMillis(500L);
        
        // Execute & Verify - Should default to fixed interval
        assertEquals(10500L, retryPolicy.calculateDelayMillis(1)); // 500 + (10 * 1000)
    }
    
    @Test
    void testCalculateDelayMillis_NullStrategy() {
        // Setup
        RetryPolicy retryPolicy = new RetryPolicy();
        retryPolicy.setRetryStrategy(null);
        retryPolicy.setRetryDelaySeconds(10);
        retryPolicy.setInitialDelayMillis(500L);
        
        // Execute & Verify - Should default to fixed interval
        assertEquals(10500L, retryPolicy.calculateDelayMillis(1)); // 500 + (10 * 1000)
    }
}
