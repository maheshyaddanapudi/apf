# APFlow

## Overview

APFlow is a robust Java library designed to manage workflow states and progressions in enterprise applications. It provides a flexible and extensible framework for defining, executing, and monitoring workflows with complex business logic.

This library implements a decoupled architecture where the workflow engine is completely separated from workflow definitions and task definitions. It uses a DTO-based approach for JSON handling instead of string literals, providing better type safety, IDE support, and reducing the risk of errors from string manipulation.

## Core Components

### 1. Workflow State Manager

The `WorkflowStateManager` is the central component responsible for:
- Processing workflow instances based on their current state
- Coordinating with task groups and task handlers
- Managing workflow state transitions
- Ensuring proper workflow progression

The state manager uses a DTO-based approach to represent workflow instances, with all sequence details maintained in the instance JSON structure.

### 2. Task Handler Framework

The task handler framework consists of:
- `TaskHandler` interface: Defines methods for creating, executing, and completing tasks
- `TaskHandlerRegistry`: Maintains a registry of task handlers and provides them when needed
- Concrete task handler implementations (e.g., `ToDoTaskHandler`)

Task handlers use Map<String, Object> for input and output data instead of string literals, providing better type safety and maintainability.

### 3. Task Group Framework

The task group framework includes:
- `TaskGroupHandler` interface: Defines methods for initializing, executing, and evaluating task groups
- `TaskGroupHandlerRegistry`: Maintains a registry of task group handlers and provides them when needed
- Concrete task group implementations (e.g., `HorizontalTaskGroupHandler`, `VerticalTaskGroupHandler`)

Task groups provide flexible patterns for organizing and executing related tasks, such as parallel execution or sequential workflows.

### 4. Execution Sweeper

The `WorkflowExecutionSweeper` processes pending queue entries and triggers workflow execution. It works in conjunction with:
- `ExecutionQueuingInterceptor`: Intercepts task completions and workflow resume events
- `WorkflowExecutionQueueDAO`: Manages the queue of workflow instances waiting to be processed

### 5. DTO-Based JSON Handling

The engine uses DTOs for JSON handling instead of string literals:
- `WorkflowInstanceDTO`: Represents a workflow instance
- `TaskGroupDTO`: Represents a task group state
- `SequenceItemDTO`: Base class for sequence items
- `TaskGroupSequenceItemDTO`: Represents a task group in a sequence
- `TaskSequenceItemDTO`: Represents a task in a sequence

## Architecture

APFlow follows a layered architecture:

1. **API Layer**: Provides interfaces for interacting with the engine
   - `WorkflowInstanceAPI`: Manages workflow instances
   - `TaskManagementAPI`: Manages task instances
   - `WorkflowHistoryAPI`: Provides access to workflow history
   - `WorkflowAdminAPI`: Provides administrative operations
   - `WorkflowMonitoringAPI`: Provides monitoring capabilities

2. **Service Layer**: Implements business logic
   - `WorkflowInstanceService`: Handles workflow instance operations
   - `TaskCompletionService`: Manages task completion logic
   - `WorkflowMigrationService`: Handles workflow migration

3. **Execution Layer**: Manages workflow execution
   - `WorkflowStateManager`: Manages workflow state and progression
   - `WorkflowExecutionSweeper`: Processes workflow execution queue
   - `ExecutionQueuingInterceptor`: Intercepts events and queues workflows

4. **Data Access Layer**: Provides access to data storage
   - `WorkflowInstanceDAO`: Manages workflow instance data
   - `TaskInstanceDAO`: Manages task instance data
   - `TaskGroupInstanceDAO`: Manages task group instance data
   - `WorkflowExecutionQueueDAO`: Manages execution queue data

## Integration Flow

APFlow implements a two-layer approach for workflow execution:

### Primary Path (Direct Execution)
1. When a task is completed, the task handler calls the `ExecutionQueuingInterceptor`
2. The interceptor directly calls the `WorkflowStateManager` to process the workflow
3. The `WorkflowStateManager` processes the workflow instance:
   - If the current item is a task group, it uses the `TaskGroupHandlerRegistry` to handle it
   - If the current item is a task, it uses the `TaskHandlerRegistry` to handle it
4. As tasks and task groups complete, the workflow progresses to the next item in the sequence

### Fallback Path (Sweeper-based Execution)
1. If the direct call to the `WorkflowStateManager` fails, the execution is queued for retry
2. The `WorkflowExecutionSweeper` processes failed executions from the queue
3. On startup, the sweeper processes all pending, in-progress, and failed queue entries
4. During subsequent sweeps, it only processes failed entries

This two-layer approach optimizes performance for the normal flow while providing resilience for failure scenarios. When the workflow reaches the end of the sequence, it is marked as completed.

## Key Features

- **Decoupled Architecture**: The engine is completely decoupled from definitions
- **DTO-Based JSON Handling**: Uses DTOs instead of string literals for better type safety
- **Flexible Task Group Framework**: Supports various task group types for complex workflows
- **Extensible Task Handler Framework**: Easily add new task types
- **Robust State Management**: Ensures proper workflow progression
- **Library-Only Implementation**: No Spring Boot dependencies, can be integrated into any Java application
- **Comprehensive Monitoring**: Built-in metrics and SLA monitoring
- **Workflow Migration**: Support for migrating workflows to newer versions

## Getting Started

### Prerequisites

- Java 11 or higher
- Gradle 7.0 or higher

### Installation

Add the library to your project dependencies:

```gradle
dependencies {
    implementation 'com.workday:apflow:1.0.0'
}
```

### Basic Usage

1. **Initialize the engine components**:

```java
// Create DAOs
WorkflowInstanceDAO workflowInstanceDAO = new WorkflowInstanceDAOImpl();
TaskInstanceDAO taskInstanceDAO = new TaskInstanceDAOImpl();
TaskGroupInstanceDAO taskGroupInstanceDAO = new TaskGroupInstanceDAOImpl();
WorkflowExecutionQueueDAO queueDAO = new WorkflowExecutionQueueDAOImpl();

// Create interceptor
ExecutionQueuingInterceptor interceptor = new ExecutionQueuingInterceptor(queueDAO);

// Create task handler registry
TaskHandlerRegistry taskHandlerRegistry = new TaskHandlerRegistry(interceptor);

// Register task handlers
taskHandlerRegistry.registerHandler(new ToDoTaskHandler(taskInstanceDAO, interceptor));

// Create task instance service
TaskInstanceService taskInstanceService = new TaskInstanceService(taskInstanceDAO);

// Create task group handler registry
TaskGroupHandlerRegistry taskGroupHandlerRegistry = new TaskGroupHandlerRegistry(taskInstanceService);

// Register task group handlers
taskGroupHandlerRegistry.registerHandler(new HorizontalTaskGroupHandler(taskHandlerRegistry));
taskGroupHandlerRegistry.registerHandler(new VerticalTaskGroupHandler(taskHandlerRegistry));

// Create state manager
WorkflowStateManager stateManager = new WorkflowStateManager(
    workflowInstanceDAO, 
    taskInstanceDAO,
    taskGroupInstanceDAO,
    taskHandlerRegistry, 
    taskGroupHandlerRegistry
);

// Create sweeper
WorkflowExecutionSweeper sweeper = new WorkflowExecutionSweeper(queueDAO, stateManager);

// Create APIs
WorkflowInstanceAPI workflowInstanceAPI = new WorkflowInstanceAPIImpl(workflowInstanceDAO);
TaskManagementAPI taskManagementAPI = new TaskManagementAPIImpl(taskInstanceService, new TaskCompletionService(taskInstanceDAO, interceptor));
```

2. **Create a workflow instance**:

```java
// Create workflow instance DTO
WorkflowInstanceDTO instanceDto = new WorkflowInstanceDTO();
instanceDto.setCurrentPosition(0);

// Create sequence
List<SequenceItemDTO> sequence = new ArrayList<>();

// Add a task to the sequence
TaskSequenceItemDTO taskItem = new TaskSequenceItemDTO();
taskItem.setId("task1");
taskItem.setName("Review Document");
taskItem.setTaskType("TODO");
taskItem.setAssignment("user1");
sequence.add(taskItem);

// Set sequence
instanceDto.setSequence(sequence);

// Create workflow instance request
WorkflowInstanceRequest request = WorkflowInstanceRequest.builder()
    .name("Sample Workflow")
    .instanceDto(instanceDto)
    .build();

// Create workflow instance
WorkflowInstanceResponse response = workflowInstanceAPI.createWorkflowInstance(request);
```

3. **Process workflows**:

```java
// Process pending queue entries
sweeper.processPendingQueueEntries(10);
```

## Advanced Usage

### Creating Custom Task Handlers

1. Implement the `TaskHandler` interface:

```java
public class CustomTaskHandler implements TaskHandler {
    
    private final TaskInstanceDAO taskInstanceDAO;
    private final ExecutionQueuingInterceptor interceptor;
    
    public CustomTaskHandler(TaskInstanceDAO taskInstanceDAO, ExecutionQueuingInterceptor interceptor) {
        this.taskInstanceDAO = taskInstanceDAO;
        this.interceptor = interceptor;
    }
    
    @Override
    public String getTaskType() {
        return "CUSTOM";
    }
    
    @Override
    public TaskInstance createAndExecute(Integer workflowInstanceId, String name, Map<String, Object> inputJson, 
                                        String assignment, String taskGroupId) {
        // Create task instance
        TaskInstance task = new TaskInstance();
        task.setWorkflowInstanceId(workflowInstanceId);
        task.setName(name);
        task.setType(getTaskType());
        task.setStatus(TaskConstants.STATUS_PENDING);
        task.setAssignment(assignment);
        task.setTaskGroupInstanceId(taskGroupId != null ? Integer.valueOf(taskGroupId) : null);
        task.setInputMap(inputJson);
        
        // Save task instance
        taskInstanceDAO.createTaskInstance(task);
        
        // Execute task
        execute(task);
        
        return task;
    }
    
    @Override
    public void execute(TaskInstance task) {
        // Implement custom execution logic
        task.setStatus(TaskConstants.STATUS_RUNNING);
        taskInstanceDAO.updateTaskInstance(task);
    }
    
    @Override
    public TaskInstance complete(Integer taskInstanceId, Map<String, Object> outputJson) {
        // Get task instance
        TaskInstance task = taskInstanceDAO.getTaskInstance(taskInstanceId);
        
        // Update task
        task.setStatus(TaskConstants.STATUS_COMPLETED);
        task.setOutputMap(outputJson);
        task.setCompletedAt(new java.sql.Timestamp(System.currentTimeMillis()));
        
        // Save task
        taskInstanceDAO.updateTaskInstance(task);
        
        // Intercept task completion
        interceptor.interceptTaskCompletion(task);
        
        return task;
    }
}
```

2. Register the custom task handler:

```java
taskHandlerRegistry.registerHandler(new CustomTaskHandler(taskInstanceDAO, interceptor));
```

### Creating Custom Task Group Handlers

1. Implement the `TaskGroupHandler` interface:

```java
public class CustomTaskGroupHandler implements TaskGroupHandler {
    
    private final TaskHandlerRegistry taskHandlerRegistry;
    
    public CustomTaskGroupHandler(TaskHandlerRegistry taskHandlerRegistry) {
        this.taskHandlerRegistry = taskHandlerRegistry;
    }
    
    @Override
    public String getType() {
        return "CUSTOM_GROUP";
    }
    
    @Override
    public void initialize(TaskGroupInstance taskGroup, TaskGroupDTO taskGroupDto) {
        // Initialize task group state
        Map<String, Object> state = taskGroupDto.getState();
        if (state == null) {
            state = new HashMap<>();
            taskGroupDto.setState(state);
        }
        
        // Set initialized flag
        taskGroupDto.setInitialized(true);
    }
    
    @Override
    public void execute(TaskGroupInstance taskGroup, TaskGroupDTO taskGroupDto) {
        // Implement custom execution logic
        // For example, create child tasks based on input data
        Map<String, Object> inputJson = taskGroup.getInputMap();
        List<String> items = (List<String>) inputJson.get("items");
        
        if (items != null) {
            for (String item : items) {
                Map<String, Object> taskInput = new HashMap<>();
                taskInput.put("item", item);
                
                TaskHandler handler = taskHandlerRegistry.getHandler("TODO");
                handler.createAndExecute(
                    taskGroup.getWorkflowInstanceId(),
                    "Process " + item,
                    taskInput,
                    taskGroup.getCreatedBy(),
                    taskGroup.getId().toString()
                );
            }
        }
    }
    
    @Override
    public boolean isCompleted(TaskGroupInstance taskGroup, TaskGroupDTO taskGroupDto) {
        // Check if all child tasks are completed
        List<TaskInstance> tasks = taskGroup.getTasks();
        if (tasks.isEmpty()) {
            return false;
        }
        
        for (TaskInstance task : tasks) {
            if (!TaskConstants.STATUS_COMPLETED.equals(task.getStatus())) {
                return false;
            }
        }
        
        return true;
    }
    
    @Override
    public void handleTaskCompletion(TaskGroupInstance taskGroup, TaskGroupDTO taskGroupDto, TaskInstance completedTask) {
        // Handle task completion logic
        // For example, update task group state based on completed task
        Map<String, Object> state = taskGroupDto.getState();
        List<String> completedTasks = (List<String>) state.get("completedTasks");
        
        if (completedTasks == null) {
            completedTasks = new ArrayList<>();
            state.put("completedTasks", completedTasks);
        }
        
        completedTasks.add(completedTask.getId().toString());
    }
}
```

2. Register the custom task group handler:

```java
taskGroupHandlerRegistry.registerHandler(new CustomTaskGroupHandler(taskHandlerRegistry));
```

### Using Task Groups in Workflows

1. **Creating a workflow with a horizontal task group**:

```java
// Create workflow instance DTO
WorkflowInstanceDTO instanceDto = new WorkflowInstanceDTO();
instanceDto.setCurrentPosition(0);

// Create sequence
List<SequenceItemDTO> sequence = new ArrayList<>();

// Add a task group to the sequence
TaskGroupSequenceItemDTO taskGroupItem = new TaskGroupSequenceItemDTO();
taskGroupItem.setId("group1");
taskGroupItem.setName("Process Items");
taskGroupItem.setTaskGroupType("HORIZONTAL");
sequence.add(taskGroupItem);

// Set sequence
instanceDto.setSequence(sequence);

// Create task group
TaskGroupDTO taskGroupDto = new TaskGroupDTO();
taskGroupDto.setType("HORIZONTAL");
taskGroupDto.setInitialized(false);

// Add input data
Map<String, Object> inputJson = new HashMap<>();
List<String> items = Arrays.asList("item1", "item2", "item3");
inputJson.put("items", items);
taskGroupDto.setInputJson(inputJson);

// Add task group to instance
Map<String, TaskGroupDTO> taskGroups = new HashMap<>();
taskGroups.put("group1", taskGroupDto);
instanceDto.setTaskGroups(taskGroups);

// Create workflow instance request
WorkflowInstanceRequest request = WorkflowInstanceRequest.builder()
    .name("Parallel Processing Workflow")
    .instanceDto(instanceDto)
    .build();

// Create workflow instance
WorkflowInstanceResponse response = workflowInstanceAPI.createWorkflowInstance(request);
```

2. **Creating a workflow with a vertical task group**:

```java
// Create workflow instance DTO
WorkflowInstanceDTO instanceDto = new WorkflowInstanceDTO();
instanceDto.setCurrentPosition(0);

// Create sequence
List<SequenceItemDTO> sequence = new ArrayList<>();

// Add a task group to the sequence
TaskGroupSequenceItemDTO taskGroupItem = new TaskGroupSequenceItemDTO();
taskGroupItem.setId("group1");
taskGroupItem.setName("Sequential Process");
taskGroupItem.setTaskGroupType("VERTICAL");
sequence.add(taskGroupItem);

// Set sequence
instanceDto.setSequence(sequence);

// Create task group
TaskGroupDTO taskGroupDto = new TaskGroupDTO();
taskGroupDto.setType("VERTICAL");
taskGroupDto.setInitialized(false);

// Create task group sequence
List<SequenceItemDTO> taskGroupSequence = new ArrayList<>();

// Add tasks to task group sequence
TaskSequenceItemDTO task1 = new TaskSequenceItemDTO();
task1.setId("task1");
task1.setName("Review");
task1.setTaskType("TODO");
task1.setAssignment("reviewer");
taskGroupSequence.add(task1);

TaskSequenceItemDTO task2 = new TaskSequenceItemDTO();
task2.setId("task2");
task2.setName("Approve");
task2.setTaskType("TODO");
task2.setAssignment("approver");
taskGroupSequence.add(task2);

TaskSequenceItemDTO task3 = new TaskSequenceItemDTO();
task3.setId("task3");
task3.setName("Publish");
task3.setTaskType("TODO");
task3.setAssignment("publisher");
taskGroupSequence.add(task3);

// Set task group sequence
Map<String, Object> state = new HashMap<>();
state.put("sequence", taskGroupSequence);
state.put("currentPosition", 0);
taskGroupDto.setState(state);

// Add task group to instance
Map<String, TaskGroupDTO> taskGroups = new HashMap<>();
taskGroups.put("group1", taskGroupDto);
instanceDto.setTaskGroups(taskGroups);

// Create workflow instance request
WorkflowInstanceRequest request = WorkflowInstanceRequest.builder()
    .name("Sequential Workflow")
    .instanceDto(instanceDto)
    .build();

// Create workflow instance
WorkflowInstanceResponse response = workflowInstanceAPI.createWorkflowInstance(request);
```
